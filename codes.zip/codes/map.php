<?php
session_start();

// Redirect to login if not logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_role = $_SESSION['user_role'] ?? '';
$user_id = $_SESSION['user_id'];

include 'db.php';

// Fetch farmers based on role
$farmers = [];
if ($user_role === 'Farmer' || $user_role === 'Buyer' || $user_role === 'Delivery') {
    $sql = "SELECT DISTINCT u.id, u.name, u.phone_number as phone, u.address, p.location, COUNT(p.id) as product_count 
            FROM users u 
            JOIN products p ON u.id = p.farmer_id 
            WHERE u.role = 'Farmer' AND p.location IS NOT NULL 
            GROUP BY u.id, u.name, u.phone_number, u.address, p.location";
    $result = $conn->query($sql);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $farmers[] = $row;
        }
    }
}

// Fetch buyers based on role (only for Delivery role)
$buyers = [];
if ($user_role === 'Delivery') {
    $check_address = $conn->query("SHOW COLUMNS FROM users LIKE 'address'");
    if ($check_address && $check_address->num_rows > 0) {
        $sql = "SELECT u.id, u.name, u.phone_number as phone, u.address 
                FROM users u 
                WHERE u.role = 'Buyer' AND u.address IS NOT NULL AND u.address != ''";
        $result = $conn->query($sql);
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $buyers[] = $row;
            }
        }
    }
}

// Fetch active deliveries based on role
$active_deliveries = [];
if ($user_role === 'Buyer') {
    $sql = "SELECT o.id, o.status, u.address as buyer_address, p.location as farmer_location, pr.name as product_name, f.name as farmer_name
            FROM orders o
            JOIN users u ON o.user_id = u.id
            JOIN order_items oi ON o.id = oi.order_id
            JOIN products pr ON oi.product_id = pr.id
            JOIN users f ON pr.farmer_id = f.id
            LEFT JOIN products p ON pr.farmer_id = p.farmer_id
            WHERE o.user_id = ? AND o.status IN ('processing', 'shipped')
            GROUP BY o.id";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $active_deliveries[] = $row;
    }
} elseif ($user_role === 'Delivery') {
    $sql = "SELECT o.id, o.status, u.address as buyer_address, p.location as farmer_location, pr.name as product_name, f.name as farmer_name
            FROM orders o
            JOIN users u ON o.user_id = u.id
            JOIN order_items oi ON o.id = oi.order_id
            JOIN products pr ON oi.product_id = pr.id
            JOIN users f ON pr.farmer_id = f.id
            LEFT JOIN products p ON pr.farmer_id = p.farmer_id
            WHERE o.status IN ('processing', 'shipped')
            GROUP BY o.id";
    $result = $conn->query($sql);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $active_deliveries[] = $row;
        }
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Map View - AgroConnect</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <style>
        #map { height: 600px; width: 100%; border-radius: 10px; }
        .farmer-marker { background: #22c55e; color: white; border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; font-size: 20px; border: 3px solid white; box-shadow: 0 2px 10px rgba(0,0,0,0.3); }
        .buyer-marker { background: #f97316; color: white; border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; font-size: 20px; border: 3px solid white; box-shadow: 0 2px 10px rgba(0,0,0,0.3); }
        .delivery-marker { background: #3b82f6; color: white; border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; font-size: 20px; border: 3px solid white; box-shadow: 0 2px 10px rgba(0,0,0,0.3); }
    </style>
</head>
<body class="bg-gray-50">
    <nav class="bg-white shadow-md p-4">
        <div class="max-w-7xl mx-auto flex justify-between items-center">
            <div class="flex items-center gap-2">
                <img src="logo.png" alt="Logo" class="w-10 h-10" onerror="this.style.display='none'">
                <span class="text-2xl font-bold text-green-800">AgroConnect Map</span>
            </div>
            <a href="<?= $user_role === 'Farmer' ? 'farmer.php' : ($user_role === 'Buyer' ? 'buyer.php' : ($user_role === 'Delivery' ? 'delivery.php' : 'home.php')) ?>" class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto p-6">
        <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
            <h1 class="text-3xl font-bold text-green-800 mb-4">
                <i class="fas fa-map-marked-alt"></i> Farmers & Deliveries Map
            </h1>
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div class="bg-green-50 p-4 rounded-lg">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center text-white">
                            <i class="fas fa-tractor"></i>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">Farmers</p>
                            <p class="text-2xl font-bold text-green-800"><?= count($farmers) ?></p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-orange-50 p-4 rounded-lg">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 bg-orange-600 rounded-full flex items-center justify-center text-white">
                            <i class="fas fa-users"></i>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">Buyers</p>
                            <p class="text-2xl font-bold text-orange-800"><?= count($buyers) ?></p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-blue-50 p-4 rounded-lg">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white">
                            <i class="fas fa-truck"></i>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">Active Deliveries</p>
                            <p class="text-2xl font-bold text-blue-800"><?= count($active_deliveries) ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <div id="map"></div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-white rounded-lg shadow-lg p-6">
                <h2 class="text-xl font-bold text-green-800 mb-4">
                    <i class="fas fa-tractor"></i> Farmers
                </h2>
                <div class="space-y-3 max-h-96 overflow-y-auto">
                    <?php foreach($farmers as $farmer): ?>
                    <div class="border-l-4 border-green-600 bg-green-50 p-4 rounded">
                        <h3 class="font-bold text-green-800"><?= htmlspecialchars($farmer['name']) ?></h3>
                        <p class="text-sm text-gray-600"><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($farmer['location']) ?></p>
                        <p class="text-sm text-gray-600"><i class="fas fa-box"></i> <?= $farmer['product_count'] ?> products</p>
                        <?php if(!empty($farmer['phone'])): ?>
                        <a href="tel:<?= htmlspecialchars($farmer['phone']) ?>" class="text-sm text-blue-600 hover:underline">
                            <i class="fas fa-phone"></i> <?= htmlspecialchars($farmer['phone']) ?>
                        </a>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-lg p-6">
                <h2 class="text-xl font-bold text-orange-800 mb-4">
                    <i class="fas fa-users"></i> Buyers
                </h2>
                <div class="space-y-3 max-h-96 overflow-y-auto">
                    <?php if(empty($buyers)): ?>
                    <p class="text-gray-500 text-center py-8">No buyers with addresses</p>
                    <?php else: ?>
                    <?php foreach($buyers as $buyer): ?>
                    <div class="border-l-4 border-orange-600 bg-orange-50 p-4 rounded">
                        <h3 class="font-bold text-orange-800"><?= htmlspecialchars($buyer['name']) ?></h3>
                        <p class="text-sm text-gray-600"><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($buyer['address']) ?></p>
                        <?php if(!empty($buyer['phone'])): ?>
                        <a href="tel:<?= htmlspecialchars($buyer['phone']) ?>" class="text-sm text-blue-600 hover:underline">
                            <i class="fas fa-phone"></i> <?= htmlspecialchars($buyer['phone']) ?>
                        </a>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-lg p-6">
                <h2 class="text-xl font-bold text-blue-800 mb-4">
                    <i class="fas fa-truck"></i> Active Deliveries
                </h2>
                <?php if(empty($active_deliveries)): ?>
                <p class="text-gray-500 text-center py-8">No active deliveries</p>
                <?php else: ?>
                <div class="space-y-3 max-h-96 overflow-y-auto">
                    <?php foreach($active_deliveries as $delivery): ?>
                    <div class="border-l-4 border-blue-600 bg-blue-50 p-4 rounded">
                        <h3 class="font-bold text-blue-800">Order #<?= $delivery['id'] ?></h3>
                        <p class="text-sm text-gray-600">Status: <span class="font-semibold"><?= ucfirst($delivery['status']) ?></span></p>
                        <p class="text-sm text-gray-600"><i class="fas fa-arrow-right"></i> From: <?= htmlspecialchars($delivery['farmer_location']) ?></p>
                        <a href="order_tracking.php?order_id=<?= $delivery['id'] ?>" class="text-sm text-blue-600 hover:underline">
                            <i class="fas fa-route"></i> Track Order
                        </a>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        // Initialize map centered on Sri Lanka
        const map = L.map('map').setView([7.8731, 80.7718], 8);

        // Add OpenStreetMap tiles
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(map);

        // Sri Lanka district coordinates
        const locationCoords = {
            'Colombo': [6.9271, 79.8612],
            'Kandy': [7.2906, 80.6337],
            'Galle': [6.0535, 80.2210],
            'Matara': [5.9549, 80.5550],
            'Jaffna': [9.6615, 80.0255],
            'Anuradhapura': [8.3114, 80.4037],
            'Kurunegala': [7.4863, 80.3623],
            'Ratnapura': [6.7056, 80.3847],
            'Batticaloa': [7.7310, 81.6747],
            'Trincomalee': [8.5874, 81.2152],
            'Ampara': [7.2914, 81.6747],
            'Badulla': [6.9934, 81.0550],
            'Gampaha': [7.0840, 80.0098],
            'Hambantota': [6.1429, 81.1212],
            'Kalutara': [6.5854, 79.9607],
            'Kegalle': [7.2513, 80.3464],
            'Kilinochchi': [9.3803, 80.3847],
            'Mannar': [8.9810, 79.9044],
            'Matale': [7.4675, 80.6234],
            'Monaragala': [6.8728, 81.3507],
            'Mullaitivu': [9.2671, 80.8142],
            'Nuwara Eliya': [6.9497, 80.7891],
            'Polonnaruwa': [7.9403, 81.0188],
            'Puttalam': [8.0362, 79.8283],
            'Vavuniya': [8.7542, 80.4982]
        };

        // Add farmer markers
        const farmers = <?= json_encode($farmers) ?>;
        farmers.forEach(farmer => {
            const coords = locationCoords[farmer.location] || [7.8731, 80.7718];
            const marker = L.marker(coords, {
                icon: L.divIcon({
                    className: 'farmer-marker',
                    html: '<i class="fas fa-tractor"></i>',
                    iconSize: [40, 40]
                })
            }).addTo(map);
            
            marker.bindPopup(`
                <div class="p-2">
                    <h3 class="font-bold text-green-800"><i class="fas fa-tractor"></i> ${farmer.name}</h3>
                    <p class="text-sm"><i class="fas fa-map-marker-alt"></i> ${farmer.location}</p>
                    <p class="text-sm"><i class="fas fa-box"></i> ${farmer.product_count} products</p>
                    ${farmer.phone ? `<a href="tel:${farmer.phone}" class="text-blue-600 text-sm"><i class="fas fa-phone"></i> Call</a>` : ''}
                </div>
            `);
        });

        // Add buyer markers
        const buyers = <?= json_encode($buyers) ?>;
        
        // Function to extract city from address
        function getCityFromAddress(address) {
            const cities = Object.keys(locationCoords);
            const addressLower = address.toLowerCase();
            
            // Try to find a matching city in the address
            for (let city of cities) {
                if (addressLower.includes(city.toLowerCase())) {
                    return city;
                }
            }
            return null;
        }
        
        buyers.forEach((buyer, index) => {
            // Try to extract city from address
            const city = getCityFromAddress(buyer.address);
            let coords;
            
            if (city && locationCoords[city]) {
                // Use the city coordinates with small random offset
                coords = locationCoords[city];
                const lat = coords[0] + (Math.random() - 0.5) * 0.05;
                const lng = coords[1] + (Math.random() - 0.5) * 0.05;
                coords = [lat, lng];
            } else {
                // If no city found, distribute across cities
                const cities = Object.keys(locationCoords);
                const cityIndex = index % cities.length;
                coords = locationCoords[cities[cityIndex]];
                const lat = coords[0] + (Math.random() - 0.5) * 0.1;
                const lng = coords[1] + (Math.random() - 0.5) * 0.1;
                coords = [lat, lng];
            }
            
            const marker = L.marker(coords, {
                icon: L.divIcon({
                    className: 'buyer-marker',
                    html: '<i class="fas fa-user"></i>',
                    iconSize: [40, 40]
                })
            }).addTo(map);
            
            marker.bindPopup(`
                <div class="p-2">
                    <h3 class="font-bold text-orange-800"><i class="fas fa-user"></i> ${buyer.name}</h3>
                    <p class="text-sm"><i class="fas fa-map-marker-alt"></i> ${buyer.address}</p>
                    ${buyer.phone ? `<a href="tel:${buyer.phone}" class="text-blue-600 text-sm"><i class="fas fa-phone"></i> Call</a>` : ''}
                </div>
            `);
        });

        // Add delivery markers
        const deliveries = <?= json_encode($active_deliveries) ?>;
        deliveries.forEach(delivery => {
            if (delivery.farmer_location) {
                const coords = locationCoords[delivery.farmer_location] || [7.8731, 80.7718];
                const marker = L.marker(coords, {
                    icon: L.divIcon({
                        className: 'delivery-marker',
                        html: '<i class="fas fa-truck"></i>',
                        iconSize: [40, 40]
                    })
                }).addTo(map);
                
                marker.bindPopup(`
                    <div class="p-2">
                        <h3 class="font-bold text-blue-800"><i class="fas fa-truck"></i> Order #${delivery.id}</h3>
                        <p class="text-sm">Status: ${delivery.status}</p>
                        <p class="text-sm">From: ${delivery.farmer_location}</p>
                        <a href="order_tracking.php?order_id=${delivery.id}" class="text-blue-600 text-sm">Track Order</a>
                    </div>
                `);
            }
        });
    </script>
</body>
</html>
