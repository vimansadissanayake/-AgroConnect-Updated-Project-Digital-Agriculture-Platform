<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$order_id = $_GET['order_id'] ?? null;

if (!$order_id) {
    header('Location: buyer.php');
    exit();
}

// Check if columns exist
$check = $conn->query("SHOW COLUMNS FROM orders LIKE 'delivery_partner_id'");
$has_delivery_partner = $check->num_rows > 0;
$check = $conn->query("SHOW COLUMNS FROM users LIKE 'phone'");
$has_phone = $check->num_rows > 0;
$check = $conn->query("SHOW COLUMNS FROM users LIKE 'address'");
$has_address = $check->num_rows > 0;

$sql = "SELECT o.*, u.name as buyer_name, 
        " . ($has_address ? "u.address" : "''") . " as delivery_address, 
        " . ($has_phone ? "u.phone" : "''") . " as buyer_phone
        FROM orders o
        JOIN users u ON o.user_id = u.id
        WHERE o.id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) {
    header('Location: buyer.php');
    exit();
}

// Get delivery partner info if column exists
if ($has_delivery_partner && !empty($order['delivery_partner_id'])) {
    $partner_sql = "SELECT name, " . ($has_phone ? "phone" : "''") . " as phone FROM users WHERE id = ?";
    $stmt = $conn->prepare($partner_sql);
    $stmt->bind_param("i", $order['delivery_partner_id']);
    $stmt->execute();
    $partner = $stmt->get_result()->fetch_assoc();
    $order['delivery_partner_name'] = $partner['name'] ?? null;
    $order['delivery_partner_phone'] = $partner['phone'] ?? null;
    $stmt->close();
} else {
    $order['delivery_partner_name'] = null;
    $order['delivery_partner_phone'] = null;
}

$items_sql = "SELECT oi.*, p.name as product_name, p.location as farmer_location FROM order_items oi 
              JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?";
$stmt = $conn->prepare($items_sql);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get farmer location from first item
$farmer_location = !empty($items) ? $items[0]['farmer_location'] : 'Colombo';

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Order #<?= $order_id ?> - AgroConnect</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50">
    <div class="max-w-6xl mx-auto p-6">
        <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
            <h1 class="text-3xl font-bold text-green-800 mb-4">
                <i class="fas fa-map-marker-alt"></i> Track Order #<?= $order_id ?>
            </h1>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                    <h3 class="font-bold text-lg mb-2">Order Status</h3>
                    <div class="flex items-center gap-4">
                        <span class="px-4 py-2 bg-blue-100 text-blue-800 rounded-full font-bold">
                            <?= ucfirst($order['status']) ?>
                        </span>
                        <span class="text-gray-600"><?= date('M d, Y', strtotime($order['order_date'])) ?></span>
                    </div>
                </div>
                
                <div>
                    <h3 class="font-bold text-lg mb-2">Delivery Address</h3>
                    <p class="text-gray-700"><?= htmlspecialchars($order['delivery_address']) ?></p>
                </div>
            </div>

            <div class="mb-6">
                <h3 class="font-bold text-lg mb-3">Order Items</h3>
                <div class="bg-gray-50 rounded p-4">
                    <?php foreach($items as $item): ?>
                    <div class="flex justify-between py-2 border-b">
                        <span><?= htmlspecialchars($item['product_name']) ?> x <?= $item['quantity'] ?></span>
                        <span class="font-bold">Rs <?= number_format($item['price_at_order'] * $item['quantity'], 2) ?></span>
                    </div>
                    <?php endforeach; ?>
                    <div class="flex justify-between py-2 mt-2 font-bold text-lg">
                        <span>Total</span>
                        <span class="text-green-600">Rs <?= number_format($order['total_amount'], 2) ?></span>
                    </div>
                </div>
            </div>

            <?php if($order['delivery_partner_name']): ?>
            <div class="bg-blue-50 rounded p-4 mb-6">
                <h3 class="font-bold text-lg mb-2">Delivery Partner</h3>
                <p><i class="fas fa-user"></i> <?= htmlspecialchars($order['delivery_partner_name']) ?></p>
                <p><i class="fas fa-phone"></i> <?= htmlspecialchars($order['delivery_partner_phone']) ?></p>
            </div>
            <?php endif; ?>

            <div class="mb-6">
                <h3 class="font-bold text-lg mb-3">Delivery Progress</h3>
                <div class="flex justify-between items-center">
                    <div class="flex flex-col items-center <?= in_array($order['status'], ['pending', 'processing', 'shipped', 'delivered']) ? 'text-green-600' : 'text-gray-400' ?>">
                        <div class="w-12 h-12 rounded-full <?= in_array($order['status'], ['pending', 'processing', 'shipped', 'delivered']) ? 'bg-green-600' : 'bg-gray-300' ?> flex items-center justify-center text-white mb-2">
                            <i class="fas fa-check"></i>
                        </div>
                        <span class="text-sm font-medium">Ordered</span>
                    </div>
                    <div class="flex-1 h-1 <?= in_array($order['status'], ['processing', 'shipped', 'delivered']) ? 'bg-green-600' : 'bg-gray-300' ?>"></div>
                    <div class="flex flex-col items-center <?= in_array($order['status'], ['processing', 'shipped', 'delivered']) ? 'text-green-600' : 'text-gray-400' ?>">
                        <div class="w-12 h-12 rounded-full <?= in_array($order['status'], ['processing', 'shipped', 'delivered']) ? 'bg-green-600' : 'bg-gray-300' ?> flex items-center justify-center text-white mb-2">
                            <i class="fas fa-box"></i>
                        </div>
                        <span class="text-sm font-medium">Prepared</span>
                    </div>
                    <div class="flex-1 h-1 <?= in_array($order['status'], ['shipped', 'delivered']) ? 'bg-green-600' : 'bg-gray-300' ?>"></div>
                    <div class="flex flex-col items-center <?= in_array($order['status'], ['shipped', 'delivered']) ? 'text-green-600' : 'text-gray-400' ?>">
                        <div class="w-12 h-12 rounded-full <?= in_array($order['status'], ['shipped', 'delivered']) ? 'bg-green-600' : 'bg-gray-300' ?> flex items-center justify-center text-white mb-2">
                            <i class="fas fa-truck"></i>
                        </div>
                        <span class="text-sm font-medium">Shipped</span>
                    </div>
                    <div class="flex-1 h-1 <?= $order['status'] === 'delivered' ? 'bg-green-600' : 'bg-gray-300' ?>"></div>
                    <div class="flex flex-col items-center <?= $order['status'] === 'delivered' ? 'text-green-600' : 'text-gray-400' ?>">
                        <div class="w-12 h-12 rounded-full <?= $order['status'] === 'delivered' ? 'bg-green-600' : 'bg-gray-300' ?> flex items-center justify-center text-white mb-2">
                            <i class="fas fa-home"></i>
                        </div>
                        <span class="text-sm font-medium">Delivered</span>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                <h3 class="font-bold text-lg p-4 bg-green-600 text-white">
                    <i class="fas fa-map-marked-alt"></i> Delivery Route
                </h3>
                <div id="map" style="height: 450px; width: 100%;"></div>
            </div>

            <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
            <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
            <script>
                const deliveryAddress = <?= json_encode($order['delivery_address']) ?>;
                const farmerLocation = <?= json_encode($farmer_location) ?>;
                const orderStatus = <?= json_encode($order['status']) ?>;
                
                // Sri Lanka city coordinates
                const cityCoords = {
                    'Colombo': [6.9271, 79.8612],
                    'Kandy': [7.2906, 80.6337],
                    'Galle': [6.0535, 80.2210],
                    'Matara': [5.9549, 80.5550],
                    'Jaffna': [9.6615, 80.0255],
                    'Anuradhapura': [8.3114, 80.4037],
                    'Kurunegala': [7.4863, 80.3623],
                    'Ratnapura': [6.7056, 80.3847],
                    'Batticaloa': [7.7310, 81.6747],
                    'Trincomalee': [8.5874, 81.2152],
                    'Ampara': [7.2914, 81.6747],
                    'Badulla': [6.9934, 81.0550],
                    'Gampaha': [7.0840, 80.0098],
                    'Hambantota': [6.1429, 81.1212],
                    'Kalutara': [6.5854, 79.9607],
                    'Kegalle': [7.2513, 80.3464],
                    'Matale': [7.4675, 80.6234],
                    'Nuwara Eliya': [6.9497, 80.7891],
                    'Polonnaruwa': [7.9403, 81.0188],
                    'Puttalam': [8.0362, 79.8283],
                    'Vavuniya': [8.7542, 80.4982],
                    'Monaragala': [6.8728, 81.3507],
                    'Kilinochchi': [9.3961, 80.3980],
                    'Mannar': [8.9810, 79.9044],
                    'Mullaitivu': [9.2671, 80.8142],
                    'Chilaw': [7.5759, 79.7953],
                    'Negombo': [7.2008, 79.8358],
                    'Avissawella': [6.9522, 80.2097],
                    'Embilipitiya': [6.3429, 80.8501],
                    'Horana': [6.7153, 80.0630]
                };
                
                // Extract city from address or use main location
                function getCityFromAddress(address) {
                    if (!address) return null;
                    const addressLower = address.toLowerCase();
                    for (let city in cityCoords) {
                        if (addressLower.includes(city.toLowerCase())) {
                            return city;
                        }
                    }
                    return null;
                }
                
                // Get delivery city with smart regional fallback
                let deliveryCity = getCityFromAddress(deliveryAddress);
                if (!deliveryCity) {
                    // Check if address mentions regions for better fallback
                    const addrLower = (deliveryAddress || '').toLowerCase();
                    if (addrLower.includes('east') || addrLower.includes('batticaloa') || addrLower.includes('ampara')) {
                        deliveryCity = 'Batticaloa';
                    } else if (addrLower.includes('south') || addrLower.includes('hambantota') || addrLower.includes('matara')) {
                        deliveryCity = 'Galle';
                    } else if (addrLower.includes('north') || addrLower.includes('jaffna')) {
                        deliveryCity = 'Jaffna';
                    } else if (addrLower.includes('central') || addrLower.includes('kandy')) {
                        deliveryCity = 'Kandy';
                    } else {
                        deliveryCity = 'Colombo'; // Western province default
                    }
                }
                
                // Get farmer city with smart regional fallback
                let farmerCity = cityCoords[farmerLocation] ? farmerLocation : getCityFromAddress(farmerLocation);
                if (!farmerCity) {
                    const locLower = (farmerLocation || '').toLowerCase();
                    if (locLower.includes('east') || locLower.includes('uva')) {
                        farmerCity = 'Badulla';
                    } else if (locLower.includes('south')) {
                        farmerCity = 'Matara';
                    } else if (locLower.includes('north')) {
                        farmerCity = 'Anuradhapura';
                    } else {
                        farmerCity = 'Kandy'; // Central agricultural hub
                    }
                }
                
                const deliveryCoords = cityCoords[deliveryCity];
                const farmerCoords = cityCoords[farmerCity];
                
                // Calculate center point between farmer and delivery
                const centerLat = (farmerCoords[0] + deliveryCoords[0]) / 2;
                const centerLng = (farmerCoords[1] + deliveryCoords[1]) / 2;
                
                // Initialize map
                const map = L.map('map').setView([centerLat, centerLng], 8);
                
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '© OpenStreetMap contributors'
                }).addTo(map);
                
                // Add farmer marker (green)
                const farmerIcon = L.divIcon({
                    className: 'custom-marker',
                    html: '<div style="background: #22c55e; width: 45px; height: 45px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 22px; border: 3px solid white; box-shadow: 0 3px 15px rgba(0,0,0,0.4);"><i class="fas fa-tractor"></i></div>',
                    iconSize: [45, 45]
                });
                
                L.marker(farmerCoords, { icon: farmerIcon }).addTo(map)
                    .bindPopup(`
                        <div style="padding: 10px; min-width: 200px;">
                            <h4 style="font-weight: bold; margin-bottom: 5px; color: #22c55e;"><i class="fas fa-tractor"></i> Farmer Location</h4>
                            <p style="margin: 0; font-size: 14px;"><strong>${farmerCity}</strong></p>
                            <p style="margin: 5px 0 0 0; font-size: 12px; color: #666;">Origin: ${farmerLocation || farmerCity}</p>
                        </div>
                    `);
                
                // Add delivery marker (red)
                const deliveryIcon = L.divIcon({
                    className: 'custom-marker',
                    html: '<div style="background: #ef4444; width: 45px; height: 45px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 22px; border: 3px solid white; box-shadow: 0 3px 15px rgba(0,0,0,0.4);"><i class="fas fa-home"></i></div>',
                    iconSize: [45, 45]
                });
                
                L.marker(deliveryCoords, { icon: deliveryIcon }).addTo(map)
                    .bindPopup(`
                        <div style="padding: 10px; min-width: 200px;">
                            <h4 style="font-weight: bold; margin-bottom: 5px; color: #ef4444;"><i class="fas fa-home"></i> Delivery Location</h4>
                            <p style="margin: 0; font-size: 14px;">${deliveryAddress}</p>
                            <p style="margin: 5px 0 0 0; font-size: 12px; color: #666;">Status: <strong>${orderStatus}</strong></p>
                        </div>
                    `).openPopup();
                
                // Draw route line
                const routeLine = L.polyline([farmerCoords, deliveryCoords], {
                    color: '#3b82f6',
                    weight: 4,
                    opacity: 0.7,
                    dashArray: '10, 10'
                }).addTo(map);
                
                // Add delivery truck marker if order is shipped
                if (orderStatus === 'shipped') {
                    const midLat = (farmerCoords[0] + deliveryCoords[0]) / 2;
                    const midLng = (farmerCoords[1] + deliveryCoords[1]) / 2;
                    
                    const truckIcon = L.divIcon({
                        className: 'custom-marker',
                        html: '<div style="background: #3b82f6; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 20px; border: 3px solid white; box-shadow: 0 3px 15px rgba(0,0,0,0.4); animation: pulse 2s infinite;"><i class="fas fa-truck"></i></div>',
                        iconSize: [40, 40]
                    });
                    
                    L.marker([midLat, midLng], { icon: truckIcon }).addTo(map)
                        .bindPopup(`
                            <div style="padding: 10px;">
                                <h4 style="font-weight: bold; margin-bottom: 5px; color: #3b82f6;"><i class="fas fa-truck"></i> In Transit</h4>
                                <p style="margin: 0; font-size: 14px;">Your order is on the way!</p>
                            </div>
                        `);
                }
                
                // Fit map to show both markers
                map.fitBounds([farmerCoords, deliveryCoords], { padding: [50, 50] });
            </script>
            <style>
                @keyframes pulse {
                    0%, 100% { transform: scale(1); }
                    50% { transform: scale(1.1); }
                }
            </style>

            <div class="mt-6 flex gap-4">
                <a href="buyer.php" class="px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
                <button onclick="location.reload()" class="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700">
                    <i class="fas fa-sync"></i> Refresh Status
                </button>
            </div>
        </div>
    </div>

    <script>
        setInterval(() => {
            fetch(`order_tracking.php?order_id=<?= $order_id ?>&ajax=1`)
                .then(r => r.json())
                .then(data => {
                    if(data.status !== '<?= $order['status'] ?>') {
                        location.reload();
                    }
                });
        }, 30000);
    </script>
</body>
</html>
