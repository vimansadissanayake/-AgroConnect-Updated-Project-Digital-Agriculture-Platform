<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false]);
    exit();
}

$user_id = $_SESSION['user_id'];

// Check if notifications table exists
$check = $conn->query("SHOW TABLES LIKE 'notifications'");
if ($check->num_rows == 0) {
    echo json_encode(['success' => false, 'message' => 'Notifications table not found']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Get unread notifications
    $sql = "SELECT * FROM notifications WHERE user_id = ? AND is_read = 0 ORDER BY created_at DESC LIMIT 10";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $notifications = $result->fetch_all(MYSQLI_ASSOC);
    
    echo json_encode(['success' => true, 'notifications' => $notifications]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mark_read'])) {
    // Mark notifications as read
    $conn->query("UPDATE notifications SET is_read = 1 WHERE user_id = $user_id");
    echo json_encode(['success' => true]);
}

$conn->close();
?>
