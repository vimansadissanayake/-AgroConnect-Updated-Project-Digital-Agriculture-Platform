<?php
session_start();
include 'db.php';

$product_id = $_GET['id'] ?? null;

if (!$product_id) {
    header("Location: marketplace.php");
    exit();
}

// Fetch product details
$product_query = "SELECT p.*, u.name as farmer_name, u.phone_number as farmer_phone 
                  FROM products p 
                  JOIN users u ON p.farmer_id = u.id 
                  WHERE p.id = ?";
$stmt = $conn->prepare($product_query);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$product) {
    header("Location: marketplace.php");
    exit();
}

// Fetch farmer rating
$farmer_rating_query = "SELECT * FROM farmer_ratings WHERE farmer_id = ?";
$stmt = $conn->prepare($farmer_rating_query);
$stmt->bind_param("i", $product['farmer_id']);
$stmt->execute();
$farmer_rating = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Fetch product reviews
$reviews_query = "SELECT pr.*, u.name as buyer_name, u.profile_image_path 
                  FROM product_reviews pr 
                  JOIN users u ON pr.user_id = u.id 
                  WHERE pr.product_id = ? 
                  ORDER BY pr.created_at DESC";
$stmt = $conn->prepare($reviews_query);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$reviews_result = $stmt->get_result();
$reviews = [];
$total_rating = 0;
$review_count = 0;

while ($row = $reviews_result->fetch_assoc()) {
    $reviews[] = $row;
    $total_rating += $row['rating'];
    $review_count++;
}
$stmt->close();

$average_rating = $review_count > 0 ? round($total_rating / $review_count, 1) : 0;

// Fetch quality verification
$quality_query = "SELECT * FROM quality_verifications WHERE product_id = ? AND verification_status = 'approved' ORDER BY verified_at DESC LIMIT 1";
$stmt = $conn->prepare($quality_query);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$quality_verification = $stmt->get_result()->fetch_assoc();
$stmt->close();

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['name']); ?> - AgroConnect</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        body { font-family: 'Poppins', sans-serif; }
        .star-filled { color: #fbbf24; }
        .star-empty { color: #d1d5db; }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-md sticky top-0 z-50">
        <div class="container mx-auto px-6 py-3">
            <div class="flex items-center justify-between">
                <a href="home.php" class="flex items-center">
                    <img src="logo.png" alt="Logo" class="w-10 h-10 mr-2">
                    <span class="text-xl font-bold text-green-800">AgroConnect</span>
                </a>
                <div class="flex items-center space-x-4">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <a href="<?php echo $_SESSION['user_role'] == 'Buyer' ? 'buyer.php' : 'farmer.php'; ?>" class="text-green-700 hover:text-green-800">Dashboard</a>
                    <?php else: ?>
                        <a href="login.php" class="text-green-700 hover:text-green-800">Login</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <!-- Product Image -->
            <div class="bg-white rounded-2xl shadow-lg p-6">
                <img src="<?php echo htmlspecialchars($product['image_url'] ?: 'https://via.placeholder.com/500'); ?>" 
                     alt="<?php echo htmlspecialchars($product['name']); ?>"
                     class="w-full h-96 object-cover rounded-xl">
                
                <!-- Quality Badge -->
                <?php if ($product['is_quality_verified']): ?>
                    <div class="mt-4 bg-green-100 border border-green-400 rounded-lg p-4">
                        <div class="flex items-center space-x-3">
                            <i class="fas fa-certificate text-green-600 text-2xl"></i>
                            <div>
                                <p class="font-bold text-green-800">Quality Verified</p>
                                <p class="text-sm text-green-700">This product has been verified by our food testers</p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Product Info -->
            <div class="bg-white rounded-2xl shadow-lg p-6">
                <h1 class="text-4xl font-bold text-gray-800 mb-4"><?php echo htmlspecialchars($product['name']); ?></h1>
                
                <!-- Rating -->
                <div class="flex items-center space-x-3 mb-4">
                    <div class="flex items-center">
                        <?php for($i = 1; $i <= 5; $i++): ?>
                            <i class="fas fa-star <?php echo $i <= $average_rating ? 'star-filled' : 'star-empty'; ?>"></i>
                        <?php endfor; ?>
                    </div>
                    <span class="text-lg font-semibold"><?php echo $average_rating; ?></span>
                    <span class="text-gray-600">(<?php echo $review_count; ?> reviews)</span>
                </div>

                <!-- Price -->
                <div class="mb-6">
                    <span class="text-4xl font-bold text-green-700">Rs <?php echo number_format($product['price'], 2); ?></span>
                    <span class="text-xl text-gray-600">/ <?php echo htmlspecialchars($product['unit']); ?></span>
                </div>

                <!-- Description -->
                <div class="mb-6">
                    <h3 class="text-xl font-bold text-gray-800 mb-2">Description</h3>
                    <p class="text-gray-700"><?php echo htmlspecialchars($product['description'] ?: 'Fresh and quality produce from local farmers.'); ?></p>
                </div>

                <!-- Product Details -->
                <div class="grid grid-cols-2 gap-4 mb-6">
                    <div class="bg-gray-50 rounded-lg p-4">
                        <p class="text-sm text-gray-600">Category</p>
                        <p class="font-semibold text-gray-800"><?php echo htmlspecialchars($product['category']); ?></p>
                    </div>
                    <div class="bg-gray-50 rounded-lg p-4">
                        <p class="text-sm text-gray-600">Location</p>
                        <p class="font-semibold text-gray-800"><?php echo htmlspecialchars($product['location']); ?></p>
                    </div>
                    <div class="bg-gray-50 rounded-lg p-4">
                        <p class="text-sm text-gray-600">Stock</p>
                        <p class="font-semibold text-gray-800"><?php echo number_format($product['stock_quantity'], 2); ?> <?php echo htmlspecialchars($product['unit']); ?></p>
                    </div>
                    <div class="bg-gray-50 rounded-lg p-4">
                        <p class="text-sm text-gray-600">Farmer</p>
                        <p class="font-semibold text-gray-800"><?php echo htmlspecialchars($product['farmer_name']); ?></p>
                    </div>
                </div>

                <!-- Farmer Rating -->
                <?php if ($farmer_rating): ?>
                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                        <h4 class="font-bold text-gray-800 mb-2">Farmer Rating</h4>
                        <div class="grid grid-cols-3 gap-3 text-sm">
                            <div>
                                <p class="text-gray-600">Overall</p>
                                <p class="font-bold text-blue-700"><?php echo number_format($farmer_rating['average_rating'], 1); ?> ★</p>
                            </div>
                            <div>
                                <p class="text-gray-600">Quality</p>
                                <p class="font-bold text-blue-700"><?php echo number_format($farmer_rating['quality_score'], 1); ?> ★</p>
                            </div>
                            <div>
                                <p class="text-gray-600">Delivery</p>
                                <p class="font-bold text-blue-700"><?php echo number_format($farmer_rating['delivery_score'], 1); ?> ★</p>
                            </div>
                        </div>
                        <p class="text-xs text-gray-600 mt-2"><?php echo $farmer_rating['total_reviews']; ?> total reviews • <?php echo $farmer_rating['total_sales']; ?> sales</p>
                    </div>
                <?php endif; ?>

                <!-- Action Buttons -->
                <div class="space-y-3">
                    <?php if (isset($_SESSION['user_id']) && $_SESSION['user_role'] === 'Buyer'): ?>
                        <button onclick="addToCart(<?php echo $product_id; ?>)" class="w-full bg-green-700 hover:bg-green-800 text-white font-bold py-4 rounded-lg transition">
                            <i class="fas fa-shopping-cart mr-2"></i>Add to Cart
                        </button>
                    <?php else: ?>
                        <a href="login.php" class="block w-full bg-green-700 hover:bg-green-800 text-white font-bold py-4 rounded-lg transition text-center">
                            Login to Purchase
                        </a>
                    <?php endif; ?>
                    <a href="marketplace.php" class="block w-full bg-white hover:bg-gray-50 text-green-700 font-bold py-4 rounded-lg border-2 border-green-700 transition text-center">
                        <i class="fas fa-arrow-left mr-2"></i>Back to Marketplace
                    </a>
                </div>
            </div>
        </div>

        <!-- Reviews Section -->
        <div class="bg-white rounded-2xl shadow-lg p-6">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">
                <i class="fas fa-star text-yellow-500 mr-2"></i>Customer Reviews
            </h2>

            <?php if (empty($reviews)): ?>
                <p class="text-gray-600 text-center py-8">No reviews yet. Be the first to review this product!</p>
            <?php else: ?>
                <div class="space-y-6">
                    <?php foreach ($reviews as $review): ?>
                        <div class="border-b border-gray-200 pb-6 last:border-b-0">
                            <div class="flex items-start space-x-4">
                                <div class="flex-shrink-0">
                                    <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                                        <span class="text-green-700 font-bold"><?php echo strtoupper(substr($review['buyer_name'], 0, 1)); ?></span>
                                    </div>
                                </div>
                                <div class="flex-1">
                                    <div class="flex items-center justify-between mb-2">
                                        <h4 class="font-bold text-gray-800"><?php echo htmlspecialchars($review['buyer_name']); ?></h4>
                                        <span class="text-sm text-gray-500"><?php echo date('M d, Y', strtotime($review['created_at'])); ?></span>
                                    </div>
                                    <div class="flex items-center space-x-4 mb-3">
                                        <div class="flex items-center">
                                            <?php for($i = 1; $i <= 5; $i++): ?>
                                                <i class="fas fa-star <?php echo $i <= $review['rating'] ? 'star-filled' : 'star-empty'; ?> text-sm"></i>
                                            <?php endfor; ?>
                                        </div>
                                        <?php if ($review['is_verified_purchase']): ?>
                                            <span class="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">Verified Purchase</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="grid grid-cols-2 gap-2 mb-3 text-sm">
                                        <div>
                                            <span class="text-gray-600">Quality: </span>
                                            <span class="font-semibold"><?php echo $review['quality_rating']; ?>/5</span>
                                        </div>
                                        <div>
                                            <span class="text-gray-600">Delivery: </span>
                                            <span class="font-semibold"><?php echo $review['delivery_rating']; ?>/5</span>
                                        </div>
                                    </div>
                                    <?php if ($review['review_text']): ?>
                                        <p class="text-gray-700"><?php echo htmlspecialchars($review['review_text']); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function addToCart(productId) {
            // This would integrate with your existing buyer.php cart system
            alert('Product will be added to cart. Please go to marketplace to add items.');
            window.location.href = 'buyer.php';
        }
    </script>
</body>
</html>
