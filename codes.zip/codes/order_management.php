<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Farmer') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$farmer_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'get_orders') {
        $sql = "SELECT o.id, o.order_date, o.total_amount, o.status, o.delivery_partner_id,
                u.name as buyer_name, u.address as delivery_address,
                GROUP_CONCAT(CONCAT(p.name, ' x', oi.quantity, ' ', p.unit) SEPARATOR ', ') as items
                FROM orders o
                JOIN order_items oi ON o.id = oi.order_id
                JOIN products p ON oi.product_id = p.id
                JOIN users u ON o.user_id = u.id
                WHERE p.farmer_id = ?
                GROUP BY o.id
                ORDER BY o.order_date DESC";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $farmer_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $orders = $result->fetch_all(MYSQLI_ASSOC);
        
        echo json_encode(['success' => true, 'orders' => $orders]);
        
    } elseif ($action === 'prepare_order') {
        $order_id = $_POST['order_id'];
        
        $stmt = $conn->prepare("UPDATE orders SET status = 'processing' WHERE id = ?");
        $stmt->bind_param("i", $order_id);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Order marked as prepared']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to update order']);
        }
        
    } elseif ($action === 'assign_delivery') {
        $order_id = $_POST['order_id'];
        $delivery_partner_id = $_POST['delivery_partner_id'];
        
        $stmt = $conn->prepare("UPDATE orders SET delivery_partner_id = ?, status = 'shipped' WHERE id = ?");
        $stmt->bind_param("ii", $delivery_partner_id, $order_id);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Delivery partner assigned']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to assign delivery partner']);
        }
        
    } elseif ($action === 'get_delivery_partners') {
        $stmt = $conn->query("SELECT id, name, phone FROM users WHERE role = 'Delivery'");
        $partners = $stmt->fetch_all(MYSQLI_ASSOC);
        
        echo json_encode(['success' => true, 'partners' => $partners]);
    }
}

$conn->close();
?>
