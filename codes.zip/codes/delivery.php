<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Database connection details (consistent with other dashboards)
$servername = "localhost";
$username_db = "root";
$password_db = ""; // Your MySQL password
$dbname = "vimansa"; // Your database name

$userId = $_SESSION['user_id'];
$userName = $_SESSION['user_name'];
$userRole = $_SESSION['user_role'] ?? 'Delivery';

// Establish database connection
$conn = new mysqli($servername, $username_db, $password_db, $dbname);
if ($conn->connect_error) {
    die("<div style='color:red;'>Database connection failed: " . $conn->connect_error . "</div>");
}

// --- Handle AJAX status update for orders ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'], $_POST['status'])) {
    $orderId = $_POST['order_id'];
    $newStatus = $_POST['status'];

    // Validate status to prevent arbitrary updates
    $allowedStatuses = ['pending', 'processing', 'shipped', 'delivered', 'cancelled']; // 'pending' is initial, 'processing' for delivery pickup
    if (!in_array($newStatus, $allowedStatuses)) {
        http_response_code(400);
        exit('Invalid status');
    }

   
    $stmt = $conn->prepare("UPDATE orders SET status=? WHERE id=?");
    $stmt->bind_param("si", $newStatus, $orderId);
    $ok = $stmt->execute();
    $stmt->close();
    
    // If status is delivered, send notifications
    if ($ok && $newStatus === 'delivered') {
        // Check if notifications table exists
        $check = $conn->query("SHOW TABLES LIKE 'notifications'");
        if ($check && $check->num_rows > 0) {
            // Get order details
            $order_info = $conn->query("SELECT o.*, u.name as buyer_name, u.email as buyer_email
                                        FROM orders o
                                        JOIN users u ON o.user_id = u.id
                                        WHERE o.id = $orderId LIMIT 1")->fetch_assoc();
            
            if ($order_info) {
                // Insert notification for buyer
                $message = "Order #$orderId has been delivered successfully!";
                $stmt = $conn->prepare("INSERT INTO notifications (user_id, message, type, created_at) VALUES (?, ?, 'order_delivered', NOW())");
                $stmt->bind_param("is", $order_info['user_id'], $message);
                $stmt->execute();
                $stmt->close();
                
                // Notify farmer
                $farmer_msg = "Your order #$orderId to {$order_info['buyer_name']} has been delivered!";
                $conn->query("INSERT INTO notifications (user_id, message, type, created_at) 
                             SELECT DISTINCT p.farmer_id, '$farmer_msg', 'order_delivered', NOW() 
                             FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = $orderId");
            }
        }
    }
    
    $conn->close();

    if ($ok) {
        echo 'success';
    } else {
        http_response_code(500);
        echo 'Failed to update order status.';
    }
    exit();
}

// --- Fetch Pending/Processing Orders for Delivery ---
$pendingOrders = [];

// Check if phone_number and address columns exist
$columns_check = $conn->query("SHOW COLUMNS FROM users LIKE 'phone_number'");
$has_phone = $columns_check->num_rows > 0;
$columns_check = $conn->query("SHOW COLUMNS FROM users LIKE 'address'");
$has_address = $columns_check->num_rows > 0;
$columns_check = $conn->query("SHOW COLUMNS FROM orders LIKE 'delivery_address'");
$has_delivery_address = $columns_check->num_rows > 0;
$columns_check = $conn->query("SHOW COLUMNS FROM orders LIKE 'delivery_partner_id'");
$has_delivery_partner_col = $columns_check->num_rows > 0;

$phone_field = $has_phone ? 'u.phone_number' : "''";
$address_field = $has_address ? 'u.address' : "''";
$delivery_address_field = $has_delivery_address ? 'o.delivery_address' : "''";

if ($has_delivery_partner_col) {
    $sqlPending = "SELECT o.id as order_id, o.order_date, o.total_amount, o.status,
                          u.name as customer_name, u.email as customer_email, 
                          $phone_field as customer_phone,
                          $address_field as user_address,
                          $delivery_address_field as delivery_address,
                          GROUP_CONCAT(p.name, ' (', oi.quantity, ' ', p.unit, ')') as items_summary,
                          p.location as product_location
                   FROM orders o
                   JOIN users u ON o.user_id = u.id
                   JOIN order_items oi ON o.id = oi.order_id
                   JOIN products p ON oi.product_id = p.id
                   WHERE o.status IN ('pending', 'processing', 'shipped') 
                   AND o.status != 'delivered'
                   AND o.delivery_partner_id = ?
                   GROUP BY o.id
                   ORDER BY o.order_date DESC";
    $stmtPending = $conn->prepare($sqlPending);
    $stmtPending->bind_param("i", $userId);
    $stmtPending->execute();
    $resultPending = $stmtPending->get_result();
} else {
    $sqlPending = "SELECT o.id as order_id, o.order_date, o.total_amount, o.status,
                          u.name as customer_name, u.email as customer_email, 
                          $phone_field as customer_phone,
                          $address_field as user_address,
                          $delivery_address_field as delivery_address,
                          GROUP_CONCAT(p.name, ' (', oi.quantity, ' ', p.unit, ')') as items_summary,
                          p.location as product_location
                   FROM orders o
                   JOIN users u ON o.user_id = u.id
                   JOIN order_items oi ON o.id = oi.order_id
                   JOIN products p ON oi.product_id = p.id
                   WHERE o.status IN ('pending', 'processing', 'shipped') AND o.status != 'delivered'
                   GROUP BY o.id
                   ORDER BY o.order_date DESC";
    $resultPending = $conn->query($sqlPending);
}

if ($resultPending) {
    while ($row = $resultPending->fetch_assoc()) {
        $row['customer_address'] = $row['delivery_address'] ?: $row['user_address'];
        $pendingOrders[] = $row;
    }
    if ($has_delivery_partner_col) $stmtPending->close();
} else {
    error_log("SQL Error fetching pending orders: " . $conn->error);
}


// --- Fetch Completed/Delivered Orders ---
$completedOrders = [];
if ($has_delivery_partner_col) {
    $sqlCompleted = "SELECT o.id as order_id, o.order_date, o.total_amount, o.status,
                            u.name as customer_name, u.email as customer_email, 
                            $phone_field as customer_phone,
                            GROUP_CONCAT(p.name, ' (', oi.quantity, ' ', p.unit, ')') as items_summary
                     FROM orders o
                     JOIN users u ON o.user_id = u.id
                     JOIN order_items oi ON o.id = oi.order_id
                     JOIN products p ON oi.product_id = p.id
                     WHERE o.status = 'delivered'
                     AND o.delivery_partner_id = ?
                     GROUP BY o.id
                     ORDER BY o.order_date DESC";
    $stmtCompleted = $conn->prepare($sqlCompleted);
    $stmtCompleted->bind_param("i", $userId);
    $stmtCompleted->execute();
    $resultCompleted = $stmtCompleted->get_result();
} else {
    $sqlCompleted = "SELECT o.id as order_id, o.order_date, o.total_amount, o.status,
                            u.name as customer_name, u.email as customer_email, 
                            $phone_field as customer_phone,
                            GROUP_CONCAT(p.name, ' (', oi.quantity, ' ', p.unit, ')') as items_summary
                     FROM orders o
                     JOIN users u ON o.user_id = u.id
                     JOIN order_items oi ON o.id = oi.order_id
                     JOIN products p ON oi.product_id = p.id
                     WHERE o.status = 'delivered'
                     GROUP BY o.id
                     ORDER BY o.order_date DESC";
    $resultCompleted = $conn->query($sqlCompleted);
}

if ($resultCompleted) {
    while ($row = $resultCompleted->fetch_assoc()) {
        $completedOrders[] = $row;
    }
    if ($has_delivery_partner_col) $stmtCompleted->close();
} else {
    error_log("SQL Error fetching completed orders: " . $conn->error);
}


$deliveryNotifications = $pendingOrders;
$showRedDot = count($deliveryNotifications) > 0;

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($userRole); ?> - AgroConnect Delivery Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        /* Reset and Base Styles */
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #e8f5e8 0%, #f0f9f0 100%);
            min-height: 100vh;
            color: #333;
            margin: 0;
        }

        .header {
            background: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 1rem;
            font-size: 1.5rem;
            font-weight: bold;
            color: #2d5a2d;
            margin-right: 2rem;
        }

        .logo img {
            width: 38px;
            height: 38px;
        }

        /* Header Icons  */
        .header-icons {
            display: flex;
            align-items: center;
            gap: 1rem; 
            margin-left: auto;
            position: relative;
        }

        #notif-dot {
            position: absolute;
            right: 8px;
            top: 7px;
            width: 12px;
            height: 12px;
            background: #e53935;
            border-radius: 50%;
            border: 2px solid #fff;
            display: <?php echo $showRedDot ? 'block' : 'none'; ?>;
            z-index: 2;
        }

        /* Styles for navigation links */
        .nav-links {
            display: flex;
            gap: 2rem;
            list-style: none;
            margin: 0; /* Remove default margin */
            padding: 0; /* Remove default padding */
        }

        .nav-links a {
            text-decoration: none;
            color: #666;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .nav-links a:hover {
            color: rgb(74, 171, 74);
        }

        @media (max-width: 768px) {
            .nav-links {
                display: none; 
            }
        }

        /* Styles for the logout button */
        .btn-logout {
            background: #dc3545;
            color: white;
            border: none;
            padding: 0.5rem 1.5rem;
            border-radius: 25px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }

        .btn-logout:hover {
            background: #c82333;
            transform: translateY(-2px);
        }

        /* Notification Popup */
        .notification-popup {
            display: none;
            position: fixed;
            top: 70px; /* Adjust as needed */
            right: 48px; /* Adjust as needed */
            width: 320px;
            background: #fff;
            border-radius: 14px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.13);
            z-index: 1200;
            animation: popup-fade 0.25s;
        }

        @keyframes popup-fade {
            from { opacity: 0; transform: translateY(-24px);}
            to { opacity: 1; transform: translateY(0);}
        }

        .popup-header {
            font-size: 1.15rem;
            font-weight: bold;
            color: #256129;
            padding: 16px 20px 12px 20px;
            border-bottom: 1px solid #e8f5e8;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .popup-close {
            font-size: 1.4rem;
            cursor: pointer;
            color: #888;
            padding: 2px 8px;
            border-radius: 4px;
        }

        .popup-close:hover {
            background: #eaeaea;
        }

        .notification-list {
            list-style: none;
            margin: 0;
            padding: 0 0 10px 0;
            max-height: 270px;
            overflow-y: auto;
        }

        .notification-list li {
            padding: 14px 20px 10px 20px;
            border-bottom: 1px solid #f4f4f4;
            font-size: 0.97rem;
            display: flex;
            flex-direction: column;
        }

        .notification-list li:last-child {
            border-bottom: none;
        }

        .notif-title {
            color: #255729;
            font-weight: 500;
        }

        .notif-time {
            color: #aaa;
            font-size: 0.85em;
            margin-top: 2px;
        }

        /* Main Content Styles */
        .container {
            max-width: 900px;
            margin: 2rem auto;
            padding: 0 1rem;
        }

        .dashboard-header {
            margin-bottom: 2rem;
        }

        .dashboard-title {
            font-size: 2rem;
            color: #2d5a2d;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .dashboard-title::before {
            content: "🚚"; /* Delivery icon */
            font-size: 2rem;
        }

        .section {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
            border: 1px solid #e8f5e8;
        }

        .section-title {
            font-size: 1.3rem;
            color: #2d5a2d;
            margin-bottom: 1.5rem;
            font-weight: 600;
        }

        .order-card {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            border-left: 4px solid #007bff; /* Blue for pending/processing */
        }

        .order-card.completed {
            border-left: 4px solid #28a745; /* Green for completed */
            background: #e8f5e8;
        }

        .order-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1rem;
        }

        .order-title {
            font-size: 1.1rem;
            font-weight: bold;
            color: #007bff; /* Blue for order titles */
            margin-bottom: 0.5rem;
        }

        .order-card.completed .order-title {
            color: #28a745; /* Green for completed order titles */
        }

        .order-meta {
            color: #666;
            font-size: 0.9rem;
            margin-bottom: 1rem;
        }

        .order-details {
            color: #333;
            margin-bottom: 1rem;
            line-height: 1.5;
        }

        .order-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 1rem;
        }

        .action-btn {
            background: #007bff;
            color: white;
            border: none;
            padding: 0.75rem 1.2rem;
            border-radius: 25px;
            cursor: pointer;
            font-weight: 500;
            font-size: 0.95rem;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .action-btn.map { background: #6f42c1; } /* Purple */
        .action-btn.contact { background: #ffc107; color: #333; } /* Yellow */
        .action-btn.delivered { background: #28a745; } /* Green */
        .action-btn:hover { transform: translateY(-2px); opacity: 0.9; }
        .action-btn:disabled { background: #ccc; cursor: not-allowed; }

        .empty-state {
            text-align: center;
            padding: 3rem;
            color: #666;
        }

        .empty-state-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
        }

        .footer {
            background: #2d5a2d;
            color: white;
            text-align: center;
            padding: 2rem;
            margin-top: 3rem;
        }

        @media (max-width: 768px) {
            .dashboard-title {
                font-size: 1.5rem;
            }
            .order-header {
                flex-direction: column;
                gap: 1rem;
            }
            .action-btn {
                width: 100%;
                justify-content: center;
            }
            .notification-popup {
                right: 20px;
            }
        }

    </style>
</head>
<body>
    <header class="header">
        <nav class="nav">
            <div class="logo">
                <img src="logo.png" alt="AgroConnect Logo">
                <span>AgroConnect</span>
            </div>
            <ul class="nav-links">
                <li><a href="home.php">Home</a></li>
                <li><a href="features.php">Features</a></li>
                <li><a href="marketplace.php">Marketplace</a></li>
                <li><a href="crop-health.php">Crop Health</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="map.php">Map</a></li>
            </ul>
            <div class="header-icons">
                <a href="javascript:void(0);" title="Notifications" style="display: flex; align-items: center; position:relative;"
                id="notif-bell" onclick="showNotificationPopup()">
                    <img src="notification.png" alt="Notifications" style="width:38px; height:38px; cursor:pointer;">
                    <span id="notif-dot"></span>
                </a>
                <span style="color: #2d5a2d; font-weight: bold; margin-right: 10px;">Welcome, <?php echo htmlspecialchars($userName); ?>!</span>
                <a href="logout.php" class="btn btn-logout">Logout</a>
            </div>
        </nav>
    </header>

    <div class="container">
        <div class="dashboard-header">
            <h1 class="dashboard-title">Delivery Dashboard</h1>
        </div>

        <section class="section">
            <h2 class="section-title">Pending & In-Transit Deliveries</h2>
            <?php if (count($pendingOrders) > 0): ?>
                <?php foreach ($pendingOrders as $order): ?>
                    <?php
                    $orderId = htmlspecialchars($order['order_id']);
                    $customerName = htmlspecialchars($order['customer_name']);
                    $customerEmail = htmlspecialchars($order['customer_email']);
                    $customerPhone = $order['customer_phone'] ?? '';
                    $customerAddress = $order['customer_address'] ?? '';
                    $missingDetails = empty($customerPhone) || empty($customerAddress);
                    $customerPhone = htmlspecialchars($customerPhone ?: 'Not Provided');
                    $customerAddress = htmlspecialchars($customerAddress ?: 'Not Provided');
                    $totalAmount = htmlspecialchars(number_format($order['total_amount'], 2));
                    $orderStatus = htmlspecialchars(ucfirst($order['status']));
                    $orderDate = new DateTime($order['order_date']);
                    $formattedDate = $orderDate->format('M d, Y H:i');
                    $itemsSummary = htmlspecialchars($order['items_summary']);
                    $pickupLocation = htmlspecialchars($order['product_location'] ?? 'N/A');
                    ?>
                    <div class="order-card" data-order-id="<?= $orderId ?>">
                        <?php if($missingDetails): ?>
                        <div style="background: #fff3cd; border: 2px solid #ffc107; padding: 1rem; border-radius: 8px; margin-bottom: 1rem;">
                            <strong style="color: #856404;"><i class="fas fa-exclamation-triangle"></i> Customer Details Missing!</strong>
                            <p style="color: #856404; margin-top: 0.5rem;">Customer needs to provide <?= empty($order['customer_phone']) ? 'phone number' : '' ?><?= empty($order['customer_phone']) && empty($order['customer_address']) ? ' and ' : '' ?><?= empty($order['customer_address']) ? 'delivery address' : '' ?> before delivery can proceed.</p>
                        </div>
                        <?php endif; ?>
                        <div class="order-header">
                            <div>
                                <div class="order-title">Order #<?= $orderId ?> (Status: <?= $orderStatus ?>)</div>
                                <div class="order-meta">
                                    Customer: <?= $customerName ?> (<?= $customerEmail ?>) • Placed: <?= $formattedDate ?>
                                </div>
                                <div class="order-details">
                                    <strong>Items:</strong> <?= $itemsSummary ?><br>
                                    <strong>Total:</strong> Rs. <?= $totalAmount ?><br>
                                    <strong>Pickup Location:</strong> <?= $pickupLocation ?><br>
                                    <strong>Delivery Address:</strong> <span style="<?= empty($order['customer_address']) ? 'color: #dc3545; font-weight: bold;' : '' ?>"><?= $customerAddress ?></span><br>
                                    <strong>Customer Phone:</strong> <span style="<?= empty($order['customer_phone']) ? 'color: #dc3545; font-weight: bold;' : '' ?>"><?= $customerPhone ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="order-actions">
                            <button class="action-btn map" onclick="viewOnMap('<?= $pickupLocation ?>', '<?= $customerAddress ?>')" <?= $missingDetails ? 'disabled title="Customer details required"' : '' ?>>
                                <i class="fas fa-map-marker-alt"></i> View on Map
                            </button>
                            <button class="action-btn contact" onclick="callBuyer('<?= $customerName ?>', '<?= $customerPhone ?>')" <?= empty($order['customer_phone']) ? 'disabled title="Phone number not provided"' : '' ?>>
                                <i class="fas fa-phone"></i> Call Buyer
                            </button>
                            <?php if ($order['status'] !== 'delivered'): ?>
                                <button class="action-btn" onclick="<?= $missingDetails ? 'alert(\"Cannot proceed: Customer must provide address and phone number first\")' : 'updateOrderStatus(\''. $orderId . '\', \'shipped\', this)' ?>"
                                style="background:#17a2b8;" <?= $missingDetails ? 'disabled' : '' ?>>
                                    <i class="fas fa-shipping-fast"></i> Mark as Shipped
                                </button>
                                <button class="action-btn delivered" onclick="<?= $missingDetails ? 'alert(\"Cannot proceed: Customer must provide address and phone number first\")' : 'updateOrderStatus(\''. $orderId . '\', \'delivered\', this)' ?>" <?= $missingDetails ? 'disabled' : '' ?>>
                                    <i class="fas fa-check-circle"></i> Mark as Delivered
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-state-icon">📦</div>
                    No pending or in-transit deliveries.
                </div>
            <?php endif; ?>
        </section>

        <section class="section completed">
            <h2 class="section-title">Completed Deliveries</h2>
            <?php if (count($completedOrders) > 0): ?>
                <?php foreach ($completedOrders as $order): ?>
                    <?php
                    $orderId = htmlspecialchars($order['order_id']);
                    $customerName = htmlspecialchars($order['customer_name']);
                    $totalAmount = htmlspecialchars(number_format($order['total_amount'], 2));
                    $orderStatus = htmlspecialchars(ucfirst($order['status']));
                    $orderDate = new DateTime($order['order_date']);
                    $formattedDate = $orderDate->format('M d, Y H:i');
                    $itemsSummary = htmlspecialchars($order['items_summary']);
                    ?>
                    <div class="order-card completed" data-order-id="<?= $orderId ?>">
                        <div class="order-header">
                            <div>
                                <div class="order-title">Order #<?= $orderId ?> (Status: <?= $orderStatus ?>)</div>
                                <div class="order-meta">
                                    Customer: <?= $customerName ?> • Placed: <?= $formattedDate ?>
                                </div>
                                <div class="order-details">
                                    <strong>Items:</strong> <?= $itemsSummary ?><br>
                                    <strong>Total:</strong> Rs. <?= $totalAmount ?>
                                </div>
                            </div>
                        </div>
                        </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-state-icon">✅</div>
                    No completed deliveries yet.
                </div>
            <?php endif; ?>
        </section>
    </div>

    <div id="notification-popup" class="notification-popup">
        <div class="popup-header">
            New Pending Deliveries
            <span class="popup-close" onclick="closeNotificationPopup()">×</span>
        </div>
        <ul class="notification-list" id="notification-list">
            <?php
            if (empty($deliveryNotifications)) {
                echo "<li><span class='notif-title'>No new pending deliveries</span></li>";
            } else {
                foreach ($deliveryNotifications as $notif) {
                    echo "<li>
                                <span class='notif-title'>New order #{$notif['order_id']} for {$notif['customer_name']}</span>
                                <span class='notif-time'>".date('M d, H:i', strtotime($notif['order_date']))."</span>
                              </li>";
                }
            }
            ?>
        </ul>
    </div>

    <footer class="footer">
        <p>© 2025 AgroConnect. All rights reserved 🧡</p>
    </footer>

    <script>
        // Notification popup functions farmer.php and foodtester.php
        function showNotificationPopup() {
            document.getElementById('notification-popup').style.display = 'block';
            document.getElementById('notif-dot').style.display = 'none'; // Mark as read visually
            document.body.style.overflow = 'hidden';
           
        }

        function closeNotificationPopup() {
            document.getElementById('notification-popup').style.display = 'none';
            document.body.style.overflow = 'auto';
        }

        // Close popup with ESC key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeNotificationPopup();
            }
        });

        // Close popup if click outside
        window.onclick = function(event) {
            const popup = document.getElementById('notification-popup');
            const bell = document.getElementById('notif-bell');
            if (popup && popup.style.display === 'block' && !popup.contains(event.target) && !bell.contains(event.target)) {
                closeNotificationPopup();
            }
        };

        function viewOnMap(pickupLocation, deliveryAddress) {
            if (pickupLocation && deliveryAddress && deliveryAddress !== 'Not Provided') {
                // Open Google Maps with directions
                const url = `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(pickupLocation)}&destination=${encodeURIComponent(deliveryAddress)}&travelmode=driving`;
                window.open(url, '_blank');
            } else {
                alert('Delivery address not available. Customer needs to provide address first.');
            }
        }
        
        function callBuyer(buyerName, buyerPhone) {
            if (buyerPhone && buyerPhone !== 'Not Provided') {
                window.location.href = `tel:${buyerPhone}`;
            } else {
                alert('Buyer phone number not available.');
            }
        }

        function updateOrderStatus(orderId, newStatus, btn) {
            const originalText = btn.textContent;
            btn.textContent = 'Updating...';
            btn.disabled = true;
            btn.style.opacity = '0.7';

            fetch(window.location.pathname, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `order_id=${encodeURIComponent(orderId)}&status=${encodeURIComponent(newStatus)}`
            })
            .then(response => response.text())
            .then(text => {
                if (text === 'success') {
                    btn.textContent = `✅ ${newStatus.charAt(0).toUpperCase() + newStatus.slice(1)}`;
                    btn.style.background = '#28a745'; // Green on success
                    setTimeout(() => {
                        alert(`Order #${orderId} marked as ${newStatus}!`);
                        location.reload(); 
                    }, 500);
                } else {
                    btn.textContent = originalText;
                    btn.disabled = false;
                    btn.style.opacity = '1';
                    alert(`Failed to update status for Order #${orderId}. Error: ${text}`);
                }
            })
            .catch(error => {
                console.error('Error updating status:', error);
                btn.textContent = originalText;
                btn.disabled = false;
                btn.style.opacity = '1';
                alert('An error occurred while updating status. Please try again.');
            });
        }



    </script>
</body>
</html>