<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    
    $stmt = $conn->prepare("UPDATE users SET phone_number = ?, address = ? WHERE id = ?");
    $stmt->bind_param("ssi", $phone, $address, $user_id);
    
    if ($stmt->execute()) {
        $message = '<div class="alert success">Profile updated successfully!</div>';
    } else {
        $message = '<div class="alert error">Failed to update profile.</div>';
    }
}

$stmt = $conn->prepare("SELECT name, email, phone_number as phone, address FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Profile - AgroConnect</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .alert { padding: 1rem; border-radius: 8px; margin-bottom: 1rem; }
        .alert.success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert.error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
    </style>
</head>
<body class="bg-gray-50">
    <div class="max-w-2xl mx-auto p-6">
        <div class="bg-white rounded-lg shadow-lg p-8">
            <h1 class="text-3xl font-bold text-green-800 mb-6">
                <i class="fas fa-user-edit"></i> Update Profile
            </h1>
            
            <?= $message ?>
            
            <form method="POST" class="space-y-6">
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Name</label>
                    <input type="text" value="<?= htmlspecialchars($user['name']) ?>" class="w-full px-4 py-3 border rounded-lg bg-gray-100" disabled>
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">Email</label>
                    <input type="email" value="<?= htmlspecialchars($user['email']) ?>" class="w-full px-4 py-3 border rounded-lg bg-gray-100" disabled>
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">
                        Phone Number <span class="text-red-600">*</span>
                        <?php if(empty($user['phone'])): ?>
                        <span class="text-red-600 text-sm">(Required for delivery)</span>
                        <?php endif; ?>
                    </label>
                    <input type="tel" name="phone" value="<?= htmlspecialchars($user['phone'] ?? '') ?>" 
                           class="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-green-500" 
                           placeholder="Enter your phone number" required>
                </div>
                
                <div>
                    <label class="block text-gray-700 font-semibold mb-2">
                        Delivery Address <span class="text-red-600">*</span>
                        <?php if(empty($user['address'])): ?>
                        <span class="text-red-600 text-sm">(Required for delivery)</span>
                        <?php endif; ?>
                    </label>
                    <textarea name="address" rows="4" 
                              class="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-green-500" 
                              placeholder="Enter your complete delivery address" required><?= htmlspecialchars($user['address'] ?? '') ?></textarea>
                </div>
                
                <div class="flex gap-4">
                    <button type="submit" class="flex-1 px-6 py-3 bg-green-600 text-white font-bold rounded-lg hover:bg-green-700">
                        <i class="fas fa-save"></i> Save Changes
                    </button>
                    <a href="buyer.php" class="flex-1 px-6 py-3 bg-gray-600 text-white font-bold rounded-lg hover:bg-gray-700 text-center">
                        <i class="fas fa-arrow-left"></i> Back
                    </a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
