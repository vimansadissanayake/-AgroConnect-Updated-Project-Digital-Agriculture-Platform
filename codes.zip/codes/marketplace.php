<?php
// marketplace.php - Public Product Listing

// Database connection details (from buyer.php)
$servername = "localhost";
$username_db = "root";
$password_db = ""; // Your MySQL password
$dbname = "vimansa"; // Your database name

// Establish connection for fetching data
$conn = new mysqli($servername, $username_db, $password_db, $dbname);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Fetch products from the database
$products = [];
// Changed 'image_url' to 'image_path' in SELECT query (from buyer.php)
$sql_products = "SELECT id, name, price, unit, stock_quantity, image_path, category, location, farmer_id FROM products ORDER BY name ASC";
$result_products = $conn->query($sql_products);
if ($result_products->num_rows > 0) {
    while ($row = $result_products->fetch_assoc()) {
        $products[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marketplace - AgroConnect</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Import Google Font - Poppins (from aboutus.php) */
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f1ffeb;
        }
        
        /* Card hover effects (from marketplace.html) */
        .product-card:hover {
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        /* Smooth transitions for interactive elements (from marketplace.html) */
        .transition-all {
            transition: all 0.3s ease;
        }

        /* Custom styles for mobile menu toggle (from aboutus.php) */
        #mobile-menu {
            display: none;
        }
        #mobile-menu.active {
            display: block;
        }
        
        /* Product image handling */
        .product-image {
            width: 100%; height: 200px;
            background: #f8f9fa;
            display: flex; align-items: center; justify-content: center;
            font-size: 3rem; color: #666;
            overflow: hidden; /* Ensure image doesn't overflow */
        }
        .product-image img {
            width: 100%; /* Make image fill the container */
            height: 100%; /* Make image fill the container */
            object-fit: cover; /* Cover the area, cropping if necessary */
            border-radius: 12px; /* Apply border-radius to the image itself */
        }
        /* Search and filter styles */
        .search-bar {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            justify-content: center; /* Center items on smaller screens */
        }
        .search-input {
            flex: 1;
            padding: 0.75rem;
            border: 2px solid #e8f5e8;
            border-radius: 25px;
            font-size: 1rem;
            min-width: 250px;
        }
        .search-input:focus { outline: none; border-color: #2d5a2d; }
        .filter-select {
            padding: 0.75rem 1rem;
            border: 2px solid #e8f5e8;
            border-radius: 25px;
            background: white;
            cursor: pointer;
            min-width: 150px;
        }
        .filter-btn {
            background: #2d5a2d;
            color: white;
            padding: 0.75rem 2rem;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .filter-btn:hover { background: #1a3d1a; transform: translateY(-2px); }
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .search-bar { flex-direction: column; align-items: center; }
            .search-input, .filter-select, .filter-btn { width: 100%; }
        }
    </style>
</head>
<body>
    <!-- Navigation Bar (Copied from aboutus.php for consistency) -->
    <nav class="bg-white shadow-md sticky top-0 z-50">
        <div class="container mx-auto px-6 py-3">
            <div class="flex items-center justify-between">
                <div class="flex items-center">
                    <img src="logo.png" alt="AgroConnect Logo" class="w-15 h-10 mr-2">
                    <span class="text-xl font-bold text-green-800">AgroConnect</span>
                </div>
                <div class="hidden md:flex items-center space-x-8">
                    <a href="home.php" class="text-gray-600 hover:text-green-600 font-medium">Home</a>
                    <a href="features.php" class="text-gray-600 hover:text-green-600 font-medium">Features</a>
                    <a href="marketplace.php" class="text-green-700 font-bold">Marketplace</a>
                    <a href="crophealth.php" class="text-gray-600 hover:text-green-600 font-medium">Crop Health</a>
                    <a href="aboutus.php" class="text-gray-600 hover:text-green-600 font-medium">About</a> 
                    <a href="profile.php" class="text-gray-600 hover:text-green-600 font-medium">Profile</a>
                    <a href="map.php" class="text-gray-600 hover:text-green-600 font-medium">Map</a>
                </div>
                <div class="flex items-center space-x-4">
                    <!-- Check if user is logged in (simplified for marketplace) -->
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <span class="text-green-700 font-bold">Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</span>
                        <a href="logout.php" class="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-all">Logout</a>
                    <?php else: ?>
                        <a href="login.php" class="px-4 py-2 text-green-700 border border-green-700 rounded-md hover:bg-green-50 transition-all">
                            Login
                        </a>
                        <a href="register.php" class="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-all">
                            Register
                        </a>
                    <?php endif; ?>
                    <button id="mobile-menu-button" class="md:hidden text-gray-600 focus:outline-none">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                </div>
            </div>
            <div id="mobile-menu" class="md:hidden mt-4 bg-white rounded-md shadow-lg py-2">
                <a href="home.php" class="block px-4 py-2 text-gray-800 hover:bg-gray-100">Home</a>
                <a href="features.php" class="block px-4 py-2 text-gray-800 hover:bg-gray-100">Features</a>
                <a href="marketplace.php" class="block px-4 py-2 text-green-700 font-bold hover:bg-gray-100">Marketplace</a>
                <a href="crophealth.php" class="block px-4 py-2 text-gray-800 hover:bg-gray-100">Crop Health</a>
                <a href="aboutus.php" class="block px-4 py-2 text-gray-800 hover:bg-gray-100">About</a>
                <a href="profile.php" class="block px-4 py-2 text-gray-800 hover:bg-gray-100">Profile</a>
                <a href="map.php" class="block px-4 py-2 text-gray-800 hover:bg-gray-100">Map</a>
            </div>
        </div>
    </nav>

    <!-- Marketplace Section -->
    <section id="marketplace" class="py-16 bg-gray-50">
        <div class="container mx-auto px-6">
            <div class="flex flex-col md:flex-row justify-between items-center mb-12 text-center md:text-left">
                <div>
                    <h2 class="text-3xl font-bold text-gray-800 mb-2">Fresh From the Farm</h2>
                    <p class="text-gray-600">Browse our marketplace for the freshest produce available</p>
                </div>
                <!-- This link can lead to buyer dashboard if user is logged in, or remain as is -->
                <a href="register.php" class="mt-4 md:mt-0 px-6 py-2 border border-green-600 text-green-600 rounded-md hover:bg-green-600 hover:text-white transition-all">
                    View all products in Buyer Dashboard
                </a>
            </div>

            <!-- Search and Filter Bar -->
            <div class="search-bar">
                <input type="text" class="search-input" id="search-input" placeholder="Search crops (e.g., tomatoes, apples)..." onkeyup="filterProducts()">
                <select class="filter-select" id="category-filter" onchange="filterProducts()">
                    <option value="">All Categories</option>
                    <option value="Vegetables">Vegetables</option>
                    <option value="Fruits">Fruits</option>
                    <option value="Grains">Grains</option>
                    <option value="Dairy">Dairy</option>
                    <option value="Spices">Spices</option>
                    <option value="Herbs">Herbs</option>
                    <option value="Other">Other</option>
                </select>
                <select class="filter-select" id="location-filter" onchange="filterProducts()">
                  <option value="">All Locations</option>
                    <option value="Ampara">Ampara</option>
                    <option value="Anuradhapura">Anuradhapura</option>
                    <option value="Badulla">Badulla</option>
                    <option value="Batticaloa">Batticaloa</option>
                    <option value="Colombo">Colombo</option>
                    <option value="Galle">Galle</option>
                    <option value="Gampaha">Gampaha</option>
                    <option value="Hambantota">Hambantota</option>
                    <option value="Jaffna">Jaffna</option>
                    <option value="Kalutara">Kalutara</option>
                    <option value="Kandy">Kandy</option>
                    <option value="Kegalle">Kegalle</option>
                    <option value="Kilinochchi">Kilinochchi</option>
                    <option value="Kurunegala">Kurunegala</option>
                    <option value="Mannar">Mannar</option>
                    <option value="Matale">Matale</option>
                    <option value="Matara">Matara</option>
                    <option value="Monaragala">Monaragala</option>
                    <option value="Mullaitivu">Mullaitivu</option>
                    <option value="Nuwara Eliya">Nuwara Eliya</option>
                    <option value="Polonnaruwa">Polonnaruwa</option>
                    <option value="Puttalam">Puttalam</option>
                    <option value="Ratnapura">Ratnapura</option>
                    <option value="Trincomalee">Trincomalee</option>
                    <option value="Vavuniya">Vavuniya</option>
                </select>
                <!--<button class="filter-btn" onclick="filterProducts()">Filter</button>-->
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6" id="products-grid">
                <!-- Products will be loaded here by JavaScript -->
                <?php if (empty($products)): ?>
                    <div class="col-span-full text-center text-gray-600 py-10">No products available at the moment. Please check back later!</div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Footer (Copied from aboutus.php for consistency) -->
    <footer class="bg-green-900 text-white py-8">
        <div class="container mx-auto px-6 text-center">
            <p>© 2025 AgroConnect. All rights reserved <i class="fas fa-heart text-yellow-500 "></i></p>
        </div>
    </footer>

    <script>
        // JavaScript for mobile menu toggle (from aboutus.php)
        document.getElementById('mobile-menu-button').addEventListener('click', function() {
            const mobileMenu = document.getElementById('mobile-menu');
            mobileMenu.classList.toggle('active');
        });

        // PHP products data passed to JavaScript (from buyer.php)
        const allProducts = <?php echo json_encode($products); ?>;
        
        // Function to render products dynamically (adapted from buyer.php)
        function renderProducts(productsToRender) {
            const productsGrid = document.getElementById('products-grid');
            let productsHTML = '';
            if (productsToRender.length === 0) {
                productsHTML = '<div class="col-span-full text-center text-gray-600 py-10">No products found matching your criteria.</div>';
            } else {
                productsToRender.forEach(product => {
                    // Use product.image_path (from DB) or fallback
                    const imageUrl = product.image_path ? product.image_path : 'https://placehold.co/90x90/EBFBEE/2F855A?text=No+Image';
                    const fallbackEmoji = getEmojiForCategory(product.category);
                    productsHTML += `
                        <div class="bg-white rounded-lg overflow-hidden shadow-md product-card transition-all">
                            <div class="relative h-48 overflow-hidden product-image">
                                <img src="${imageUrl}" alt="${product.name}" onerror="this.onerror=null;this.src='${imageUrl}'; this.parentNode.innerHTML='<span class=\'text-6xl\'>${fallbackEmoji}</span>';">
                            </div>
                            <div class="p-4">
                                <h3 class="font-bold text-lg mb-1">${product.name}</h3>
                                <p class="text-gray-600 text-sm mb-2">From ${product.location}</p>
                                <div class="flex justify-between items-center">
                                    <span class="font-bold text-green-600">Rs ${parseFloat(product.price).toFixed(2)}/${product.unit}</span>
                                    <!-- Add to cart button is removed as per request -->
                                </div>
                                <div class="text-gray-500 text-xs mt-2">Stock: ${parseFloat(product.stock_quantity).toFixed(2)} ${product.unit}</div>
                            </div>
                        </div>
                    `;
                });
            }
            productsGrid.innerHTML = productsHTML;
        }

        // Helper function for category emojis (from buyer.php)
        function getEmojiForCategory(category) {
            switch (category) {
                case 'Vegetables': return '🥕';
                case 'Fruits': return '🍎';
                case 'Grains': return '🌾';
                case 'Dairy': return '🥛';
                case 'Spices': return '🌶️';
                case 'Herbs': return '🌿';
                default: return '📦';
            }
        }

        // Filter products function (from buyer.php)
        function filterProducts() {
            const searchTerm = document.getElementById('search-input').value.toLowerCase();
            const categoryFilter = document.getElementById('category-filter').value;
            const locationFilter = document.getElementById('location-filter').value;

            const filtered = allProducts.filter(product => {
                const matchesSearch = product.name.toLowerCase().includes(searchTerm);
                const matchesCategory = categoryFilter === "" || product.category === categoryFilter;
                const matchesLocation = locationFilter === "" || product.location === locationFilter;
                return matchesSearch && matchesCategory && matchesLocation;
            });
            renderProducts(filtered);
        }
        
        // Load products when the page loads
        window.onload = function() {
            renderProducts(allProducts);
        };
    </script>
</body>
</html>
