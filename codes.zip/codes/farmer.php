<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Database connection details
$servername = "localhost";
$username_db = "root";
$password_db = ""; 
$dbname = "vimansa"; 

$userId = $_SESSION['user_id'];
$userName = $_SESSION['user_name'];
$userRole = $_SESSION['user_role'] ?? 'Farmer';

$uploadMessage = '';
$diseaseReportMessage = '';

// --- Product Upload Handling ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_name'])) {
    $productName = trim($_POST['product_name']);
    $price = $_POST['price'];
    $stockQuantity = $_POST['stock_quantity'];
    $unit = $_POST['unit'];
    $location = $_POST['location'];
    $category = $_POST['category'];
    $imagePath = NULL;

    $conn = new mysqli($servername, $username_db, $password_db, $dbname);
    if ($conn->connect_error) {
        $uploadMessage = "<span style='color:red;'>Database connection failed: " . $conn->connect_error . "</span>";
    } else {
        if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = 'uploads/';
            if (!file_exists($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }
            $fileName = basename($_FILES['product_image']['name']);
            $ext = pathinfo($fileName, PATHINFO_EXTENSION);
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

            if (in_array(strtolower($ext), $allowed)) {
                $newName = uniqid('img_', true) . '.' . $ext;
                $targetPath = $uploadDir . $newName;
                if (move_uploaded_file($_FILES['product_image']['tmp_name'], $targetPath)) {
                    $imagePath = $targetPath;
                } else {
                    $uploadMessage = "<span style='color:red;'>Failed to upload image.</span>";
                }
            } else {
                $uploadMessage = "<span style='color:red;'>Invalid image format. Allowed: jpg, jpeg, png, gif, webp.</span>";
            }
        } else if ($_FILES['product_image']['error'] !== UPLOAD_ERR_NO_FILE) {
            $uploadMessage = "<span style='color:red;'>Image upload error: " . $_FILES['product_image']['error'] . "</span>";
        }

        if (empty($uploadMessage)) {
            $stmt = $conn->prepare("INSERT INTO products (farmer_id, name, price, unit, stock_quantity, image_path, category, location) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("isdsisss", $userId, $productName, $price, $unit, $stockQuantity, $imagePath, $category, $location);

            if ($stmt->execute()) {
                $uploadMessage = "<span style='color:green;'>Product uploaded successfully!</span>";
            } else {
                $uploadMessage = "<span style='color:red;'>Database error: " . $stmt->error . "</span>";
            }
            $stmt->close();
        }
        $conn->close();
    }
}

// --- Disease Report Handling (popup modal) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['crop_type']) && !isset($_POST['product_name'])) {
    $cropType = trim($_POST['crop_type']);
    $symptoms = trim($_POST['symptoms']);
    $imagePath = NULL;

    $conn = new mysqli($servername, $username_db, $password_db, $dbname);
    if ($conn->connect_error) {
        $diseaseReportMessage = "<span style='color:red;'>Database connection failed: " . $conn->connect_error . "</span>";
    } else {
        if (isset($_FILES['disease_image']) && $_FILES['disease_image']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = 'uploads/';
            if (!file_exists($uploadDir)) mkdir($uploadDir, 0777, true);
            $fileName = basename($_FILES['disease_image']['name']);
            $ext = pathinfo($fileName, PATHINFO_EXTENSION);
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            if (in_array(strtolower($ext), $allowed)) {
                $newName = uniqid('disease_', true) . '.' . $ext;
                $targetPath = $uploadDir . $newName;
                if (move_uploaded_file($_FILES['disease_image']['tmp_name'], $targetPath)) {
                    $imagePath = $targetPath;
                } else {
                    $diseaseReportMessage = "<span style='color:red;'>Failed to upload disease image.</span>";
                }
            } else {
                $diseaseReportMessage = "<span style='color:red;'>Invalid disease image format. Allowed: jpg, jpeg, png, gif, webp.</span>";
            }
        } else if ($_FILES['disease_image']['error'] !== UPLOAD_ERR_NO_FILE) {
             $diseaseReportMessage = "<span style='color:red;'>Disease image upload error: " . $_FILES['disease_image']['error'] . "</span>";
        }

        if (empty($diseaseReportMessage)) {
            $stmt = $conn->prepare("INSERT INTO disease_reports (user_id, crop_type, symptoms, image_path) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("isss", $userId, $cropType, $symptoms, $imagePath);
            if ($stmt->execute()) {
                $diseaseReportMessage = "<span style='color:green;'>Disease report submitted!</span>";
            } else {
                $diseaseReportMessage = "<span style='color:red;'>Database error: " . $stmt->error . "</span>";
            }
            $stmt->close();
        }
        $conn->close();
    }
}

// Re-establish connection for fetching data after POST operations
$conn = new mysqli($servername, $username_db, $password_db, $dbname);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// --- Notifications: check for new diagnosis for this farmer ---
$diseaseNotifications = [];
$sqlNotif = "SELECT id, crop_type, symptoms, diagnosis, treatment_suggestion, created_at
             FROM disease_reports
             WHERE user_id=? AND diagnosis IS NOT NULL AND diagnosis!='' AND (seen_notification IS NULL OR seen_notification=0) ORDER BY created_at DESC";
$stmtNotif = $conn->prepare($sqlNotif);
$stmtNotif->bind_param("i", $userId);
$stmtNotif->execute();
$resultNotif = $stmtNotif->get_result();
while ($row = $resultNotif->fetch_assoc()) {
    $diseaseNotifications[] = $row;
}
$showRedDot = count($diseaseNotifications) > 0;
$stmtNotif->close();

// --- Disease Reports Table (all of user's reports) ---
$reports = [];
$sqlRep = "SELECT crop_type, symptoms, diagnosis, treatment_suggestion, created_at FROM disease_reports WHERE user_id=? ORDER BY created_at DESC";
$stmtRep = $conn->prepare($sqlRep);
$stmtRep->bind_param("i", $userId);
$stmtRep->execute();
$resultRep = $stmtRep->get_result();
while ($row = $resultRep->fetch_assoc()) {
    $reports[] = $row;
}
$stmtRep->close();

// --- Recent Listings (Products) ---
$products = [];
$sqlProducts = "SELECT name, stock_quantity, unit, price, category, image_path FROM products WHERE farmer_id=? ORDER BY id DESC LIMIT 10";
$stmtProducts = $conn->prepare($sqlProducts);
$stmtProducts->bind_param("i", $userId);
$stmtProducts->execute();
$resultProducts = $stmtProducts->get_result();
while ($row = $resultProducts->fetch_assoc()) {
    $products[] = $row;
}
$stmtProducts->close();

// --- Farmer's Orders (Orders placed for this farmer's products) ---
$farmerOrders = [];
$sqlFarmerOrders = "
    SELECT
        o.id AS order_id,
        o.order_date,
        o.total_amount,
        o.status,
        u.name AS buyer_name,
        GROUP_CONCAT(CONCAT(oi.quantity, ' ', p.unit, ' ', p.name) SEPARATOR '; ') AS ordered_items
    FROM orders o
    JOIN order_items oi ON o.id = oi.order_id
    JOIN products p ON oi.product_id = p.id
    JOIN users u ON o.user_id = u.id
    WHERE p.farmer_id = ?
    GROUP BY o.id, o.order_date, o.total_amount, o.status, u.name
    ORDER BY o.order_date DESC
    LIMIT 10";
$stmtFarmerOrders = $conn->prepare($sqlFarmerOrders);
$stmtFarmerOrders->bind_param("i", $userId);
$stmtFarmerOrders->execute();
$resultFarmerOrders = $stmtFarmerOrders->get_result();
while ($row = $resultFarmerOrders->fetch_assoc()) {
    $farmerOrders[] = $row;
}
$stmtFarmerOrders->close();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>AgroConnect Farmer Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<style>
body { font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif; background: linear-gradient(135deg, #e8f5e8 0%, #f0f9f0 100%); min-height: 100vh; color:#333; margin:0;}
.header { background: white; padding: 1rem 2rem; box-shadow: 0 2px 10px rgba(0,0,0,0.1); position: sticky; top: 0; z-index: 100;}
.nav { display: flex; justify-content: space-between; align-items: center; max-width: 1200px; margin: 0 auto;}
.logo {
    display: flex;
    align-items: center;
    gap: 1rem;
    font-size: 1.5rem;
    font-weight: bold;
    color: #2d5a2d;
    margin-right: 2rem; /* Added margin-right for spacing */
}
.logo img { width: 38px; height: 38px; }
.header-icons {
    display: flex;
    align-items: center;
    gap: 1rem; /* Adjusted to 1rem for consistent spacing */
    margin-left: auto;
    position: relative;
}
#notif-dot { position:absolute; right:8px; top:7px; width:12px; height:12px; background:#e53935; border-radius:50%; border:2px solid #fff; display: <?php echo $showRedDot ? 'block' : 'none'; ?>; z-index: 2; }
.main-actions {display:flex; justify-content:center; gap:1.2rem; margin:2.5rem 0;}
.action-btn {font-size:1.11rem; border:none; background:#f7fff7; color:#1c3b17; padding: 1.05rem 2rem; border-radius: 15px; font-weight: 600; box-shadow: 0 4px 12px rgba(30,80,30,0.08); cursor:pointer; transition:.15s; display:flex;align-items:center;gap:0.6rem;}
.action-btn:hover {background: #e4f6e3;}
.action-btn .icon {font-size:1.3rem;}
.modal { display: none; position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(0,0,0,0.22); z-index: 3000; align-items: center; justify-content: center;}
.modal.active { display: flex;}
.modal-content { background: white; border-radius: 22px; padding: 2rem 2.3rem; min-width:310px; max-width: 98vw; max-height: 94vh; overflow-y: auto; box-shadow: 0 10px 42px rgba(20,45,20,0.13); position: relative;}
.close-btn { position: absolute; right: 25px; top: 15px; font-size: 1.8rem; color: #666; background:none; border:none; cursor:pointer; font-weight:bold;}
.close-btn:hover {color:#219b39;}
.section-title { font-size: 1.5rem; color: #2d5a2d; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 0.5rem; }
.disease-table, .orders-table { border-collapse:collapse; width:100%; background:#fff; margin-top: 1rem;}
.disease-table th, .disease-table td, .orders-table th, .orders-table td { padding:10px; border: 1px solid #e0e0e0; text-align:left;}
.disease-table th, .orders-table th { background:#f0f9f0; color: #2d5a2d;}
.disease-table tr:nth-child(even), .orders-table tr:nth-child(even) { background:#fafafa;}
.form-group { margin-bottom: 1.5rem; }
.form-label { display: block; margin-bottom: 0.5rem; color: #555; font-weight: 500; }
.form-input, .form-select, .form-textarea { width: 100%; padding: 0.75rem; border: 2px solid #e8f5e8; border-radius: 10px; font-size: 1rem; transition: border-color 0.3s, box-shadow 0.3s; }
.form-input:focus, .form-select:focus, .form-textarea:focus { outline: none; border-color: #2d5a2d; box-shadow: 0 0 0 3px rgba(45, 90, 45, 0.1);}
.form-textarea { resize: vertical; min-height: 100px; }
.btn-primary { background: linear-gradient(135deg, #2d5a2d 0%, #3d7a3d 100%); color: white; width: 100%; padding: 1rem; font-size: 1.1rem; border-radius: 15px; border: none; cursor: pointer; transition: all 0.3s; font-weight: 600; }
.btn-primary:hover { transform: translateY(-2px); box-shadow: 0 10px 25px rgba(45, 90, 45, 0.3); }
.listing-row, .order-row-display { background: #f9fff9; border-radius: 9px; margin-bottom: 0.8rem; padding: 12px 18px; display: flex; align-items: center; justify-content: space-between;}
.status-badge { padding: 3px 16px; border-radius: 15px; font-size: 0.97rem; font-weight: 500; margin-left: 10px;}
.status-active { background: #e7f7e9; color:#237e3c;}
.status-pending { background: #fbeec2; color:#a6791f;}
.status-delivered { background: #e0f6f7; color:#16798c;}
.view-all-btn { margin: 0 auto; margin-top: 1.2rem; display: block; background: #29572a; color: #fff; padding: 0.85rem 0; border: none; border-radius: 20px; width: 100%; font-size: 1.13rem; font-weight: 500; transition: background 0.2s;}
.view-all-btn:hover { background:#187d1f; }
@media (max-width: 768px) {
    .nav { flex-direction: column; }
    .modal-content { padding: 1rem;}
    .action-btn {padding:0.75rem 1rem;}
}
.footer { background: #2d5a2d; color: white; text-align: center; padding: 2rem; margin-top: 3rem;}
.notification-popup {
    display: none;
    position: fixed;
    top: 70px;
    right: 48px;
    width: 320px;
    background: #fff;
    border-radius: 14px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.13);
    z-index: 1200;
    animation: popup-fade 0.25s;
}
@keyframes popup-fade {
    from { opacity: 0; transform: translateY(-24px);}
    to { opacity: 1; transform: translateY(0);}
}
.popup-header { font-size: 1.15rem; font-weight: bold; color: #256129; padding: 16px 20px 12px 20px; border-bottom: 1px solid #e8f5e8; display: flex; justify-content: space-between; align-items: center;}
.popup-close { font-size: 1.4rem; cursor: pointer; color: #888; padding: 2px 8px; border-radius: 4px;}
.popup-close:hover { background: #eaeaea; }
.notification-list { list-style: none; margin: 0; padding: 0 0 10px 0; max-height: 270px; overflow-y: auto;}
.notification-list li { padding: 14px 20px 10px 20px; border-bottom: 1px solid #f4f4f4; font-size: 0.97rem; display: flex; flex-direction: column;}
.notification-list li:last-child { border-bottom: none; }
.notif-title { color: #255729; font-weight: 500; }
.notif-time { color: #aaa; font-size: 0.85em; margin-top: 2px; }
.main-actions {
    display: flex;
    justify-content: center;
    gap: 2.2rem;
    margin: 2.8rem 0 2.2rem 0;
}
.action-btn {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 0.3rem;
    background: #f8fcf8;
    border: none;
    border-radius: 20px;
    box-shadow: 0 4px 28px rgba(70,110,70,0.11), 0 1.5px 4px rgba(60,110,60,0.04);
    padding: 2.1rem 2.3rem 1.4rem 2.3rem;
    font-weight: 600;
    font-size: 1.25rem;
    color: #224b1b;
    cursor: pointer;
    min-width: 200px;
    transition: box-shadow .18s, transform .14s, background .2s;
    outline: none;
    position: relative;
}
.action-btn:hover, .action-btn:focus {
    background: #e6f7ea;
    box-shadow: 0 7px 32px rgba(40,110,40,0.17), 0 3px 7px rgba(60,120,60,0.08);
    transform: translateY(-3px) scale(1.035);
}
.icon-box {
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(145deg,#defee6 60%,#b3ecc0 100%);
    border-radius: 50%;
    width: 56px;
    height: 56px;
    margin-bottom: .7rem;
    box-shadow: 0 4px 14px #bbe6c680;
}
.emoji-icon {
    font-size: 2.1rem;
    transition: transform .18s cubic-bezier(.6,1.2,.34,.86);
    display: block;
    filter: drop-shadow(0 1px 2px #aadbb255);
}
.action-btn:hover .emoji-icon {
    transform: scale(1.16) rotate(-8deg);
}
.action-title {
    font-size: 1.13rem;
    font-weight: 700;
    line-height: 1.23;
    letter-spacing: 0.01em;
    color: #1c3823;
    text-align: center;
    text-shadow: 0 1px 0 #e5ffe8;
    display: block;
    margin-top: 0.12em;
}
@media (max-width:700px){
    .main-actions { flex-direction:column; gap:1.5rem; }
    .action-btn { min-width: 0; width: 90vw; }
}
.message-box {
    padding: 10px 20px;
    margin-bottom: 15px;
    border-radius: 8px;
    font-weight: bold;
    text-align: center;
    opacity: 0;
    transition: opacity 0.5s ease-in-out;
    max-height: 0;
    overflow: hidden;
    padding-top: 0;
    padding-bottom: 0;
}
.message-box.show {
    opacity: 1;
    max-height: 100px; /* Adjust as needed */
    padding-top: 10px;
    padding-bottom: 10px;
}
.message-box.success {
    background-color: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}
.message-box.error {
    background-color: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}
/* Styles for the logout button, copied from buyer.php */
.btn-logout {
    background: #dc3545;
    color: white;
    border: none;
    padding: 0.5rem 1.5rem;
    border-radius: 25px;
    cursor: pointer;
    font-weight: 500;
    transition: all 0.3s ease;
    text-decoration: none;
    display: inline-block;
    text-align: center;
}
.btn-logout:hover {
    background: #c82333;
    transform: translateY(-2px);
}
/* Styles for navigation links */
.nav-links {
    display: flex;
    gap: 2rem;
    list-style: none;
    margin: 0; /* Remove default margin */
    padding: 0; /* Remove default padding */
}
.nav-links a {
    text-decoration: none;
    color: #666;
    font-weight: 500;
    transition: color 0.3s ease;
}
.nav-links a:hover {
    color: rgb(74, 171, 74);
}
@media (max-width: 768px) {
    .nav-links {
        display: none; 
    }
}
</style>
</head>
<body>
<header class="header">
    <nav class="nav">
        <div class="logo">
            <img src="logo.png" alt="AgroConnect Logo">
            <span>AgroConnect</span>
        </div>
        <ul class="nav-links">
            <li><a href="home.php">Home</a></li>
            <li><a href="features.php">Features</a></li>
            <li><a href="marketplace.php">Marketplace</a></li>
            <li><a href="crop-health.php">Crop Health</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="profile.php">Profile</a></li>
            <li><a href="map.php">Map</a></li>
        </ul>
        <div class="header-icons">
            <a href="javascript:void(0);" title="Notifications" style="display: flex; align-items: center; position:relative;"
            id="notif-bell" onclick="showNotificationPopup()">
                <img src="notification.png" alt="Notifications" style="width:38px; height:38px; cursor:pointer;">
                <span id="notif-dot"></span>
            </a>
            <span style="color: #2d5a2d; font-weight: bold; margin-right: 10px;">Welcome, <?php echo htmlspecialchars($userName); ?>!</span>
            <a href="logout.php" class="btn btn-logout">Logout</a>
        </div>
    </nav>
</header>
<div class="container" style="max-width:650px;margin:2.5rem auto 2.2rem auto;">
    <div class="dashboard-header" style="margin-top:2.5rem;">
        <h1 class="dashboard-title" style="display:flex;gap:0.7rem;align-items:center;justify-content:center;">🚜 Farmer Dashboard</h1>
        <p class="dashboard-subtitle">Manage your farm, track orders, and monitor crop health</p>
    </div>
<div class="main-actions">
    <button class="action-btn" onclick="openModal('listings-modal')">
        <span class="icon-box"><span class="emoji-icon">📦</span></span>
        <span>
            <span class="action-title">My Listings<br>& Orders</span>
        </span>
    </button>
    <button class="action-btn" onclick="openModal('diseases-modal')">
        <span class="icon-box"><span class="emoji-icon">🌿</span></span>
        <span>
            <span class="action-title">My Disease<br>Reports & Answers</span>
        </span>
    </button>
    <button class="action-btn" onclick="openModal('report-modal')">
        <span class="icon-box"><span class="emoji-icon">🦠</span></span>
        <span>
            <span class="action-title">Report<br>Crop Disease</span>
        </span>
    </button>
</div>
    
    <!-- Upload New Product (always visible, not modal) -->
    <section class="section">
        <h2 class="section-title">➕ Upload New Product</h2>
        <div id="upload-message-box" class="message-box"></div>
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label class="form-label">Product Name</label>
                <input type="text" name="product_name" class="form-input" placeholder="e.g., Organic Tomatoes" required>
            </div>
            <div class="form-group">
                <label class="form-label">Price (Rs)</label>
                <input type="number" step="0.01" name="price" class="form-input" placeholder="e.g., 200.00" required>
            </div>
            <div class="form-group">
                <label class="form-label">Unit of Sale</label>
                <select name="unit" class="form-select" required>
                    <option value="kg">Kilogram (kg)</option>
                    <option value="g">Gram (g)</option>
                    <option value="piece">Piece</option>
                    <option value="dozen">Dozen</option>
                    <option value="bundle">Bundle</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Stock Quantity</label>
                <input type="number" step="0.01" name="stock_quantity" class="form-input" placeholder="e.g., 100 (for 100 kg/pieces)" required>
            </div>
            <div class="form-group">
                <label class="form-label">Product Image</label>
                <input type="file" name="product_image" class="form-input" accept="image/*" required>
            </div>
            <div class="form-group">
                <label class="form-label">Location</label>
                <select name="location" class="form-select" required>
                    <option value="">Select Location</option>
                    <option value="Ampara">Ampara</option>
                    <option value="Anuradhapura">Anuradhapura</option>
                    <option value="Badulla">Badulla</option>
                    <option value="Batticaloa">Batticaloa</option>
                    <option value="Colombo">Colombo</option>
                    <option value="Galle">Galle</option>
                    <option value="Gampaha">Gampaha</option>
                    <option value="Hambantota">Hambantota</option>
                    <option value="Jaffna">Jaffna</option>
                    <option value="Kalutara">Kalutara</option>
                    <option value="Kandy">Kandy</option>
                    <option value="Kegalle">Kegalle</option>
                    <option value="Kilinochchi">Kilinochchi</option>
                    <option value="Kurunegala">Kurunegala</option>
                    <option value="Mannar">Mannar</option>
                    <option value="Matale">Matale</option>
                    <option value="Matara">Matara</option>
                    <option value="Monaragala">Monaragala</option>
                    <option value="Mullaitivu">Mullaitivu</option>
                    <option value="Nuwara Eliya">Nuwara Eliya</option>
                    <option value="Polonnaruwa">Polonnaruwa</option>
                    <option value="Puttalam">Puttalam</option>
                    <option value="Ratnapura">Ratnapura</option>
                    <option value="Trincomalee">Trincomalee</option>
                    <option value="Vavuniya">Vavuniya</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Category</label>
                <select name="category" class="form-select" required>
                    <option value="Vegetables">Vegetables</option>
                    <option value="Fruits">Fruits</option>
                    <option value="Grains">Grains</option>
                    <option value="Dairy">Dairy</option>
                    <option value="Spices">Spices</option>
                    <option value="Herbs">Herbs</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            <button type="submit" class="btn-primary">Upload Product</button>
        </form>
    </section>
</div>

<!-- Listings & Orders Modal -->
<div id="listings-modal" class="modal">
  <div class="modal-content">
    <button class="close-btn" onclick="closeModal('listings-modal')">&times;</button>
    <h2 class="section-title">📦 My Listings & Orders</h2>
    <div class="order-group" style="margin-bottom:1.5rem;">
        <div class="order-label" style="margin-bottom:.6rem;font-weight:bold;">Recent Listings:</div>
        <?php
        if (empty($products)) {
            echo "<div class='listing-row'>No listings found.</div>";
        } else {
            foreach ($products as $prod) {
                echo "<div class='listing-row'>"
                    . htmlspecialchars($prod['name']) . " (" . (float)$prod['stock_quantity'] . htmlspecialchars($prod['unit']) . ") @ Rs." . number_format($prod['price'], 2) . "/" . htmlspecialchars($prod['unit']) . " <span class='status-badge status-active'>Active</span>"
                    . "</div>";
            }
        }
        ?>
    </div>
    <div class="order-group">
        <div class="order-label" style="margin-bottom:.6rem;font-weight:bold;">Recent Orders for My Products:</div>
        <?php
        if (empty($farmerOrders)) {
            echo "<div class='order-row-display'>No orders for your products yet.</div>";
        } else {
            foreach ($farmerOrders as $order) {
                $statusClass = '';
                switch ($order['status']) {
                    case 'pending': $statusClass = 'status-pending'; break;
                    case 'processing': $statusClass = 'status-pending'; break; // Could be a different color
                    case 'shipped': $statusClass = 'status-pending'; break; // Could be a different color
                    case 'delivered': $statusClass = 'status-delivered'; break;
                    case 'cancelled': $statusClass = 'status-error'; break; // Need to add status-error style
                    default: $statusClass = 'status-pending'; break;
                }
                echo "<div class='order-row-display'>"
                    . "Order #" . htmlspecialchars($order['order_id']) . " by " . htmlspecialchars($order['buyer_name']) . ": " . htmlspecialchars($order['ordered_items'])
                    . " (Total: Rs." . number_format($order['total_amount'], 2) . ") "
                    . "<span class='status-badge " . $statusClass . "'>" . htmlspecialchars(ucfirst($order['status'])) . "</span>"
                    . "</div>";
            }
        }
        ?>
    </div>
    <button class="view-all-btn">View All Activity</button>
  </div>
</div>

<!-- Disease Reports Modal -->
<div id="diseases-modal" class="modal">
  <div class="modal-content" style="max-width:650px;">
    <button class="close-btn" onclick="closeModal('diseases-modal')">&times;</button>
    <h2 class="section-title">🌿 My Disease Reports & Answers</h2>
    <div id="disease-report-message-box" class="message-box"></div>
    <table class="disease-table">
        <thead>
            <tr>
                <th>Crop Type</th>
                <th>Symptoms</th>
                <th>Diagnosis</th>
                <th>Treatment</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
        <?php
        if (empty($reports)) {
            echo "<tr><td colspan='5'>No reports found.</td></tr>";
        } else {
            foreach ($reports as $rep) {
                echo "<tr>
                        <td>".htmlspecialchars($rep['crop_type'])."</td>
                        <td>".htmlspecialchars($rep['symptoms'])."</td>
                        <td>".($rep['diagnosis'] ? htmlspecialchars($rep['diagnosis']) : "<em style='color:orange;'>Pending</em>")."</td>
                        <td>".($rep['treatment_suggestion'] ? htmlspecialchars($rep['treatment_suggestion']) : "-")."</td>
                        <td>".date('Y-m-d', strtotime($rep['created_at']))."</td>
                      </tr>";
            }
        }
        ?>
        </tbody>
    </table>
  </div>
</div>

<!-- Report Crop Disease Modal -->
<div id="report-modal" class="modal">
  <div class="modal-content" style="max-width:500px;">
    <button class="close-btn" onclick="closeModal('report-modal')">&times;</button>
    <h2 class="section-title">🦠 Report Crop Disease</h2>
    <form action="" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label class="form-label">Crop Type</label>
            <input type="text" name="crop_type" class="form-input" placeholder="e.g., Tomato" required>
        </div>
        <div class="form-group">
            <label class="form-label">Symptoms Observed</label>
            <textarea name="symptoms" class="form-textarea" placeholder="Describe symptoms in detail..." required></textarea>
        </div>
        <div class="form-group">
            <label class="form-label">Disease Image</label>
            <input type="file" name="disease_image" class="form-input" accept="image/*">
        </div>
        <button type="submit" class="btn-primary">Report Disease</button>
    </form>
  </div>
</div>

<!-- Notification Popup -->
<div id="notification-popup" class="notification-popup">
    <div class="popup-header">
        Notifications
        <span class="popup-close" onclick="closeNotificationPopup()">&times;</span>
    </div>
    <ul class="notification-list" id="notification-list">       
        <?php
        if (empty($diseaseNotifications)) {
            echo "<li><span class='notif-title'>No new notifications</span></li>";
        } else {
            foreach ($diseaseNotifications as $notif) {
                echo "<li>
                            <span class='notif-title'>Diagnosis for '{$notif['crop_type']}' received</span>
                            <span class='notif-time'>".date('M d, H:i', strtotime($notif['created_at']))."</span>
                          </li>";
            }
        }
        ?>
    </ul>
</div>

<footer class="footer">
    <p>© 2025 AgroConnect. All rights reserved 🧡</p>
</footer>
<script>
function openModal(id) {
    document.getElementById(id).classList.add('active');
    document.body.style.overflow = 'hidden';
}
function closeModal(id) {
    document.getElementById(id).classList.remove('active');
    document.body.style.overflow = 'auto';
}
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        let open = document.querySelector('.modal.active');
        if (open) { closeModal(open.id); } // Use closeModal for consistency
        closeNotificationPopup();
    }
});
window.onclick = function(event) {
    document.querySelectorAll('.modal').forEach(function(modal){
        if (event.target === modal) {
            closeModal(modal.id);
        }
    });
    // Notification popup
    const popup = document.getElementById('notification-popup');
    const bell = document.getElementById('notif-bell');
    if (popup && popup.style.display === 'block' && !popup.contains(event.target) && !bell.contains(event.target)) {
        closeNotificationPopup();
    }
};

function showNotificationPopup() {
    document.getElementById('notification-popup').style.display = 'block';
    document.getElementById('notif-dot').style.display = 'none'; // Mark as read visually
    document.body.style.overflow = 'hidden';

    // Use Fetch API to mark notifications as seen in the database
    fetch('farmer.php?mark_notifications_seen=1', { method: 'GET' })
        .then(response => {
            if (!response.ok) {
                console.error('Failed to mark notifications as seen.');
            }
        })
        .catch(error => console.error('Error marking notifications seen:', error));
}

function closeNotificationPopup() {
    document.getElementById('notification-popup').style.display = 'none';
    document.body.style.overflow = 'auto';
}

// Function to display messages (replaces alert)
function showMessage(message, type, targetId) {
    const messageBox = document.getElementById(targetId);
    if (messageBox) {
        messageBox.textContent = message;
        messageBox.className = 'message-box show ' + type; 
        setTimeout(() => {
            messageBox.classList.remove('show');
        }, 5000); // Hide after 5 seconds
    }
}

// Check for PHP messages on page load and display them
document.addEventListener('DOMContentLoaded', function() {
    const uploadMsg = "<?php echo addslashes($uploadMessage); ?>";
    const diseaseMsg = "<?php echo addslashes($diseaseReportMessage); ?>";

    if (uploadMsg) {
        const type = uploadMsg.includes('successfully') ? 'success' : 'error';
        showMessage(uploadMsg.replace(/<\/?span[^>]*>/g, ''), type, 'upload-message-box');
    }
    if (diseaseMsg) {
        const type = diseaseMsg.includes('submitted') ? 'success' : 'error';
        showMessage(diseaseMsg.replace(/<\/?span[^>]*>/g, ''), type, 'disease-report-message-box');
    }
});

</script>
<?php
// Mark notifications as seen if mark_notifications_seen=1 is in the query string (called by JS/AJAX)
if (isset($_GET['mark_notifications_seen']) && $_GET['mark_notifications_seen'] == 1) {
    $conn = new mysqli($servername, $username_db, $password_db, $dbname);
    if (!$conn->connect_error) {
        $stmt = $conn->prepare("UPDATE disease_reports SET seen_notification=1 WHERE user_id=? AND diagnosis IS NOT NULL AND diagnosis!='' AND (seen_notification IS NULL OR seen_notification=0)");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $stmt->close();
        $conn->close();
    }
}
?>
</body>
</html>
