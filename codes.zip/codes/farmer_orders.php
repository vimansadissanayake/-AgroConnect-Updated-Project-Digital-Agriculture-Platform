<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Farmer') {
    header('Location: login.php');
    exit();
}

$farmer_id = $_SESSION['user_id'];

$orders_sql = "SELECT o.id, o.order_date, o.total_amount, o.status, o.delivery_partner_id, o.delivery_address,
               u.name as buyer_name, u.phone as buyer_phone,
               d.name as delivery_partner_name,
               GROUP_CONCAT(CONCAT(p.name, ' x', oi.quantity, ' ', p.unit) SEPARATOR ', ') as items
               FROM orders o
               JOIN order_items oi ON o.id = oi.order_id
               JOIN products p ON oi.product_id = p.id
               JOIN users u ON o.user_id = u.id
               LEFT JOIN users d ON o.delivery_partner_id = d.id
               WHERE p.farmer_id = ?
               GROUP BY o.id
               ORDER BY o.order_date DESC";

$stmt = $conn->prepare($orders_sql);
$stmt->bind_param("i", $farmer_id);
$stmt->execute();
$orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$delivery_partners = $conn->query("SELECT id, name, phone FROM users WHERE role = 'Delivery'")->fetch_all(MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'prepare') {
        $order_id = $_POST['order_id'];
        $stmt = $conn->prepare("UPDATE orders SET status = 'processing' WHERE id = ?");
        $stmt->bind_param("i", $order_id);
        $stmt->execute();
        header('Location: farmer_orders.php');
        exit();
    }
    
    if ($action === 'assign_delivery') {
        $order_id = $_POST['order_id'];
        $delivery_id = $_POST['delivery_id'];
        $stmt = $conn->prepare("UPDATE orders SET delivery_partner_id = ?, status = 'shipped' WHERE id = ?");
        $stmt->bind_param("ii", $delivery_id, $order_id);
        $stmt->execute();
        header('Location: farmer_orders.php');
        exit();
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders - AgroConnect</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50">
    <div class="max-w-7xl mx-auto p-6">
        <div class="bg-white rounded-lg shadow-lg p-6">
            <h1 class="text-3xl font-bold text-green-800 mb-6">
                <i class="fas fa-clipboard-list"></i> Manage Orders
            </h1>

            <?php foreach($orders as $order): ?>
            <div class="bg-gray-50 rounded-lg p-6 mb-4 border-l-4 <?= $order['status'] === 'delivered' ? 'border-green-600' : 'border-blue-600' ?>">
                <div class="flex justify-between items-start mb-4">
                    <div>
                        <h3 class="text-xl font-bold">Order #<?= $order['id'] ?></h3>
                        <p class="text-gray-600"><?= date('M d, Y', strtotime($order['order_date'])) ?></p>
                    </div>
                    <span class="px-4 py-2 rounded-full font-bold <?= 
                        $order['status'] === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                        ($order['status'] === 'processing' ? 'bg-blue-100 text-blue-800' :
                        ($order['status'] === 'shipped' ? 'bg-purple-100 text-purple-800' :
                        'bg-green-100 text-green-800'))
                    ?>">
                        <?= ucfirst($order['status']) ?>
                    </span>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                        <p class="font-semibold">Buyer: <?= htmlspecialchars($order['buyer_name']) ?></p>
                        <p class="text-gray-600">Phone: <?= htmlspecialchars($order['buyer_phone']) ?></p>
                        <p class="text-gray-600">Address: <?= htmlspecialchars($order['delivery_address']) ?></p>
                    </div>
                    <div>
                        <p class="font-semibold">Items:</p>
                        <p class="text-gray-700"><?= htmlspecialchars($order['items']) ?></p>
                        <p class="font-bold text-green-600 mt-2">Total: Rs <?= number_format($order['total_amount'], 2) ?></p>
                    </div>
                </div>

                <?php if($order['delivery_partner_name']): ?>
                <div class="bg-blue-50 rounded p-3 mb-4">
                    <p class="font-semibold">Delivery Partner: <?= htmlspecialchars($order['delivery_partner_name']) ?></p>
                </div>
                <?php endif; ?>

                <div class="flex gap-3">
                    <?php if($order['status'] === 'pending'): ?>
                    <form method="POST" class="inline">
                        <input type="hidden" name="action" value="prepare">
                        <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                        <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                            <i class="fas fa-box"></i> Mark as Prepared
                        </button>
                    </form>
                    <?php endif; ?>

                    <?php if($order['status'] === 'processing' && !$order['delivery_partner_id']): ?>
                    <form method="POST" class="inline flex gap-2">
                        <input type="hidden" name="action" value="assign_delivery">
                        <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                        <select name="delivery_id" class="px-4 py-2 border rounded" required>
                            <option value="">Select Delivery Partner</option>
                            <?php foreach($delivery_partners as $partner): ?>
                            <option value="<?= $partner['id'] ?>"><?= htmlspecialchars($partner['name']) ?> - <?= htmlspecialchars($partner['phone']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">
                            <i class="fas fa-truck"></i> Assign & Ship
                        </button>
                    </form>
                    <?php endif; ?>

                    <a href="order_tracking.php?order_id=<?= $order['id'] ?>" class="px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-700">
                        <i class="fas fa-map-marker-alt"></i> Track
                    </a>
                </div>
            </div>
            <?php endforeach; ?>

            <?php if(empty($orders)): ?>
            <div class="text-center py-12 text-gray-500">
                <i class="fas fa-inbox text-6xl mb-4"></i>
                <p class="text-xl">No orders yet</p>
            </div>
            <?php endif; ?>

            <div class="mt-6">
                <a href="farmer.php" class="px-6 py-3 bg-gray-600 text-white rounded hover:bg-gray-700">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </div>
</body>
</html>
