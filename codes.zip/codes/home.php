<?php
include 'db.php'; 

// Fetch recent reviews
$reviews_query = "SELECT r.rating, r.review_text, u.name as buyer_name, p.name as product_name 
                  FROM reviews r 
                  JOIN users u ON r.user_id = u.id 
                  JOIN products p ON r.product_id = p.id 
                  ORDER BY r.created_at DESC LIMIT 5";
$reviews_result = $conn->query($reviews_query);
$reviews = [];
if ($reviews_result->num_rows > 0) {
    while ($row = $reviews_result->fetch_assoc()) {
        $reviews[] = $row;
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AgroConnect - Digital Agriculture Platform</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="global-styles.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f0fdf4 0%, #fefce8 100%);
        }
        .hero-gradient {
            background: linear-gradient(rgba(9, 67, 12, 0.75), rgba(27, 94, 32, 0.85)), url('home img.jpeg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            min-height: 90vh;
            display: flex;
            align-items: center;
            position: relative;
        }
        .hero-content { position: relative; z-index: 1; }
        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        .transition-all { transition: all 0.3s ease; }
        .role-card:hover { background-color: #f1f8e9; }
        .product-card:hover { box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .disease-card { border-left: 4px solid #2e7d32; }
    </style>
</head>
<body>
      <!-- Navigation Bar -->
     <nav class="bg-white shadow-lg sticky top-0 z-50" style="border-bottom: 3px solid #22c55e;">
        <div class="container mx-auto px-6 py-3">
            <div class="flex items-center justify-between">
                <div class="flex items-center">
                    <img src="logo.png" alt="AgroConnect Logo" class="w-15 h-10 mr-2">
                    <span class="text-xl font-bold text-green-800">AgroConnect</span>
                </div>
                <div class="hidden md:flex items-center space-x-8">
                    <a href="home.php" class="text-green-600 hover:text-green-600 font-medium">Home</a>
                    <a href="features.php" class="text-gray-700 hover:text-green-600 font-medium">Features</a>
                    <a href="marketplace.php" class="text-gray-600 hover:text-green-600 font-medium">Marketplace</a>
                    <a href="crophealth.php" class="text-gray-600 hover:text-green-600 font-medium">Crop Health</a>
                    <a href="aboutus.php" class="text-gray-600 hover:text-green-600 font-medium">About</a>
                    <a href="profile.php" class="text-gray-600 hover:text-green-600 font-medium">Profile</a>
                    <a href="map.php" class="text-gray-600 hover:text-green-600 font-medium">Map</a>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="login.php" class="px-5 py-2 text-white bg-gradient-to-r from-green-500 to-green-600 rounded-lg hover:from-green-600 hover:to-green-700 transition-all shadow-md hover:shadow-lg font-semibold">
                        Login
                    </a>
                    <a href="register.php" class="px-5 py-2 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-lg hover:from-amber-600 hover:to-orange-600 transition-all shadow-md hover:shadow-lg font-semibold">
                        Register
                    </a>
                    <button class="md:hidden text-gray-600">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-gradient text-white">
        <div class="container mx-auto px-6 hero-content">
            <div class="flex flex-col items-center text-center">
                <div class="w-full max-w-5xl">
                    <div class="mb-6 inline-block px-6 py-2 bg-gradient-to-r from-amber-400/20 to-orange-400/20 backdrop-blur-sm rounded-full border-2 border-amber-300/50">
                        <span class="text-sm font-semibold text-amber-100">Empowering Agriculture Through Technology</span>
                    </div>
                    <h1 class="text-5xl md:text-7xl font-bold mb-6 leading-tight">
                        Connecting Farmers to the<br>
                        <span class="block text-transparent bg-clip-text bg-gradient-to-r from-green-200 to-emerald-100 mt-3">
                            Digital Agriculture System
                        </span>
                    </h1>
                    <p class="text-xl md:text-2xl mb-10 max-w-3xl mx-auto text-green-50 leading-relaxed">
                        A comprehensive platform for selling produce, diagnosing plant diseases, and managing deliveries - all in one place.
                    </p>
                    <div class="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-6">
                        <a href="login.php" class="group px-8 py-4 bg-gradient-to-r from-white to-green-50 text-green-700 font-bold rounded-xl hover:from-green-50 hover:to-white transition-all shadow-2xl text-lg transform hover:scale-105 border-2 border-white/50">
                            <i class="fas fa-user-plus mr-2"></i>Join as your Role
                            <i class="fas fa-arrow-right ml-2 group-hover:translate-x-1 transition-transform"></i>
                        </a>
                        <a href="marketplace.php" class="group px-8 py-4 bg-gradient-to-r from-amber-400 to-orange-500 text-white font-bold rounded-xl hover:from-amber-500 hover:to-orange-600 transition-all shadow-2xl text-lg transform hover:scale-105">
                            <i class="fas fa-store mr-2"></i>Explore Marketplace
                            <i class="fas fa-arrow-right ml-2 group-hover:translate-x-1 transition-transform"></i>
                        </a>
                    </div>
                
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="bg-gradient-to-br from-white via-green-50 to-amber-50 py-16">
        <div class="container mx-auto px-6">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
                <div class="p-6 border-r-0 md:border-r border-green-200">
                    <h3 class="text-4xl font-bold bg-gradient-to-r from-green-600 to-green-700 bg-clip-text text-transparent mb-2">1,000+</h3>
                    <p class="text-gray-600 font-medium">Registered Farmers</p>
                </div>
                <div class="p-6 border-r-0 md:border-r border-green-200">
                    <h3 class="text-4xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent mb-2">2,000+</h3>
                    <p class="text-gray-600 font-medium">Products Listed</p>
                </div>
                <div class="p-6 border-r-0 md:border-r border-green-200">
                    <h3 class="text-4xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent mb-2">500+</h3>
                    <p class="text-gray-600 font-medium">Disease Cases Solved</p>
                </div>
                <div class="p-6">
                    <h3 class="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-2">98%</h3>
                    <p class="text-gray-600 font-medium">Satisfaction Rate</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="py-16 bg-gradient-to-br from-green-50 via-white to-blue-50">
        <div class="container mx-auto px-6">
            <div class="text-center mb-16">
                <h2 class="text-3xl font-bold text-gray-800 mb-4">Our Comprehensive Features</h2>
                <p class="text-gray-600 max-w-2xl mx-auto">AgroConnect provides all the tools farmers, buyers, and agricultural experts need in one integrated platform.</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="bg-white p-8 rounded-2xl shadow-lg feature-card transition-all cursor-pointer">
                    <div class="w-16 h-16 bg-gradient-to-br from-gray-100 to-gray-200 rounded-2xl flex items-center justify-center mb-6 shadow-md">
                        <i class="fas fa-store text-gray-600 text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-800 mb-3">Digital Marketplace</h3>
                    <p class="text-gray-600">Farmers can list their produce with detailed information and images. Buyers can browse, filter, and purchase directly from farmers.</p>
                </div>
                <div class="bg-white p-8 rounded-2xl shadow-lg feature-card transition-all cursor-pointer">
                    <div class="w-16 h-16 bg-gradient-to-br from-gray-100 to-gray-200 rounded-2xl flex items-center justify-center mb-6 shadow-md">
                        <i class="fas fa-leaf text-gray-600 text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-800 mb-3">Crop Health Diagnosis</h3>
                    <p class="text-gray-600">Farmers can report plant diseases with photos and get expert diagnosis and treatment recommendations within hours.</p>
                </div>
                <div class="bg-white p-8 rounded-2xl shadow-lg feature-card transition-all cursor-pointer">
                    <div class="w-16 h-16 bg-gradient-to-br from-gray-100 to-gray-200 rounded-2xl flex items-center justify-center mb-6 shadow-md">
                        <i class="fas fa-truck text-gray-600 text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-800 mb-3">Integrated Logistics</h3>
                    <p class="text-gray-600">Our platform connects with delivery services to provide seamless order fulfillment and real-time tracking for both farmers and buyers.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Roles Section -->
    <section class="py-16 bg-white">
        <div class="container mx-auto px-6">
            <div class="text-center mb-16">
                <h2 class="text-3xl font-bold text-gray-800 mb-4">Who Can Benefit?</h2>
                <p class="text-gray-600 max-w-2xl mx-auto">AgroConnect serves multiple stakeholders in the agricultural ecosystem.</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="border border-gray-200 p-8 rounded-lg role-card transition-all cursor-pointer">
                    <div class="flex items-center mb-6">
                        <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mr-4">
                            <i class="fas fa-user-tie text-green-600 text-2xl"></i>
                        </div>
                        <h3 class="text-xl font-bold text-gray-800">Farmers</h3>
                    </div>
                    <ul class="space-y-3 text-gray-600">
                        <li class="flex items-start">
                            <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                            <span>Sell produce directly to buyers</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                            <span>Get expert advice on crop diseases</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                            <span>Manage orders and deliveries</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                            <span>Access market price trends</span>
                        </li>
                    </ul>
                </div>
                <div class="border border-gray-200 p-8 rounded-lg role-card transition-all cursor-pointer">
                    <div class="flex items-center mb-6">
                        <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mr-4">
                            <i class="fas fa-shopping-basket text-green-600 text-2xl"></i>
                        </div>
                        <h3 class="text-xl font-bold text-gray-800">Buyers</h3>
                    </div>
                    <ul class="space-y-3 text-gray-600">
                        <li class="flex items-start">
                            <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                            <span>Purchase fresh produce directly from farms</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                            <span>Filter by product type, quality, and location</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                            <span>Real-time order tracking</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                            <span>Bulk purchase discounts</span>
                        </li>
                    </ul>
                </div>
                <div class="border border-gray-200 p-8 rounded-lg role-card transition-all cursor-pointer">
                    <div class="flex items-center mb-6">
                        <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mr-4">
                            <i class="fas fa-microscope text-green-600 text-2xl"></i>
                        </div>
                        <h3 class="text-xl font-bold text-gray-800">Agricultural Experts</h3>
                    </div>
                    <ul class="space-y-3 text-gray-600">
                        <li class="flex items-start">
                            <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                            <span>Review and diagnose crop diseases</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                            <span>Provide treatment recommendations</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                            <span>Earn income through consultations</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                            <span>Build professional reputation</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section class="py-16 bg-white">
        <div class="container mx-auto px-6 text-center">
            <h2 class="text-3xl font-bold text-gray-800 mb-4">About AgroConnect</h2>
            <p class="text-lg leading-relaxed font-medium mb-4">
                <strong class="text-green-800">AgroConnect</strong> is a smart, digital bridge for
                <span class="font-semibold text-green-700">farmers</span>, <span class="font-semibold text-green-700">buyers</span>,
                <span class="font-semibold text-green-700">delivery services</span>, and <span class="font-semibold text-green-700">agriculture experts </span>.
                We make agriculture more connected, efficient, and sustainable for everyone.
                This dynamic platform is dedicated to revolutionizing the agricultural ecosystem by seamlessly connecting all stakeholders.
                Our mission is to <span class="font-semibold text-green-800">empower farmers</span> with direct market access, ensure the highest standards of
                <span class="font-semibold text-green-800">food safety</span> through expert testing, and deliver fresh produce
                <span class="font-semibold text-green-800">efficiently and reliably</span>.
                By eliminating middlemen and fostering transparency, AgroConnect helps farmers increase their income, enables buyers to purchase
                trusted, quality produce, and supports timely delivery to preserve freshness. Through innovative technology and community collaboration,
                we build a smarter, safer, and more sustainable agricultural supply chain — benefiting everyone from the farm to the table.
            </p>
            <div class="flex justify-center space-x-8 text-3xl text-green-600">
                <a href="https://web.facebook.com/vimansa.dissanayake.2025" target="_blank" class="hover:text-green-800 transition-colors duration-300"><i class="fab fa-facebook"></i></a>
                
                <a href="https://medium.com/@vimansacharuni" target="_blank" class="hover:text-green-800 transition-colors duration-300"><i class="fab fa-medium"></i></a>
                
                <a href="https://www.linkedin.com/in/vimansa-dissanayake-80125535a" target="_blank" class="hover:text-green-800 transition-colors duration-300"><i class="fab fa-linkedin"></i></a>
                
                <a href="http://www.youtube.com/@Lilz_Liz" target="_blank" class="hover:text-green-800 transition-colors duration-300"><i class="fab fa-youtube"></i></a>
            </div>
        </div>
    </section>

        <!-- Recent Reviews Section -->
    <section class="py-16 bg-white">
        <div class="container mx-auto px-6">
            <h2 class="text-3xl font-bold text-gray-800 mb-8 text-center">Our Customers Reviews</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php if (!empty($reviews)): ?>
                    <?php foreach ($reviews as $review): ?>
                        <div class="bg-green-50 p-6 rounded-xl shadow-md">
                            <div class="flex items-center mb-4">
                                <!-- Stars -->
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <i class="fas fa-star <?php echo $i <= $review['rating'] ? 'text-yellow-400' : 'text-gray-300'; ?>"></i>
                                <?php endfor; ?>
                            </div>
                            <p class="text-gray-700 mb-4">"<?php echo htmlspecialchars($review['review_text']); ?>"</p>
                            <div class="flex items-center">
                                <div class="w-10 h-10 bg-green-200 rounded-full flex items-center justify-center text-green-600 font-bold">
                                    <?php echo strtoupper(substr($review['buyer_name'], 0, 1)); ?>
                                </div>
                                <div class="ml-3">
                                    <p class="font-semibold text-gray-800"><?php echo htmlspecialchars($review['buyer_name']); ?></p>
                                    <p class="text-sm text-gray-600">Reviewed: <?php echo htmlspecialchars($review['product_name']); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="text-center text-gray-600 col-span-3">No reviews yet. Be the first!</p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <footer class="bg-green-900 text-white py-8">
        <div class="container mx-auto px-6 text-center">
            <p>© 2025 AgroConnect. All rights reserved <i class="fas fa-heart text-yellow-500"></i></p>
        </div>
    </footer>
</body>
</html>
