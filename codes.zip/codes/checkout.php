<?php
// checkout.php 

session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit();
}

$user_id = $_SESSION['user_id'];

// Get data sent from JavaScript (buyer.php)
$input_data = file_get_contents('php://input');
$request_data = json_decode($input_data, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Invalid JSON data received.']);
    exit();
}

$cart_items = $request_data['cart'] ?? [];
$total_amount = $request_data['total'] ?? 0;
$delivery_partner_id = $request_data['delivery_partner_id'] ?? null;
$buyer_address = $request_data['buyer_address'] ?? '';
$farmer_location = $request_data['farmer_location'] ?? '';

if (empty($cart_items) || $total_amount <= 0) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Cart is empty or invalid total.']);
    exit();
}

if (empty($delivery_partner_id)) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Please select a delivery partner.']);
    exit();
}

// Check for existing pending orders
$check_pending = $conn->prepare("SELECT id FROM orders WHERE user_id = ? AND status IN ('pending', 'processing', 'shipped')");
$check_pending->bind_param("i", $user_id);
$check_pending->execute();
$existing = $check_pending->get_result();
if ($existing->num_rows > 0) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'You have an active order. Please wait for it to be delivered before placing a new order.']);
    $check_pending->close();
    exit();
}
$check_pending->close();

// Calculate delivery fee based on distance
$delivery_fee = 0;
if (!empty($buyer_address) && !empty($farmer_location)) {
    $city_coords = [
        'Colombo' => [6.9271, 79.8612], 'Kandy' => [7.2906, 80.6337], 'Galle' => [6.0535, 80.2210],
        'Matara' => [5.9549, 80.5550], 'Jaffna' => [9.6615, 80.0255], 'Anuradhapura' => [8.3114, 80.4037],
        'Kurunegala' => [7.4863, 80.3623], 'Ratnapura' => [6.7056, 80.3847], 'Batticaloa' => [7.7310, 81.6747],
        'Trincomalee' => [8.5874, 81.2152], 'Ampara' => [7.2914, 81.6747], 'Badulla' => [6.9934, 81.0550],
        'Gampaha' => [7.0840, 80.0098], 'Hambantota' => [6.1429, 81.1212], 'Kalutara' => [6.5854, 79.9607],
        'Kegalle' => [7.2513, 80.3464], 'Matale' => [7.4675, 80.6234], 'Nuwara Eliya' => [6.9497, 80.7891],
        'Polonnaruwa' => [7.9403, 81.0188], 'Puttalam' => [8.0362, 79.8283], 'Vavuniya' => [8.7542, 80.4982],
        'Monaragala' => [6.8728, 81.3507], 'Kilinochchi' => [9.3961, 80.3980], 'Mannar' => [8.9810, 79.9044],
        'Mullaitivu' => [9.2671, 80.8142], 'Chilaw' => [7.5759, 79.7953], 'Negombo' => [7.2008, 79.8358]
    ];
    
    $buyer_coords = null;
    $farmer_coords = null;
    
    foreach ($city_coords as $city => $coords) {
        if (stripos($buyer_address, $city) !== false) {
            $buyer_coords = $coords;
        }
        if (stripos($farmer_location, $city) !== false) {
            $farmer_coords = $coords;
        }
    }
    
    if ($buyer_coords && $farmer_coords) {
        $lat1 = deg2rad($buyer_coords[0]);
        $lon1 = deg2rad($buyer_coords[1]);
        $lat2 = deg2rad($farmer_coords[0]);
        $lon2 = deg2rad($farmer_coords[1]);
        
        $dlat = $lat2 - $lat1;
        $dlon = $lon2 - $lon1;
        
        $a = sin($dlat/2) * sin($dlat/2) + cos($lat1) * cos($lat2) * sin($dlon/2) * sin($dlon/2);
        $c = 2 * atan2(sqrt($a), sqrt(1-$a));
        $distance_km = 6371 * $c;
        
        // Rs. 50 base fee + Rs. 20 per km
        $delivery_fee = 50 + ($distance_km * 20);
        $delivery_fee = round($delivery_fee, 2);
    } else {
        $delivery_fee = 200; // Default fee if locations not found
    }
}

$total_with_delivery = $total_amount + $delivery_fee;

$conn->begin_transaction();

try {
    // Get user email
    $user_sql = "SELECT email, name FROM users WHERE id = ?";
    $user_stmt = $conn->prepare($user_sql);
    $user_stmt->bind_param("i", $user_id);
    $user_stmt->execute();
    $user_result = $user_stmt->get_result()->fetch_assoc();
    $user_email = $user_result['email'];
    $user_name = $user_result['name'];
    $user_stmt->close();

    // Insert order with delivery fee
    $check_col = $conn->query("SHOW COLUMNS FROM orders LIKE 'delivery_partner_id'");
    $check_fee = $conn->query("SHOW COLUMNS FROM orders LIKE 'delivery_fee'");
    
    if ($check_col && $check_col->num_rows > 0 && $check_fee && $check_fee->num_rows > 0) {
        $order_sql = "INSERT INTO orders (user_id, total_amount, delivery_fee, status, order_date, delivery_partner_id) VALUES (?, ?, ?, 'pending', NOW(), ?)";
        $stmt = $conn->prepare($order_sql);
        $stmt->bind_param("iddi", $user_id, $total_with_delivery, $delivery_fee, $delivery_partner_id);
    } elseif ($check_col && $check_col->num_rows > 0) {
        $order_sql = "INSERT INTO orders (user_id, total_amount, status, order_date, delivery_partner_id) VALUES (?, ?, 'pending', NOW(), ?)";
        $stmt = $conn->prepare($order_sql);
        $stmt->bind_param("idi", $user_id, $total_with_delivery, $delivery_partner_id);
    } else {
        $order_sql = "INSERT INTO orders (user_id, total_amount, status, order_date) VALUES (?, ?, 'pending', NOW())";
        $stmt = $conn->prepare($order_sql);
        $stmt->bind_param("id", $user_id, $total_with_delivery);
    }
    $stmt->execute();
    $order_id = $conn->insert_id;
    $stmt->close();

    // Insert order items and build email content
    $items_html = '';
    $item_sql = "INSERT INTO order_items (order_id, product_id, quantity, price_at_order) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($item_sql);
    foreach ($cart_items as $item) {
        $product_id = $item['productId'];
        $quantity = $item['quantity'];
        $price_at_order = $item['price'];

        $stmt->bind_param("iiid", $order_id, $product_id, $quantity, $price_at_order);
        $stmt->execute();

        // Update product stock
        $update_stock = "UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?";
        $stock_stmt = $conn->prepare($update_stock);
        $stock_stmt->bind_param("ii", $quantity, $product_id);
        $stock_stmt->execute();
        $stock_stmt->close();
        
        // Build email items
        $items_html .= "<div class='order-item'>{$item['name']} x {$quantity} {$item['unit']} - Rs." . number_format($item['total'], 2) . "</div>";
    }
    $stmt->close();

    $conn->commit();
    
    // Send confirmation email 
    if (file_exists('send_order_email.php')) {
        include_once 'send_order_email.php';
        $orderDetails = [
            'items_html' => $items_html,
            'total' => number_format($total_amount, 2)
        ];
        @sendOrderConfirmationEmail($order_id, $user_email, $user_name, $orderDetails);
    }

    header('Content-Type: application/json');
    echo json_encode([
        'success' => true, 
        'message' => 'Order created successfully!', 
        'order_id' => $order_id,
        'redirect' => "payment.php?order_id=" . $order_id . "&amount=" . $total_with_delivery
    ]);
    exit();

} catch (mysqli_sql_exception $e) {
    $conn->rollback();
    error_log("Checkout transaction failed: " . $e->getMessage());
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Database error during checkout. Please try again.']);
    exit();
} catch (Exception $e) {
    $conn->rollback();
    error_log("Checkout failed: " . $e->getMessage());
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'An unexpected error occurred during checkout.']);
    exit();
} finally {
    $conn->close();
}
?>