<?php
// buyer.php 

session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
// Database connection 
$servername = "localhost";
$username_db = "root";
$password_db = ""; 
$dbname = "vimansa"; 
$userName = htmlspecialchars($_SESSION['user_name']);
$userRole = htmlspecialchars($_SESSION['user_role']);
$userId = $_SESSION['user_id'];

// Establish connection for fetching data
$conn = new mysqli($servername, $username_db, $password_db, $dbname);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Check if user has phone and address
$check_phone = $conn->query("SHOW COLUMNS FROM users LIKE 'phone'");
$check_address = $conn->query("SHOW COLUMNS FROM users LIKE 'address'");

if ($check_phone->num_rows > 0 && $check_address->num_rows > 0) {
    $user_check = $conn->query("SELECT phone, address FROM users WHERE id = $userId")->fetch_assoc();
    $missing_details = empty($user_check['phone']) || empty($user_check['address']);
} else {
    $missing_details = true;
}

// Fetch products from the database with average ratings
$products = [];
$sql_products = "SELECT p.id, p.name, p.price, p.unit, p.stock_quantity, p.image_path, p.category, p.location, p.farmer_id,
                 COALESCE(AVG(r.rating), 0) as avg_rating,
                 COUNT(r.id) as review_count
                 FROM products p
                 LEFT JOIN reviews r ON p.id = r.product_id
                 GROUP BY p.id
                 ORDER BY p.name ASC";
$result_products = $conn->query($sql_products);
if ($result_products->num_rows > 0) {
    while ($row = $result_products->fetch_assoc()) {
        $products[] = $row;
    }
}

// Fetch available delivery partners
$delivery_partners = [];
$sql_partners = "SELECT id, name, phone_number as phone FROM users WHERE role = 'Delivery' ORDER BY name ASC";
$result_partners = $conn->query($sql_partners);
if ($result_partners && $result_partners->num_rows > 0) {
    while ($row = $result_partners->fetch_assoc()) {
        $delivery_partners[] = $row;
    }
}

// Fetch user's orders
$orders = [];
$active_deliveries = [];
$sql_orders = "SELECT id, order_date, total_amount, status FROM orders WHERE user_id = ? ORDER BY order_date DESC";
$stmt_orders = $conn->prepare($sql_orders);
$stmt_orders->bind_param("i", $userId);
$stmt_orders->execute();
$result_orders = $stmt_orders->get_result();
if ($result_orders->num_rows > 0) {
    while ($order_row = $result_orders->fetch_assoc()) {
        $order_id = $order_row['id'];
        $order_row['items'] = [];

        // Fetch items for each order
        $sql_order_items = "SELECT oi.quantity, oi.price_at_order, oi.product_id, p.name, p.unit FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?";
        $stmt_order_items = $conn->prepare($sql_order_items);
        $stmt_order_items->bind_param("i", $order_id);
        $stmt_order_items->execute();
        $result_order_items = $stmt_order_items->get_result();
        while ($item_row = $result_order_items->fetch_assoc()) {
            $order_row['items'][] = $item_row;
        }
        $stmt_order_items->close();
        $orders[] = $order_row;
        
        // Track active deliveries
        if (in_array($order_row['status'], ['processing', 'shipped'])) {
            $active_deliveries[] = $order_row;
        }
    }
}
$stmt_orders->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $userRole; ?> - AgroConnect Buyer Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #e8f5e8 0%, #f0f9f0 100%);
            min-height: 100vh;
            color: #333;
        }
        .header {
            background: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: sticky; top: 0; z-index: 100;
        }
        .nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
        }
        .logo {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 1.5rem;
            font-weight: bold;
            color: #2d5a2d;
        }
        .logo img {
            width: 38px;
            height: 38px;
            margin-right: 8px;
            vertical-align: middle;
        }
        .nav-links {
            display: flex; gap: 2rem; list-style: none;
        }
        .nav-links a {
            text-decoration: none;
            color: #666;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        .nav-links a:hover { color:rgb(74, 171, 74); }
        .auth-buttons { display: flex; gap: 1rem; }
        .btn {
            padding: 0.5rem 1.5rem;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }
        .btn-login {
            background: transparent;
            color: #2d5a2d;
            border: 2px solid #2d5a2d;
        }
        .btn-login:hover { background: #2d5a2d; color: white; }
        .btn-register { background: #2d5a2d; color: white; }
        .btn-register:hover { background: #1a3d1a; transform: translateY(-2px); }
        .btn-logout {
            background: #dc3545;
            color: white;
            border: none;
            padding: 0.5rem 1.5rem;
            border-radius: 25px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }
        .btn-logout:hover { background: #c82333; transform: translateY(-2px); }

        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        .dashboard-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        .dashboard-title {
            font-size: 2.5rem;
            color: #2d5a2d;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 1rem;
        }
        .dashboard-title::before {
            content: "🛒";
            font-size: 2rem;
        }
        .dashboard-subtitle { color: #666; font-size: 1.1rem; }

        .section {
            background: white;
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: 1px solid #e8f5e8;
        }
        .section-title {
            font-size: 1.5rem;
            color: #2d5a2d;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .search-bar {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
        }
        .search-input {
            flex: 1;
            padding: 0.75rem;
            border: 2px solid #e8f5e8;
            border-radius: 25px;
            font-size: 1rem;
            min-width: 250px;
        }
        .filter-select {
            padding: 0.75rem 1.5rem;
            border: 2px solid #e8f5e8;
            border-radius: 25px;
            font-size: 1rem;
            background: white;
            cursor: pointer;
        }

        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 1.5rem;
        }
        .product-card {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border: 1px solid #f0f0f0;
        }
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }
        .product-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            background: #f8f9fa;
        }
        .product-info {
            padding: 1.25rem;
        }
        .product-name {
            font-size: 1.25rem;
            font-weight: 600;
            color: #2d5a2d;
            margin-bottom: 0.5rem;
        }
        .product-category {
            display: inline-block;
            background: #e8f5e8;
            color: #2d5a2d;
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.85rem;
            margin-bottom: 0.75rem;
        }
        .product-location {
            color: #666;
            font-size: 0.9rem;
            margin-bottom: 0.5rem;
        }
        .product-price {
            font-size: 1.5rem;
            font-weight: bold;
            color: #218838;
            margin: 0.75rem 0;
        }
        .product-stock {
            font-size: 0.9rem;
            color: #666;
            margin-bottom: 0.75rem;
        }
        
        /* REVIEW STYLES */
        .product-rating {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin: 0.75rem 0;
            cursor: pointer;
        }
        .stars {
            color: #ffc107;
            font-size: 1rem;
        }
        .rating-text {
            color: #666;
            font-size: 0.9rem;
        }
        
        .add-to-cart-btn {
            width: 100%;
            padding: 0.75rem;
            background: #2d5a2d;
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        .add-to-cart-btn:hover { background: #1a3d1a; }
        .add-to-cart-btn:disabled {
            background: #ccc;
            cursor: not-allowed;
        }

        .cart-section {
            position: sticky;
            top: 100px;
        }
        .cart-empty {
            text-align: center;
            color: #999;
            padding: 2rem;
            font-style: italic;
        }
        .cart-item-row {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            border-bottom: 1px solid #f0f0f0;
        }
        .cart-item-row img {
            width: 48px;
            height: 48px;
            border-radius: 8px;
            object-fit: cover;
        }
        .cart-info-main {
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        .cart-product-name {
            font-weight: 600;
            color: #2d5a2d;
        }
        .cart-product-price {
            font-size: 0.85rem;
            color: #666;
        }
        .cart-qty-controls {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .cart-qty-btn {
            width: 28px;
            height: 28px;
            border: none;
            background: #2d5a2d;
            color: white;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
        }
        .cart-qty-btn:hover { background: #1a3d1a; }
        .cart-qty-kg {
            min-width: 60px;
            text-align: center;
            font-weight: 600;
        }
        .cart-item-price {
            font-weight: bold;
            color: #218838;
            min-width: 80px;
            text-align: right;
        }
        .cart-delete-btn {
            background: #dc3545;
            color: white;
            border: none;
            padding: 0.5rem;
            border-radius: 5px;
            cursor: pointer;
        }
        .cart-delete-btn:hover { background: #c82333; }
        #cart-total-row {
            padding: 1rem;
            font-size: 1.25rem;
            font-weight: bold;
            text-align: right;
            border-top: 2px solid #2d5a2d;
            margin-top: 1rem;
        }
        #checkout-btn {
            width: 100%;
            padding: 1rem;
            background: #218838;
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1.1rem;
            font-weight: bold;
            cursor: pointer;
            margin-top: 1rem;
        }
        #checkout-btn:hover { background: #1a6928; }
        #checkout-btn:disabled {
            background: #ccc;
            cursor: not-allowed;
        }

        .order-card {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 1.25rem;
            margin-bottom: 1rem;
            border-left: 4px solid #2d5a2d;
        }
        .order-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        .order-id {
            font-weight: bold;
            color: #2d5a2d;
        }
        .order-status {
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.85rem;
            font-weight: 600;
        }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-confirmed { background: #d4edda; color: #155724; }
        .status-delivered { background: #cce5ff; color: #004085; }
        .order-items {
            margin: 0.75rem 0;
            padding-left: 1rem;
        }
        .order-items li {
            margin-bottom: 0.5rem;
            color: #666;
        }
        .order-total {
            font-weight: bold;
            color: #218838;
            margin-top: 0.75rem;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.6);
            align-items: center;
            justify-content: center;
        }
        .modal-content {
            background: white;
            padding: 2rem;
            border-radius: 20px;
            max-width: 500px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid #e8f5e8;
        }
        .modal-title {
            font-size: 1.5rem;
            color: #2d5a2d;
            font-weight: bold;
        }
        .close-modal {
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #999;
        }
        .close-modal:hover { color: #333; }
        
        /* Review Modal Styles */
        .review-form {
            margin-top: 1rem;
        }
        .star-rating {
            display: flex;
            gap: 0.5rem;
            font-size: 2rem;
            margin: 1rem 0;
            justify-content: center;
        }
        .star-rating i {
            cursor: pointer;
            color: #ddd;
            transition: color 0.2s;
        }
        .star-rating i.active,
        .star-rating i:hover {
            color: #ffc107;
        }
        .review-textarea {
            width: 100%;
            min-height: 120px;
            padding: 1rem;
            border: 2px solid #e8f5e8;
            border-radius: 10px;
            font-family: inherit;
            font-size: 1rem;
            resize: vertical;
        }
        .submit-review-btn {
            width: 100%;
            padding: 1rem;
            background: #2d5a2d;
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            margin-top: 1rem;
        }
        .submit-review-btn:hover {
            background: #1a3d1a;
        }
        
        .reviews-list {
            margin-top: 2rem;
        }
        .review-item {
            padding: 1.5rem;
            border-bottom: 1px solid #e8f5e8;
        }
        .review-item:last-child {
            border-bottom: none;
        }
        .review-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 0.75rem;
        }
        .reviewer-name {
            font-weight: 600;
            color: #2d5a2d;
        }
        .review-date {
            color: #999;
            font-size: 0.85rem;
        }
        .review-stars {
            color: #ffc107;
            margin-bottom: 0.5rem;
        }
        .review-text {
            color: #666;
            line-height: 1.6;
            margin-bottom: 0.75rem;
        }
        .verified-badge {
            display: inline-block;
            background: #28a745;
            color: white;
            padding: 0.25rem 0.5rem;
            border-radius: 5px;
            font-size: 0.75rem;
            margin-left: 0.5rem;
        }
        .helpful-btn {
            background: #f8f9fa;
            border: 1px solid #ddd;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.85rem;
            transition: all 0.2s;
        }
        .helpful-btn:hover {
            background: #e8f5e8;
        }
        .helpful-btn.marked {
            background: #2d5a2d;
            color: white;
            border-color: #2d5a2d;
        }
        .load-more-btn {
            width: 100%;
            padding: 0.75rem;
            background: #f8f9fa;
            border: 2px solid #e8f5e8;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            color: #2d5a2d;
            margin-top: 1rem;
        }
        .load-more-btn:hover {
            background: #e8f5e8;
        }
        
        .rating-summary {
            display: grid;
            grid-template-columns: auto 1fr auto;
            gap: 0.5rem;
            align-items: center;
            margin-bottom: 1rem;
            font-size: 0.9rem;
        }
        .rating-bar {
            height: 8px;
            background: #e8f5e8;
            border-radius: 4px;
            overflow: hidden;
        }
        .rating-bar-fill {
            height: 100%;
            background: #ffc107;
            transition: width 0.3s;
        }

        @media (max-width: 768px) {
            .products-grid {
                grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            }
            .dashboard-title {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <nav class="nav">
            <div class="logo">
                <img src="logo.png" alt="AgroConnect Logo" onerror="this.style.display='none'">
                <a href="home.php" style="text-decoration: none; color: inherit;">AgroConnect</a>
            </div>
            <ul class="nav-links">
                <li><a href="#products">Products</a></li>
                <li><a href="#cart">Cart</a></li>
                <li><a href="#orders">Orders</a></li>
                <li><a href="map.php"><i class="fas fa-map-marked-alt"></i> Track Deliveries</a></li>
            </ul>
            <div class="auth-buttons">
                <span style="margin-right: 1rem; color: #2d5a2d; font-weight: 600;">Welcome, <?php echo $userName; ?>!</span>
                <a href="logout.php" class="btn-logout">Logout</a>
            </div>
        </nav>
    </header>

    <div class="container">
        <?php if($missing_details): ?>
        <div style="background: #fff3cd; border: 2px solid #ffc107; padding: 1rem; border-radius: 10px; margin-bottom: 2rem; text-align: center;">
            <strong style="color: #856404;"><i class="fas fa-exclamation-triangle"></i> Action Required!</strong>
            <p style="color: #856404; margin: 0.5rem 0;">Please update your profile with phone number and delivery address to enable order delivery.</p>
            <a href="update_profile.php" style="display: inline-block; margin-top: 0.5rem; padding: 0.5rem 1.5rem; background: #ffc107; color: #000; border-radius: 25px; text-decoration: none; font-weight: bold;">Update Profile Now</a>
        </div>
        <?php endif; ?>
        
        <div id="notification-banner" style="display: none; background: #d4edda; border: 2px solid #28a745; padding: 1rem; border-radius: 10px; margin-bottom: 2rem; text-align: center;">
            <strong style="color: #155724;"><i class="fas fa-check-circle"></i> <span id="notification-text"></span></strong>
        </div>
        
        <div class="dashboard-header">
            <h1 class="dashboard-title">Buyer Dashboard</h1>
            <p class="dashboard-subtitle">Browse fresh produce and manage your orders</p>
        </div>

        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 2rem;">
            <!-- Products Section -->
            <div>
                <section id="products" class="section">
                    <h2 class="section-title"><i class="fas fa-leaf"></i> Available Products</h2>
                    
                    <div class="search-bar">
                        <input type="text" id="search-input" class="search-input" placeholder="🔍 Search products..." oninput="filterProducts()">
                        <select id="category-filter" class="filter-select" onchange="filterProducts()">
                            <option value="">All Categories</option>
                            <option value="Vegetables">Vegetables</option>
                            <option value="Fruits">Fruits</option>
                            <option value="Grains">Grains</option>
                            <option value="Dairy">Dairy</option>
                            <option value="Herbs">Herbs</option>
                        </select>
                        <select id="location-filter" class="filter-select" onchange="filterProducts()">
                            <option value="">All Locations</option>
                            <option value="Ampara">Ampara</option>
                            <option value="Anuradhapura">Anuradhapura</option>
                            <option value="Badulla">Badulla</option>
                            <option value="Batticaloa">Batticaloa</option>
                            <option value="Colombo">Colombo</option>
                            <option value="Galle">Galle</option>
                            <option value="Gampaha">Gampaha</option>
                            <option value="Hambantota">Hambantota</option>
                            <option value="Jaffna">Jaffna</option>
                            <option value="Kalutara">Kalutara</option>
                            <option value="Kandy">Kandy</option>
                            <option value="Kegalle">Kegalle</option>
                            <option value="Kilinochchi">Kilinochchi</option>
                            <option value="Kurunegala">Kurunegala</option>
                            <option value="Mannar">Mannar</option>
                            <option value="Matale">Matale</option>
                            <option value="Matara">Matara</option>
                            <option value="Monaragala">Monaragala</option>
                            <option value="Mullaitivu">Mullaitivu</option>
                            <option value="Nuwara Eliya">Nuwara Eliya</option>
                            <option value="Polonnaruwa">Polonnaruwa</option>
                            <option value="Puttalam">Puttalam</option>
                            <option value="Ratnapura">Ratnapura</option>
                            <option value="Trincomalee">Trincomalee</option>
                            <option value="Vavuniya">Vavuniya</option>

                        </select>
                    </div>

                    <div id="products-grid" class="products-grid"></div>
                </section>

                <!-- Orders Section -->
                <section id="orders" class="section">
                    <h2 class="section-title"><i class="fas fa-box"></i> My Orders</h2>
                    <?php if (empty($orders)): ?>
                        <div class="cart-empty">You haven't placed any orders yet. Start shopping!</div>
                    <?php else: ?>
                        <?php foreach ($orders as $order): ?>
                            <div class="order-card">
                                <div class="order-header">
                                    <span class="order-id">Order #<?php echo $order['id']; ?> - <?php echo date('M d, Y', strtotime($order['order_date'])); ?></span>
                                    <span class="order-status status-<?php echo strtolower($order['status']); ?>"><?php echo ucfirst($order['status']); ?></span>
                                </div>
                                <ul class="order-items">
                                    <?php foreach ($order['items'] as $item): ?>
                                        <li>
                                            <?php echo htmlspecialchars($item['name']); ?> × <?php echo $item['quantity']; ?> <?php echo htmlspecialchars($item['unit']); ?> 
                                            (Rs.<?php echo number_format($item['price_at_order'], 2); ?>)
                                            <?php if ($order['status'] == 'delivered'): ?>
                                                <button class="btn" style="margin-left: 0.5rem; padding: 0.25rem 0.75rem; font-size: 0.85rem;" 
                                                        onclick="openReviewModal(<?php echo $item['product_id']; ?>, '<?php echo htmlspecialchars($item['name']); ?>')">
                                                    ⭐ Write Review
                                                </button>
                                            <?php endif; ?>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                                <div class="order-total">Total: Rs.<?php echo number_format($order['total_amount'], 2); ?></div>
                                <div style="margin-top: 1rem; display: flex; gap: 0.5rem;">
                                    <a href="order_tracking.php?order_id=<?php echo $order['id']; ?>" 
                                       class="btn" style="padding: 0.5rem 1rem; font-size: 0.9rem; background: #007bff; color: white; text-decoration: none;">
                                        📍 Track Order
                                    </a>
                                    <span class="btn" style="padding: 0.5rem 1rem; font-size: 0.9rem; background: #2d5a2d; color: white; cursor: pointer;" 
                                            onclick="viewOrderDetails(<?php echo $order['id']; ?>)">
                                        👁️ View Details
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </section>

                <!-- Delivery Partners Section -->
                <section class="section">
                    <h2 class="section-title"><i class="fas fa-truck"></i> Available Delivery Partners</h2>
                    <?php if (empty($delivery_partners)): ?>
                        <div class="cart-empty">No delivery partners available at the moment.</div>
                    <?php else: ?>
                        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 1rem;">
                            <?php foreach ($delivery_partners as $partner): ?>
                                <div style="background: #f8f9fa; border-radius: 10px; padding: 1rem; border-left: 4px solid #007bff;">
                                    <div style="display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.5rem;">
                                        <div style="width: 40px; height: 40px; background: #007bff; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 1.2rem;">
                                            <i class="fas fa-truck"></i>
                                        </div>
                                        <div>
                                            <h4 style="margin: 0; color: #007bff; font-size: 1rem;"><?php echo htmlspecialchars($partner['name']); ?></h4>
                                            <?php if(!empty($partner['phone'])): ?>
                                                <a href="tel:<?php echo htmlspecialchars($partner['phone']); ?>" style="font-size: 0.85rem; color: #666; text-decoration: none;">
                                                    <i class="fas fa-phone"></i> <?php echo htmlspecialchars($partner['phone']); ?>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </section>
            </div>

            <!-- Cart Section -->
            <div>
                <section id="cart" class="section cart-section">
                    <h2 class="section-title"><i class="fas fa-shopping-cart"></i> Shopping Cart</h2>
                    <div id="cart-items"></div>
                    <div id="cart-total-row"></div>
                    <button id="checkout-btn" onclick="showCheckoutModal()" disabled>Proceed to Checkout</button>
                </section>
            </div>
        </div>
    </div>

    <!-- Checkout Modal -->
    <div id="checkoutModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Confirm Your Order</h2>
                <button class="close-modal" onclick="hideCheckoutModal()">&times;</button>
            </div>
            <h3 style="margin-bottom: 1rem;">Order Summary:</h3>
            <ul id="modal-cart-items-list" style="margin-bottom: 1rem;"></ul>
            <p style="font-size: 1.25rem; font-weight: bold; margin: 1rem 0;">
                Total: <span id="modal-cart-total" style="color: #218838;"></span>
            </p>
            
            <div style="margin: 1.5rem 0;">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600; color: #2d5a2d;">
                    <i class="fas fa-truck"></i> Select Delivery Partner: (<?php echo count($delivery_partners); ?> available)
                </label>
                <?php if(empty($delivery_partners)): ?>
                    <p style="color: #dc3545; padding: 0.75rem; background: #f8d7da; border-radius: 10px;">
                        <i class="fas fa-exclamation-circle"></i> No delivery partners available. Please contact support.
                    </p>
                <?php else: ?>
                <select id="delivery-partner-select" style="width: 100%; padding: 0.75rem; border: 2px solid #e8f5e8; border-radius: 10px; font-size: 1rem;">
                    <option value="">-- Choose a delivery partner --</option>
                    <?php foreach($delivery_partners as $partner): ?>
                    <option value="<?php echo $partner['id']; ?>">
                        <?php echo htmlspecialchars($partner['name']); ?>
                        <?php if(!empty($partner['phone'])): ?>
                            - 📞 <?php echo htmlspecialchars($partner['phone']); ?>
                        <?php endif; ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                <?php endif; ?>
            </div>
            
            <button class="btn-register" style="width: 100%; padding: 1rem; font-size: 1rem;" onclick="proceedToCheckout()">
                Complete Order
            </button>
        </div>
    </div>

    <!-- Review Modal -->
    <div id="reviewModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Write a Review</h2>
                <button class="close-modal" onclick="closeReviewModal()">&times;</button>
            </div>
            <div id="review-product-name" style="font-weight: 600; color: #666; margin-bottom: 1rem;"></div>
            
            <form class="review-form" id="reviewForm">
                <input type="hidden" id="review-product-id">
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Your Rating:</label>
                <div class="star-rating" id="starRating">
                    <i class="fas fa-star" data-rating="1"></i>
                    <i class="fas fa-star" data-rating="2"></i>
                    <i class="fas fa-star" data-rating="3"></i>
                    <i class="fas fa-star" data-rating="4"></i>
                    <i class="fas fa-star" data-rating="5"></i>
                </div>
                <input type="hidden" id="selected-rating" value="0">
                
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">Your Review:</label>
                <textarea id="review-text" class="review-textarea" placeholder="Share your experience with this product..." required></textarea>
                
                <button type="submit" class="submit-review-btn">Submit Review</button>
            </form>
        </div>
    </div>

    <!-- Product Reviews Modal -->
    <div id="productReviewsModal" class="modal">
        <div class="modal-content" style="max-width: 700px;">
            <div class="modal-header">
                <h2 class="modal-title" id="reviews-modal-title">Product Reviews</h2>
                <button class="close-modal" onclick="closeProductReviewsModal()">&times;</button>
            </div>
            
            <div id="rating-summary-container"></div>
            
            <div class="reviews-list" id="reviews-list-container"></div>
            
            <button id="load-more-reviews" class="load-more-btn" style="display: none;">Load More Reviews</button>
        </div>
    </div>

    <!-- Order Details Modal -->
    <div id="orderDetailsModal" class="modal">
        <div class="modal-content" style="max-width: 600px;">
            <div class="modal-header">
                <h2 class="modal-title">Order Details</h2>
                <button class="close-modal" onclick="closeOrderDetailsModal()">&times;</button>
            </div>
            <div id="order-details-content"></div>
        </div>
    </div>

    <script>
        const productsData = <?php echo json_encode($products); ?>;
        console.log('Products loaded:', productsData.length, productsData);
        let allProducts = productsData;
        let cart = [];
        let cartTotal = 0;
        let currentReviewProductId = null;
        let currentReviewOffset = 0;
        const REVIEWS_PER_PAGE = 5;

        // Star rating functionality
        document.addEventListener('DOMContentLoaded', function() {
            const stars = document.querySelectorAll('#starRating i');
            stars.forEach(star => {
                star.addEventListener('click', function() {
                    const rating = this.getAttribute('data-rating');
                    document.getElementById('selected-rating').value = rating;
                    updateStarDisplay(rating);
                });
                
                star.addEventListener('mouseenter', function() {
                    const rating = this.getAttribute('data-rating');
                    updateStarDisplay(rating);
                });
            });
            
            document.getElementById('starRating').addEventListener('mouseleave', function() {
                const selectedRating = document.getElementById('selected-rating').value;
                updateStarDisplay(selectedRating);
            });
        });

        function updateStarDisplay(rating) {
            const stars = document.querySelectorAll('#starRating i');
            stars.forEach((star, index) => {
                if (index < rating) {
                    star.classList.add('active');
                } else {
                    star.classList.remove('active');
                }
            });
        }

        // Review form submission
        document.getElementById('reviewForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const productId = document.getElementById('review-product-id').value;
            const rating = document.getElementById('selected-rating').value;
            const reviewText = document.getElementById('review-text').value;
            
            if (rating == 0) {
                alert('Please select a rating');
                return;
            }
            
            if (reviewText.trim().length < 10) {
                alert('Please write at least 10 characters in your review');
                return;
            }
            
            const formData = new FormData();
            formData.append('action', 'submit_review');
            formData.append('product_id', productId);
            formData.append('rating', rating);
            formData.append('review_text', reviewText);
            
            fetch('review_handler.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    closeReviewModal();
                    // Refresh products to show updated rating
                    location.reload();
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            });
        });

        function openReviewModal(productId, productName) {
            document.getElementById('review-product-id').value = productId;
            document.getElementById('review-product-name').textContent = productName;
            document.getElementById('review-text').value = '';
            document.getElementById('selected-rating').value = 0;
            updateStarDisplay(0);
            document.getElementById('reviewModal').style.display = 'flex';
        }

        function closeReviewModal() {
            document.getElementById('reviewModal').style.display = 'none';
        }

        function openProductReviewsModal(productId, productName) {
            currentReviewProductId = productId;
            currentReviewOffset = 0;
            document.getElementById('reviews-modal-title').textContent = `Reviews for ${productName}`;
            document.getElementById('productReviewsModal').style.display = 'flex';
            
            // Load rating summary
            loadRatingSummary(productId);
            
            // Load reviews
            loadReviews(productId, true);
        }

        function closeProductReviewsModal() {
            document.getElementById('productReviewsModal').style.display = 'none';
        }

        function loadRatingSummary(productId) {
            const formData = new FormData();
            formData.append('action', 'get_product_rating');
            formData.append('product_id', productId);
            
            fetch('review_handler.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    const data = result.data;
                    const avgRating = parseFloat(data.average_rating).toFixed(1);
                    const total = parseInt(data.total_reviews);
                    
                    let summaryHTML = `
                        <div style="text-align: center; padding: 1.5rem; background: #f8f9fa; border-radius: 10px; margin-bottom: 1.5rem;">
                            <div style="font-size: 3rem; font-weight: bold; color: #2d5a2d;">${avgRating}</div>
                            <div style="color: #ffc107; font-size: 1.5rem; margin: 0.5rem 0;">${getStarHTML(avgRating)}</div>
                            <div style="color: #666;">${total} ${total === 1 ? 'review' : 'reviews'}</div>
                        </div>
                    `;
                    
                    if (total > 0) {
                        summaryHTML += '<div style="margin-bottom: 1.5rem;">';
                        for (let i = 5; i >= 1; i--) {
                            const count = parseInt(data[`rating_${i}`]);
                            const percentage = (count / total) * 100;
                            summaryHTML += `
                                <div class="rating-summary">
                                    <div>${i} ⭐</div>
                                    <div class="rating-bar">
                                        <div class="rating-bar-fill" style="width: ${percentage}%"></div>
                                    </div>
                                    <div>${count}</div>
                                </div>
                            `;
                        }
                        summaryHTML += '</div>';
                    }
                    
                    document.getElementById('rating-summary-container').innerHTML = summaryHTML;
                }
            });
        }

        function loadReviews(productId, reset = false) {
            if (reset) {
                currentReviewOffset = 0;
                document.getElementById('reviews-list-container').innerHTML = '<div style="text-align: center; padding: 2rem; color: #999;">Loading reviews...</div>';
            }
            
            const formData = new FormData();
            formData.append('action', 'get_reviews');
            formData.append('product_id', productId);
            formData.append('limit', REVIEWS_PER_PAGE);
            formData.append('offset', currentReviewOffset);
            
            fetch('review_handler.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    let reviewsHTML = '';
                    
                    if (data.reviews.length === 0 && currentReviewOffset === 0) {
                        reviewsHTML = '<div style="text-align: center; padding: 2rem; color: #999;">No reviews yet. Be the first to review this product!</div>';
                    } else {
                        data.reviews.forEach(review => {
                            const date = new Date(review.created_at).toLocaleDateString();
                            const verifiedBadge = review.verified_purchase == 1 ? '<span class="verified-badge">✓ Verified Purchase</span>' : '';
                            const helpfulClass = review.user_marked_helpful == 1 ? 'marked' : '';
                            const farmerInfo = review.farmer_name ? `<div style="margin-top: 0.5rem; padding: 0.5rem; background: #f0f9f0; border-radius: 5px; font-size: 0.85rem;"><i class="fas fa-tractor" style="color: #2d5a2d;"></i> <strong>Farmer:</strong> ${review.farmer_name}${review.farmer_location ? ` <i class="fas fa-map-marker-alt" style="color: #666;"></i> ${review.farmer_location}` : ''}</div>` : '';
                            
                            reviewsHTML += `
                                <div class="review-item">
                                    <div class="review-header">
                                        <span class="reviewer-name">${review.user_name}${verifiedBadge}</span>
                                        <span class="review-date">${date}</span>
                                    </div>
                                    <div class="review-stars">${getStarHTML(review.rating)}</div>
                                    <div class="review-text">${review.review_text}</div>
                                    ${farmerInfo}
                                    <button class="helpful-btn ${helpfulClass}" onclick="markHelpful(${review.id}, this)">
                                        <i class="fas fa-thumbs-up"></i> Helpful (${review.helpful_count})
                                    </button>
                                </div>
                            `;
                        });
                    }
                    
                    if (reset) {
                        document.getElementById('reviews-list-container').innerHTML = reviewsHTML;
                    } else {
                        document.getElementById('reviews-list-container').innerHTML += reviewsHTML;
                    }
                    
                    // Show/hide load more button
                    const loadMoreBtn = document.getElementById('load-more-reviews');
                    if (data.has_more) {
                        loadMoreBtn.style.display = 'block';
                        loadMoreBtn.onclick = function() {
                            currentReviewOffset += REVIEWS_PER_PAGE;
                            loadReviews(productId, false);
                        };
                    } else {
                        loadMoreBtn.style.display = 'none';
                    }
                }
            });
        }

        function markHelpful(reviewId, button) {
            const formData = new FormData();
            formData.append('action', 'mark_helpful');
            formData.append('review_id', reviewId);
            
            fetch('review_handler.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Reload reviews to update count and button state
                    loadReviews(currentReviewProductId, true);
                }
            });
        }

        function getStarHTML(rating) {
            const fullStars = Math.floor(rating);
            const hasHalfStar = rating % 1 >= 0.5;
            let html = '';
            
            for (let i = 0; i < fullStars; i++) {
                html += '<i class="fas fa-star"></i>';
            }
            if (hasHalfStar) {
                html += '<i class="fas fa-star-half-alt"></i>';
            }
            const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
            for (let i = 0; i < emptyStars; i++) {
                html += '<i class="far fa-star"></i>';
            }
            
            return html;
        }

        function renderProducts(products) {
            const grid = document.getElementById('products-grid');
            if (products.length === 0) {
                grid.innerHTML = '<div class="cart-empty">No products found matching your criteria.</div>';
                return;
            }

            let html = '';
            products.forEach(p => {
                const imgSrc = p.image_path && p.image_path !== 'https://via.placeholder.com/90x90?text=No+Image' 
                    ? p.image_path 
                    : 'https://via.placeholder.com/280x200?text=' + encodeURIComponent(p.name);
                const emoji = getCategoryEmoji(p.category);
                const stock = parseInt(p.stock_quantity);
                const stockClass = stock > 0 ? '' : 'Out of Stock';
                const btnDisabled = stock > 0 ? '' : 'disabled';
                
                // Rating display
                const avgRating = parseFloat(p.avg_rating).toFixed(1);
                const reviewCount = parseInt(p.review_count);
                const ratingHTML = reviewCount > 0 
                    ? `<div class="product-rating" onclick="openProductReviewsModal(${p.id}, '${p.name.replace(/'/g, "\\'")}')">
                        <div class="stars">${getStarHTML(avgRating)}</div>
                        <div class="rating-text">${avgRating} (${reviewCount} ${reviewCount === 1 ? 'review' : 'reviews'})</div>
                       </div>`
                    : `<div class="product-rating" onclick="openProductReviewsModal(${p.id}, '${p.name.replace(/'/g, "\\'")}')">
                        <div class="rating-text" style="color: #999;">No reviews yet</div>
                       </div>`;

                html += `
                    <div class="product-card">
                        <img src="${imgSrc}" alt="${p.name}" class="product-image" onerror="this.src='https://via.placeholder.com/280x200?text=${encodeURIComponent(p.name)}'">
                        <div class="product-info">
                            <div class="product-name">${p.name}</div>
                            <span class="product-category">${emoji} ${p.category}</span>
                            ${ratingHTML}
                            <div class="product-location">📍 ${p.location}</div>
                            <div class="product-price">Rs.${parseFloat(p.price).toFixed(2)}/${p.unit}</div>
                            <div class="product-stock">${stockClass || 'Stock: ' + stock + ' ' + p.unit}</div>
                            <button class="add-to-cart-btn" ${btnDisabled} 
                                onclick="addToCart(${p.id}, '${p.name.replace(/'/g, "\\'")}', ${p.price}, '${p.unit}', '${imgSrc}', ${stock})">
                                ${stock > 0 ? '🛒 Add to Cart' : 'Out of Stock'}
                            </button>
                        </div>
                    </div>
                `;
            });
            grid.innerHTML = html;
        }

        function getCategoryEmoji(category) {
            switch (category) {
                case 'Vegetables': return '🥬';
                case 'Fruits': return '🍎';
                case 'Grains': return '🌾';
                case 'Dairy': return '🥛';
                case 'Herbs': return '🌿';
                default: return '📦';
            }
        }

        function filterProducts() {
            const searchTerm = document.getElementById('search-input').value.toLowerCase();
            const categoryFilter = document.getElementById('category-filter').value;
            const locationFilter = document.getElementById('location-filter').value;

            const filtered = allProducts.filter(product => {
                const matchesSearch = product.name.toLowerCase().includes(searchTerm);
                const matchesCategory = categoryFilter === "" || product.category === categoryFilter;
                const matchesLocation = locationFilter === "" || product.location === locationFilter;
                return matchesSearch && matchesCategory && matchesLocation;
            });
            renderProducts(filtered);
        }

        function addToCart(productId, productName, price, unit, img, availableStock) {
            const existingItem = cart.find(item => item.productId === productId);
            let quantityToAdd = 1;

            if (existingItem) {
                quantityToAdd = existingItem.quantity + 1;
            }

            if (quantityToAdd > availableStock) {
                alert(`Cannot add more ${productName}. Only ${availableStock} ${unit} available.`);
                return;
            }

            if (existingItem) {
                existingItem.quantity = quantityToAdd;
                existingItem.total = existingItem.quantity * existingItem.price;
            } else {
                cart.push({
                    productId: productId,
                    name: productName,
                    price: price,
                    unit: unit,
                    quantity: quantityToAdd,
                    total: price,
                    img: img,
                    availableStock: availableStock
                });
            }
            updateCartDisplay();
            saveCart();

            const button = event.target;
            const originalText = button.textContent;
            button.textContent = '✓ Added!';
            button.style.background = '#28a745';
            setTimeout(() => {
                button.textContent = originalText;
                button.style.background = '#2d5a2d';
            }, 900);
        }

        function changeQty(productId, delta) {
            const item = cart.find(item => item.productId === productId);
            if (!item) return;

            const newQuantity = item.quantity + delta;

            if (newQuantity < 1) {
                removeFromCart(productId);
                return;
            }

            if (newQuantity > item.availableStock) {
                alert(`Cannot add more ${item.name}. Only ${item.availableStock} ${item.unit} available.`);
                return;
            }

            item.quantity = newQuantity;
            item.total = item.quantity * item.price;
            updateCartDisplay();
            saveCart();
        }

        function removeFromCart(productId) {
            const idx = cart.findIndex(item => item.productId === productId);
            if (idx > -1) {
                cart.splice(idx, 1);
                updateCartDisplay();
                saveCart();
            }
        }

        function updateCartDisplay() {
            const cartItemsContainer = document.getElementById('cart-items');
            const checkoutBtn = document.getElementById('checkout-btn');
            const totalRow = document.getElementById('cart-total-row');

            if (cart.length === 0) {
                cartItemsContainer.innerHTML = '<div class="cart-empty">Your cart is currently empty. Start adding some fresh produce!</div>';
                totalRow.textContent = "";
                checkoutBtn.disabled = true;
                return;
            }

            cartTotal = cart.reduce((sum, item) => sum + item.total, 0);

            let cartHTML = '';
            cart.forEach(item => {
                const itemImg = item.img && item.img !== 'https://via.placeholder.com/90x90?text=No+Image' ? item.img : 'https://via.placeholder.com/48?text=🥕';
                cartHTML += `
                    <div class="cart-item-row">
                        <img src="${itemImg}" alt="${item.name}" onerror="this.onerror=null;this.src='https://via.placeholder.com/48?text=🥕';">
                        <div class="cart-info-main">
                            <span class="cart-product-name">${item.name}</span>
                            <span class="cart-product-price">(Rs.${parseFloat(item.price).toFixed(2)}/${item.unit})</span>
                        </div>
                        <div class="cart-qty-controls">
                            <button class="cart-qty-btn" onclick="changeQty(${item.productId},-1)">-</button>
                            <span class="cart-qty-kg">${item.quantity} ${item.unit}</span>
                            <button class="cart-qty-btn" onclick="changeQty(${item.productId},1)">+</button>
                        </div>
                        <div class="cart-item-price">Rs.${item.total.toFixed(2)}</div>
                        <button class="cart-delete-btn" title="Remove" onclick="removeFromCart(${item.productId})"><i class="fa fa-trash"></i></button>
                    </div>
                `;
            });
            cartItemsContainer.innerHTML = cartHTML;
            totalRow.innerHTML = `Total: <span style="color:#218838;">Rs.${cartTotal.toFixed(2)}</span>`;
            checkoutBtn.disabled = false;
        }

        function saveCart() {
            localStorage.setItem('agroconnect_cart', JSON.stringify(cart));
        }

        function loadCart() {
            const saved = localStorage.getItem('agroconnect_cart');
            if (saved) {
                cart = JSON.parse(saved);
                updateCartDisplay();
            }
            renderProducts(allProducts);
        }

        function showCheckoutModal() {
            if (cart.length === 0) return;

            const modal = document.getElementById('checkoutModal');
            const modalCartItemsList = document.getElementById('modal-cart-items-list');
            const modalCartTotal = document.getElementById('modal-cart-total');

            let modalItemsHTML = '';
            cart.forEach(item => {
                modalItemsHTML += `<li>${item.name} × ${item.quantity} ${item.unit} (Rs.${item.total.toFixed(2)})</li>`;
            });
            modalCartItemsList.innerHTML = modalItemsHTML;
            modalCartTotal.textContent = `Rs.${cartTotal.toFixed(2)}`;

            modal.style.display = 'flex';
        }

        function hideCheckoutModal() {
            document.getElementById('checkoutModal').style.display = 'none';
        }

        function proceedToCheckout() {
            if (cart.length === 0) return;
            
            const deliveryPartnerId = document.getElementById('delivery-partner-select').value;
            if (!deliveryPartnerId) {
                alert('Please select a delivery partner');
                return;
            }

            // Get buyer address and farmer location
            const buyerAddress = '<?php echo addslashes($user_check['address'] ?? ''); ?>';
            const farmerLocation = cart.length > 0 ? (allProducts.find(p => p.id === cart[0].productId)?.location || '') : '';

            const checkoutData = {
                cart: cart,
                total: cartTotal,
                delivery_partner_id: deliveryPartnerId,
                buyer_address: buyerAddress,
                farmer_location: farmerLocation
            };

            fetch('checkout.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(checkoutData),
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.text();
            })
            .then(text => {
                const response = JSON.parse(text);
                if (response.success) {
                    localStorage.removeItem('agroconnect_cart');
                    cart = [];
                    updateCartDisplay();
                    hideCheckoutModal();
                    window.location.href = response.redirect;
                } else {
                    alert(response.message || 'Checkout failed');
                    hideCheckoutModal();
                }
            })
            .catch(error => {
                console.error('Error during checkout:', error);
                alert('There was an error processing your order. Please try again.');
                hideCheckoutModal();
            });
        }

        window.onload = loadCart;
        
        // View order details function
        function viewOrderDetails(orderId) {
            const orders = <?php echo json_encode($orders); ?>;
            const order = orders.find(o => o.id == orderId);
            
            if (!order) {
                alert('Order not found. Order ID: ' + orderId);
                console.error('Available orders:', orders);
                return;
            }
            
            console.log('Viewing order:', order);
            
            let itemsHTML = '<ul style="list-style: none; padding: 0;">';
            order.items.forEach(item => {
                const itemTotal = parseFloat(item.quantity) * parseFloat(item.price_at_order);
                itemsHTML += `
                    <li style="padding: 0.75rem; border-bottom: 1px solid #f0f0f0; display: flex; justify-content: space-between;">
                        <div>
                            <strong>` + item.name + `</strong><br>
                            <span style="color: #666; font-size: 0.9rem;">` + item.quantity + ` ` + item.unit + ` @ Rs.` + parseFloat(item.price_at_order).toFixed(2) + `/` + item.unit + `</span>
                        </div>
                        <div style="font-weight: bold; color: #218838;">
                            Rs.` + itemTotal.toFixed(2) + `
                        </div>
                    </li>
                `;
            });
            itemsHTML += '</ul>';
            
            const statusColors = {
                'pending': '#ffc107',
                'processing': '#17a2b8',
                'confirmed': '#28a745',
                'shipped': '#007bff',
                'delivered': '#28a745',
                'cancelled': '#dc3545'
            };
            
            const statusColor = statusColors[order.status.toLowerCase()] || '#6c757d';
            const orderDate = new Date(order.order_date);
            const formattedDate = orderDate.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
            const statusText = order.status.charAt(0).toUpperCase() + order.status.slice(1);
            
            const detailsHTML = `
                <div style="margin-bottom: 1.5rem;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; padding-bottom: 1rem; border-bottom: 2px solid #e8f5e8;">
                        <div>
                            <h3 style="margin: 0; color: #2d5a2d;">Order #` + order.id + `</h3>
                            <p style="margin: 0.25rem 0 0 0; color: #666; font-size: 0.9rem;">` + formattedDate + `</p>
                        </div>
                        <span style="padding: 0.5rem 1rem; background: ` + statusColor + `; color: white; border-radius: 20px; font-weight: 600; font-size: 0.9rem;">
                            ` + statusText + `
                        </span>
                    </div>
                    
                    <h4 style="margin: 1.5rem 0 0.75rem 0; color: #2d5a2d;">Order Items</h4>
                    ` + itemsHTML + `
                    
                    <div style="margin-top: 1.5rem; padding-top: 1rem; border-top: 2px solid #2d5a2d; display: flex; justify-content: space-between; align-items: center;">
                        <span style="font-size: 1.25rem; font-weight: bold;">Total Amount:</span>
                        <span style="font-size: 1.5rem; font-weight: bold; color: #218838;">Rs.` + parseFloat(order.total_amount).toFixed(2) + `</span>
                    </div>
                    
                    <div style="margin-top: 1.5rem; display: flex; gap: 0.5rem;">
                        <a href="order_tracking.php?order_id=` + order.id + `" 
                           style="flex: 1; padding: 0.75rem; background: #007bff; color: white; text-align: center; border-radius: 10px; text-decoration: none; font-weight: 600;">
                            📍 Track Order
                        </a>
                    </div>
                </div>
            `;
            
            document.getElementById('order-details-content').innerHTML = detailsHTML;
            document.getElementById('orderDetailsModal').style.display = 'flex';
        }
        
        function closeOrderDetailsModal() {
            document.getElementById('orderDetailsModal').style.display = 'none';
        }
        
        // Check for new notifications
        function checkNotifications() {
            // Check if notifications table exists first
            fetch('notifications.php')
                .then(r => r.json())
                .then(data => {
                    if (data.success && data.notifications && data.notifications.length > 0) {
                        const banner = document.getElementById('notification-banner');
                        const text = document.getElementById('notification-text');
                        if (banner && text) {
                            text.textContent = data.notifications[0].message;
                            banner.style.display = 'block';
                            
                            // Mark as read after 5 seconds
                            setTimeout(() => {
                                fetch('notifications.php', {
                                    method: 'POST',
                                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                                    body: 'mark_read=1'
                                });
                                banner.style.display = 'none';
                            }, 5000);
                        }
                    }
                })
                .catch(err => console.log('Notifications not available yet'));
        }
        
        checkNotifications();
        setInterval(checkNotifications, 30000); // Check every 30 seconds
    </script>
</body>
</html>