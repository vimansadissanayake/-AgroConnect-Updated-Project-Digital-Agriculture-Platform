<?php
session_start();
include 'db.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'Buyer') {
    header("Location: login.php");
    exit();
}

$user_id    = $_SESSION['user_id'];
$order_id   = $_GET['order_id']   ?? null;
$product_id = $_GET['product_id'] ?? null;

if (!$order_id || !$product_id) {
    header("Location: buyer.php");
    exit();
}

// Verify purchase and delivered status
$verify_sql = "
    SELECT oi.*, p.name AS product_name, p.farmer_id, u.name AS farmer_name 
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    JOIN users u ON p.farmer_id = u.id
    JOIN orders o ON oi.order_id = o.id
    WHERE oi.order_id = ? 
      AND oi.product_id = ? 
      AND o.user_id = ? 
      AND o.status = 'delivered'
";
$stmt = $conn->prepare($verify_sql);
$stmt->bind_param("iii", $order_id, $product_id, $user_id);
$stmt->execute();
$product_info = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$product_info) {
    $error = "You can only review products you have purchased and received (delivered).";
}

// Check if already reviewed
$check_sql = "SELECT id FROM reviews WHERE product_id = ? AND user_id = ?";
$stmt = $conn->prepare($check_sql);
$stmt->bind_param("ii", $product_id, $user_id);
$stmt->execute();
$existing = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($existing) {
    $error = "You have already submitted a review for this product.";
}

$success_message = '';
$error_message   = $error ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($error)) {
    $rating           = intval($_POST['rating'] ?? 0);
    $quality_rating   = intval($_POST['quality_rating'] ?? 0);
    $delivery_rating  = intval($_POST['delivery_rating'] ?? 0);
    $review_text      = trim($_POST['review_text'] ?? '');

    if ($rating < 1 || $rating > 5) {
        $error_message = "Please select a valid overall rating (1-5 stars).";
    } else {
        $conn->begin_transaction();
        try {
            // Get farmer_id from product_info
            $farmer_id = $product_info['farmer_id'];
            
            $sql = "
                INSERT INTO reviews (
                    user_id, product_id, farmer_id,
                    rating, quality_rating, delivery_rating, 
                    review_text, created_at, verified_purchase
                ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), TRUE)
            ";
            $stmt = $conn->prepare($sql);
            if (!$stmt) {
                throw new Exception("Prepare failed: " . $conn->error);
            }

            $stmt->bind_param("iiiiiis",
                $user_id,
                $product_id,
                $farmer_id,
                $rating,
                $quality_rating,
                $delivery_rating,
                $review_text
            );

            if (!$stmt->execute()) {
                throw new Exception("Insert failed: " . $stmt->error);
            }

            $conn->commit();
            $success_message = "Thank you! Your review has been submitted successfully.";
            
            // Redirect after 2 seconds
            header("refresh:2;url=buyer.php?review=success");
        } catch (Exception $e) {
            $conn->rollback();
            $error_message = "Error saving review: " . $e->getMessage();
            error_log("Review submission error: " . $e->getMessage());
        }
        if (isset($stmt)) $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Review Product - AgroConnect</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        body { font-family: 'Poppins', sans-serif; }
        .star-rating i {
            transition: all 0.2s ease;
        }
        .star-rating i:hover {
            transform: scale(1.2);
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">

<div class="max-w-3xl mx-auto py-10 px-4 sm:px-6 lg:px-8">

    <div class="bg-white shadow-xl rounded-2xl p-8">

        <h1 class="text-3xl font-bold text-gray-800 mb-6">
            <i class="fas fa-star text-yellow-500 mr-2"></i>Review Your Purchase
        </h1>

        <?php if ($success_message): ?>
            <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded-lg">
                <div class="flex items-center">
                    <i class="fas fa-check-circle text-2xl mr-3"></i>
                    <div>
                        <p class="font-bold"><?= htmlspecialchars($success_message) ?></p>
                        <p class="text-sm mt-1">Redirecting to your dashboard...</p>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($error_message): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-lg">
                <div class="flex items-center">
                    <i class="fas fa-exclamation-triangle text-2xl mr-3"></i>
                    <div>
                        <p class="font-bold"><?= htmlspecialchars($error_message) ?></p>
                        <a href="buyer.php" class="text-sm underline mt-2 inline-block">Back to Orders</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if (empty($error) && empty($success_message)): ?>
            <div class="mb-6 bg-blue-50 p-4 rounded-lg border border-blue-200">
                <h2 class="text-xl font-semibold text-blue-900"><?= htmlspecialchars($product_info['product_name'] ?? 'Product') ?></h2>
                <p class="text-blue-700 mt-1">
                    <i class="fas fa-user-tie mr-1"></i>
                    Sold by: <?= htmlspecialchars($product_info['farmer_name'] ?? 'Farmer') ?>
                </p>
            </div>

            <form method="POST" class="space-y-8" onsubmit="return validateForm()">

                <!-- Overall Rating -->
                <div>
                    <label class="block text-lg font-medium text-gray-700 mb-3">
                        Overall Rating <span class="text-red-500">*</span>
                    </label>
                    <div class="flex space-x-2 star-rating" id="rating-stars">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <i class="fas fa-star fa-2x cursor-pointer text-gray-300 hover:text-yellow-400 transition" 
                               data-rating="<?= $i ?>"></i>
                        <?php endfor; ?>
                    </div>
                    <input type="hidden" name="rating" id="rating-input" value="0" required />
                    <p class="text-sm text-gray-500 mt-2">Click stars to rate</p>
                </div>

                <!-- Quality Rating -->
                <div>
                    <label class="block text-lg font-medium text-gray-700 mb-3">
                        Product Quality <span class="text-gray-400">(optional)</span>
                    </label>
                    <div class="flex space-x-2 star-rating" id="quality-stars">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <i class="fas fa-star fa-2x cursor-pointer text-gray-300 hover:text-yellow-400 transition" 
                               data-rating="<?= $i ?>"></i>
                        <?php endfor; ?>
                    </div>
                    <input type="hidden" name="quality_rating" id="quality-input" value="0" />
                </div>

                <!-- Delivery Rating -->
                <div>
                    <label class="block text-lg font-medium text-gray-700 mb-3">
                        Delivery Experience <span class="text-gray-400">(optional)</span>
                    </label>
                    <div class="flex space-x-2 star-rating" id="delivery-stars">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <i class="fas fa-star fa-2x cursor-pointer text-gray-300 hover:text-yellow-400 transition" 
                               data-rating="<?= $i ?>"></i>
                        <?php endfor; ?>
                    </div>
                    <input type="hidden" name="delivery_rating" id="delivery-input" value="0" />
                </div>

                <!-- Review Text -->
                <div>
                    <label class="block text-lg font-medium text-gray-700 mb-3">
                        Your Review <span class="text-gray-400">(optional)</span>
                    </label>
                    <textarea name="review_text" rows="5"
                              class="w-full border-2 border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-green-500 focus:border-green-500 transition"
                              placeholder="Share your experience with this product..."></textarea>
                    <p class="text-sm text-gray-500 mt-2">Help other buyers by sharing your honest opinion</p>
                </div>

                <div class="flex gap-3">
                    <button type="submit"
                            class="flex-1 bg-green-600 text-white py-3 rounded-lg font-medium hover:bg-green-700 transition transform hover:scale-105 shadow-lg">
                        <i class="fas fa-paper-plane mr-2"></i>Submit Review
                    </button>
                    <a href="buyer.php" 
                       class="flex-1 bg-gray-200 text-gray-700 py-3 rounded-lg font-medium hover:bg-gray-300 transition text-center">
                        <i class="fas fa-times mr-2"></i>Cancel
                    </a>
                </div>
            </form>
        <?php endif; ?>

        <div class="mt-8 text-center">
            <a href="buyer.php" class="text-green-600 hover:underline font-medium">
                <i class="fas fa-arrow-left mr-1"></i> Back to My Orders
            </a>
        </div>

    </div>
</div>

<script>
    function setupStarRating(containerId, inputId) {
        const container = document.getElementById(containerId);
        const input = document.getElementById(inputId);
        const stars = container.querySelectorAll('.fa-star');

        stars.forEach(star => {
            star.addEventListener('click', function() {
                const rating = this.getAttribute('data-rating');
                input.value = rating;

                stars.forEach(s => {
                    if (s.getAttribute('data-rating') <= rating) {
                        s.classList.remove('text-gray-300');
                        s.classList.add('text-yellow-400');
                    } else {
                        s.classList.remove('text-yellow-400');
                        s.classList.add('text-gray-300');
                    }
                });
            });

            star.addEventListener('mouseover', function() {
                const rating = this.getAttribute('data-rating');
                stars.forEach(s => {
                    if (s.getAttribute('data-rating') <= rating) {
                        s.classList.remove('text-gray-300');
                        s.classList.add('text-yellow-400');
                    } else {
                        s.classList.remove('text-yellow-400');
                        s.classList.add('text-gray-300');
                    }
                });
            });
        });

        container.addEventListener('mouseleave', function() {
            const current = input.value;
            stars.forEach(s => {
                if (current && s.getAttribute('data-rating') <= current) {
                    s.classList.remove('text-gray-300');
                    s.classList.add('text-yellow-400');
                } else {
                    s.classList.remove('text-yellow-400');
                    s.classList.add('text-gray-300');
                }
            });
        });
    }

    function validateForm() {
        const rating = document.getElementById('rating-input').value;
        if (rating == 0) {
            alert('Please select an overall rating before submitting!');
            return false;
        }
        return true;
    }

    setupStarRating('rating-stars',   'rating-input');
    setupStarRating('quality-stars',  'quality-input');
    setupStarRating('delivery-stars', 'delivery-input');
</script>

</body>
</html>