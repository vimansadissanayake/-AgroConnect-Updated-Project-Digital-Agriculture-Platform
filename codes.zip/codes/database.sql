-- Updated database schema for AgroConnect with correct admin setup

-- Create the database
CREATE DATABASE IF NOT EXISTS vimansa;
USE vimansa;

-- Table for Users (for login and registration)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL, 
    email VARCHAR(100) UNIQUE,
    username VARCHAR(50) UNIQUE NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('Buyer', 'Farmer', 'Delivery', 'Food Tester', 'admin') NOT NULL,
    phone_number VARCHAR(20) NULL,
    address VARCHAR(255) NULL,
    profile_image_path VARCHAR(255) NULL DEFAULT 'uploads/default_profile.png',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    INDEX idx_username (username),
    INDEX idx_email (email)
);

-- Delete any existing admin user first
DELETE FROM users WHERE role = 'admin';

-- Insert default admin user with password: admin123
-- This is the CORRECT hash for 'admin123' using PHP password_hash() with PASSWORD_DEFAULT
INSERT INTO users (name, email, username, password, role, is_active) VALUES 
('Administrator', 'admin@gmail.com', 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', TRUE);

-- Note: The password hash above is for 'admin123'
-- You can also login with:
--   Username: admin  Password: admin123
--   Email: admin@gmail.com  Password: admin123

CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    unit VARCHAR(20) NOT NULL DEFAULT 'kg',
    stock_quantity DECIMAL(10, 2) NOT NULL DEFAULT 0, 
    image_path VARCHAR(255),
    image_url VARCHAR(255),
    category VARCHAR(50),
    location VARCHAR(100),
    farmer_id INT,
    is_quality_verified BOOLEAN DEFAULT FALSE,
    quality_verification_date TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (farmer_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Table for Cart Items
CREATE TABLE IF NOT EXISTS cart_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity DECIMAL(10, 2) NOT NULL,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE (user_id, product_id) 
);

-- Table for Orders
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    total_amount DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
    payment_status ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
    payment_method VARCHAR(50),
    delivery_address TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Table for Order Items
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity DECIMAL(10, 2) NOT NULL,
    price_at_order DECIMAL(10, 2) NOT NULL,
    farmer_id INT,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (farmer_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Table for Payments
CREATE TABLE IF NOT EXISTS payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    user_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    payment_method ENUM('credit_card', 'debit_card', 'bank_transfer', 'cash_on_delivery', 'mobile_payment') NOT NULL,
    payment_status ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
    transaction_id VARCHAR(255),
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Table for Product Reviews (legacy - keeping for compatibility)
CREATE TABLE IF NOT EXISTS product_reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    user_id INT NOT NULL,
    farmer_id INT NOT NULL,
    order_id INT NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    review_text TEXT,
    quality_rating INT CHECK (quality_rating >= 1 AND quality_rating <= 5),
    delivery_rating INT CHECK (delivery_rating >= 1 AND delivery_rating <= 5),
    is_verified_purchase BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (farmer_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);

-- Table for Quality Verification
CREATE TABLE IF NOT EXISTS quality_verifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    verified_by INT NOT NULL,
    verification_status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    quality_score INT CHECK (quality_score >= 1 AND quality_score <= 10),
    verification_notes TEXT,
    verification_image_path VARCHAR(255),
    verified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (verified_by) REFERENCES users(id) ON DELETE CASCADE
);

-- Table for Disease Reports
CREATE TABLE IF NOT EXISTS disease_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    crop_type VARCHAR(100) NOT NULL,
    symptoms TEXT NOT NULL,
    image_path VARCHAR(255),
    diagnosis TEXT,             
    treatment_suggestion TEXT,  
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    seen_notification BOOLEAN DEFAULT FALSE, 
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Reviews System Tables

-- Create reviews table
CREATE TABLE IF NOT EXISTS reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    user_id INT NOT NULL,
    farmer_id INT NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    review_text TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    verified_purchase BOOLEAN DEFAULT FALSE,
    helpful_count INT DEFAULT 0,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (farmer_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_product (product_id),
    INDEX idx_user (user_id),
    INDEX idx_farmer (farmer_id),
    INDEX idx_rating (rating),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create review_helpful table
CREATE TABLE IF NOT EXISTS review_helpful (
    id INT AUTO_INCREMENT PRIMARY KEY,
    review_id INT NOT NULL,
    user_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (review_id) REFERENCES reviews(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_review (review_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create review_images table
CREATE TABLE IF NOT EXISTS review_images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    review_id INT NOT NULL,
    image_path VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (review_id) REFERENCES reviews(id) ON DELETE CASCADE,
    INDEX idx_review (review_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create farmer_ratings table
CREATE TABLE IF NOT EXISTS farmer_ratings (
    farmer_id INT PRIMARY KEY,
    total_reviews INT DEFAULT 0,
    average_rating DECIMAL(3,2) DEFAULT 0.00,
    rating_5_count INT DEFAULT 0,
    rating_4_count INT DEFAULT 0,
    rating_3_count INT DEFAULT 0,
    rating_2_count INT DEFAULT 0,
    rating_1_count INT DEFAULT 0,
    total_sales INT DEFAULT 0,
    quality_score DECIMAL(3, 2) DEFAULT 0.00,
    delivery_score DECIMAL(3, 2) DEFAULT 0.00,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (farmer_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Triggers for Reviews

DELIMITER //

-- Trigger to mark review as verified purchase
CREATE TRIGGER IF NOT EXISTS mark_verified_purchase 
BEFORE INSERT ON reviews
FOR EACH ROW
BEGIN
    DECLARE purchase_exists INT;
    
    SELECT COUNT(*) INTO purchase_exists
    FROM orders o
    JOIN order_items oi ON o.id = oi.order_id
    WHERE o.user_id = NEW.user_id 
    AND oi.product_id = NEW.product_id
    AND o.status IN ('delivered', 'completed');
    
    IF purchase_exists > 0 THEN
        SET NEW.verified_purchase = TRUE;
    END IF;
END//

-- Trigger to update farmer ratings when review is added
CREATE TRIGGER IF NOT EXISTS update_farmer_rating_insert
AFTER INSERT ON reviews
FOR EACH ROW
BEGIN
    INSERT INTO farmer_ratings (farmer_id, total_reviews, average_rating, 
                                rating_5_count, rating_4_count, rating_3_count, 
                                rating_2_count, rating_1_count)
    VALUES (NEW.farmer_id, 1, NEW.rating,
            IF(NEW.rating=5,1,0), IF(NEW.rating=4,1,0), IF(NEW.rating=3,1,0),
            IF(NEW.rating=2,1,0), IF(NEW.rating=1,1,0))
    ON DUPLICATE KEY UPDATE
        total_reviews = total_reviews + 1,
        rating_5_count = rating_5_count + IF(NEW.rating=5,1,0),
        rating_4_count = rating_4_count + IF(NEW.rating=4,1,0),
        rating_3_count = rating_3_count + IF(NEW.rating=3,1,0),
        rating_2_count = rating_2_count + IF(NEW.rating=2,1,0),
        rating_1_count = rating_1_count + IF(NEW.rating=1,1,0),
        average_rating = (
            SELECT AVG(rating) FROM reviews WHERE farmer_id = NEW.farmer_id
        );
END//

-- Trigger to update farmer ratings when review is deleted
CREATE TRIGGER IF NOT EXISTS update_farmer_rating_delete
AFTER DELETE ON reviews
FOR EACH ROW
BEGIN
    DECLARE new_total INT;
    DECLARE new_avg DECIMAL(3,2);
    
    SELECT COUNT(*), COALESCE(AVG(rating), 0) 
    INTO new_total, new_avg
    FROM reviews 
    WHERE farmer_id = OLD.farmer_id;
    
    IF new_total = 0 THEN
        DELETE FROM farmer_ratings WHERE farmer_id = OLD.farmer_id;
    ELSE
        UPDATE farmer_ratings SET
            total_reviews = new_total,
            average_rating = new_avg,
            rating_5_count = rating_5_count - IF(OLD.rating=5,1,0),
            rating_4_count = rating_4_count - IF(OLD.rating=4,1,0),
            rating_3_count = rating_3_count - IF(OLD.rating=3,1,0),
            rating_2_count = rating_2_count - IF(OLD.rating=2,1,0),
            rating_1_count = rating_1_count - IF(OLD.rating=1,1,0)
        WHERE farmer_id = OLD.farmer_id;
    END IF;
END//

DELIMITER ;

-- Verify admin user was created
SELECT 'Admin user created successfully!' as Status;
SELECT id, name, email, username, role, is_active FROM users WHERE role = 'admin';

ALTER TABLE reviews 
ADD IF NOT EXISTS quality_rating INT DEFAULT 0,
ADD IF NOT EXISTS delivery_rating INT DEFAULT 0;


-- ============================================================================
-- AgroConnect Database Fixes and Verification
-- Run this file to ensure your database is properly configured
-- ============================================================================

USE vimansa;

-- ============================================================================
-- 1. VERIFY AND FIX ADMIN USER
-- ============================================================================

-- Delete any existing admin users first (to avoid duplicates)
DELETE FROM users WHERE role = 'admin';

-- Create the default admin user
-- Username: admin / admin@agroconnect.com
-- Password: admin123
INSERT INTO users (name, email, password, role, is_active, created_at) VALUES 
('Administrator', 
 'admin@agroconnect.com', 
 '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 
 'admin', 
 TRUE,
 NOW());

-- Verify admin was created
SELECT 'Admin user created/verified' as Status;
SELECT id, name, email, role, is_active FROM users WHERE role = 'admin';

-- ============================================================================
-- 2. VERIFY REVIEWS TABLE STRUCTURE
-- ============================================================================

-- Check current structure
DESC reviews;

-- Ensure all required columns exist
-- If any columns are missing, add them:

-- Add quality_rating if missing
ALTER TABLE reviews 
ADD COLUMN IF NOT EXISTS quality_rating INT DEFAULT 0 
COMMENT 'Rating for product quality (1-5)';

-- Add delivery_rating if missing
ALTER TABLE reviews 
ADD COLUMN IF NOT EXISTS delivery_rating INT DEFAULT 0 
COMMENT 'Rating for delivery experience (1-5)';

-- Add verified_purchase if missing
ALTER TABLE reviews 
ADD COLUMN IF NOT EXISTS verified_purchase BOOLEAN DEFAULT FALSE
COMMENT 'Whether this review is from a verified purchase';

-- Add helpful_count if missing
ALTER TABLE reviews 
ADD COLUMN IF NOT EXISTS helpful_count INT DEFAULT 0
COMMENT 'Number of users who found this review helpful';

-- Add updated_at if missing
ALTER TABLE reviews 
ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
COMMENT 'Last update timestamp';

-- ============================================================================
-- 3. VERIFY FOREIGN KEY RELATIONSHIPS
-- ============================================================================

-- Check if farmer_id constraint exists in reviews table
SELECT 
    CONSTRAINT_NAME, 
    TABLE_NAME, 
    COLUMN_NAME, 
    REFERENCED_TABLE_NAME, 
    REFERENCED_COLUMN_NAME
FROM 
    INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE 
    TABLE_SCHEMA = 'vimansa'
    AND TABLE_NAME = 'reviews'
    AND REFERENCED_TABLE_NAME IS NOT NULL;

-- If farmer_id foreign key is missing, add it:
-- (This will fail if the constraint already exists - that's OK, it means it's already there)
ALTER TABLE reviews 
ADD CONSTRAINT fk_reviews_farmer 
FOREIGN KEY (farmer_id) REFERENCES users(id) ON DELETE CASCADE;

-- ============================================================================
-- 4. ADD PERFORMANCE INDEXES
-- ============================================================================

-- Add indexes for faster queries (if they don't exist)

-- Reviews table indexes
CREATE INDEX IF NOT EXISTS idx_reviews_product ON reviews(product_id);
CREATE INDEX IF NOT EXISTS idx_reviews_user ON reviews(user_id);
CREATE INDEX IF NOT EXISTS idx_reviews_farmer ON reviews(farmer_id);
CREATE INDEX IF NOT EXISTS idx_reviews_rating ON reviews(rating);
CREATE INDEX IF NOT EXISTS idx_reviews_created ON reviews(created_at);

-- Orders table indexes
CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_payment_status ON orders(payment_status);
CREATE INDEX IF NOT EXISTS idx_orders_date ON orders(order_date);

-- Order items indexes
CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_order_items_product ON order_items(product_id);
CREATE INDEX IF NOT EXISTS idx_order_items_farmer ON order_items(farmer_id);

-- Products table indexes
CREATE INDEX IF NOT EXISTS idx_products_farmer ON products(farmer_id);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
CREATE INDEX IF NOT EXISTS idx_products_verified ON products(is_quality_verified);

-- Users table indexes
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_active ON users(is_active);

-- ============================================================================
-- 5. FIX DATA INTEGRITY ISSUES
-- ============================================================================

-- Remove any orphaned reviews (reviews for non-existent products)
DELETE r FROM reviews r
LEFT JOIN products p ON r.product_id = p.id
WHERE p.id IS NULL;

-- Remove any orphaned reviews (reviews by non-existent users)
DELETE r FROM reviews r
LEFT JOIN users u ON r.user_id = u.id
WHERE u.id IS NULL;

-- Remove any orphaned order items
DELETE oi FROM order_items oi
LEFT JOIN orders o ON oi.order_id = o.id
WHERE o.id IS NULL;

-- ============================================================================
-- 6. UPDATE FARMER RATINGS (Recalculate)
-- ============================================================================

-- Clear existing farmer ratings
TRUNCATE TABLE farmer_ratings;

-- Recalculate all farmer ratings from reviews
INSERT INTO farmer_ratings (
    farmer_id,
    total_reviews,
    average_rating,
    rating_5_count,
    rating_4_count,
    rating_3_count,
    rating_2_count,
    rating_1_count,
    quality_score,
    delivery_score
)
SELECT 
    r.farmer_id,
    COUNT(*) as total_reviews,
    AVG(r.rating) as average_rating,
    SUM(CASE WHEN r.rating = 5 THEN 1 ELSE 0 END) as rating_5_count,
    SUM(CASE WHEN r.rating = 4 THEN 1 ELSE 0 END) as rating_4_count,
    SUM(CASE WHEN r.rating = 3 THEN 1 ELSE 0 END) as rating_3_count,
    SUM(CASE WHEN r.rating = 2 THEN 1 ELSE 0 END) as rating_2_count,
    SUM(CASE WHEN r.rating = 1 THEN 1 ELSE 0 END) as rating_1_count,
    AVG(r.quality_rating) as quality_score,
    AVG(r.delivery_rating) as delivery_score
FROM reviews r
GROUP BY r.farmer_id
ON DUPLICATE KEY UPDATE
    total_reviews = VALUES(total_reviews),
    average_rating = VALUES(average_rating),
    rating_5_count = VALUES(rating_5_count),
    rating_4_count = VALUES(rating_4_count),
    rating_3_count = VALUES(rating_3_count),
    rating_2_count = VALUES(rating_2_count),
    rating_1_count = VALUES(rating_1_count),
    quality_score = VALUES(quality_score),
    delivery_score = VALUES(delivery_score);

-- ============================================================================
-- 7. VERIFICATION QUERIES
-- ============================================================================

-- Show database statistics
SELECT 'Database Statistics' as Info;

SELECT 
    'Total Users' as Metric, 
    COUNT(*) as Count 
FROM users WHERE role != 'admin'
UNION ALL
SELECT 
    'Total Farmers', 
    COUNT(*) 
FROM users WHERE role = 'Farmer'
UNION ALL
SELECT 
    'Total Buyers', 
    COUNT(*) 
FROM users WHERE role = 'Buyer'
UNION ALL
SELECT 
    'Total Products', 
    COUNT(*) 
FROM products
UNION ALL
SELECT 
    'Total Orders', 
    COUNT(*) 
FROM orders
UNION ALL
SELECT 
    'Total Reviews', 
    COUNT(*) 
FROM reviews
UNION ALL
SELECT 
    'Quality Verified Products', 
    COUNT(*) 
FROM products WHERE is_quality_verified = TRUE;

-- Show reviews table structure
SELECT 'Reviews Table Structure' as Info;
DESC reviews;

-- Show sample reviews (if any exist)
SELECT 'Sample Reviews' as Info;
SELECT 
    r.id,
    u.name as reviewer,
    p.name as product,
    r.rating,
    r.quality_rating,
    r.delivery_rating,
    r.verified_purchase,
    r.created_at
FROM reviews r
JOIN users u ON r.user_id = u.id
JOIN products p ON r.product_id = p.id
LIMIT 5;

-- ============================================================================
-- 8. OPTIONAL: CREATE SAMPLE DATA FOR TESTING
-- ============================================================================

-- Uncomment the following section if you want sample data for testing

/*
-- Sample Farmer
INSERT INTO users (name, email, password, role, phone_number, is_active) VALUES
('John Farmer', 'farmer@test.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Farmer', '0771234567', TRUE);

SET @farmer_id = LAST_INSERT_ID();

-- Sample Buyer
INSERT INTO users (name, email, password, role, phone_number, is_active) VALUES
('Jane Buyer', 'buyer@test.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Buyer', '0777654321', TRUE);

SET @buyer_id = LAST_INSERT_ID();

-- Sample Products
INSERT INTO products (name, description, price, unit, stock_quantity, category, location, farmer_id, is_quality_verified) VALUES
('Organic Tomatoes', 'Fresh organic tomatoes', 250.00, 'kg', 100, 'Vegetables', 'Colombo', @farmer_id, TRUE),
('Fresh Carrots', 'Crunchy fresh carrots', 180.00, 'kg', 50, 'Vegetables', 'Kandy', @farmer_id, FALSE),
('Red Rice', 'Locally grown red rice', 200.00, 'kg', 200, 'Grains', 'Anuradhapura', @farmer_id, TRUE);

-- Sample Order (Delivered status for testing reviews)
INSERT INTO orders (user_id, total_amount, status, payment_status, delivery_address) VALUES
(@buyer_id, 680.00, 'delivered', 'completed', '123 Test Street, Colombo');

SET @order_id = LAST_INSERT_ID();

-- Sample Order Items
INSERT INTO order_items (order_id, product_id, quantity, price_at_order, farmer_id) VALUES
(@order_id, 1, 2, 250.00, @farmer_id),
(@order_id, 2, 1, 180.00, @farmer_id);

SELECT 'Sample data created successfully!' as Status;
SELECT 'Test login: farmer@test.com / admin123' as FarmerLogin;
SELECT 'Test login: buyer@test.com / admin123' as BuyerLogin;
*/

-- ============================================================================
-- END OF FIXES
-- ============================================================================

SELECT '✅ All database fixes applied successfully!' as Status;
SELECT 'You can now test:' as NextSteps;
SELECT '1. Admin login: admin / admin123' as Step1;
SELECT '2. Review submission on delivered orders' as Step2;
SELECT '3. All user roles login correctly' as Step3;

use vimansa;

DELETE FROM users WHERE role = 'admin';

INSERT INTO users (name, email, password, role, is_active) VALUES
('Administrator', 'admin@agroconnect.com', '$2y$10$K3HFq0KOtRjnXZQ7XzUnIu0sDO2NYWflo7q0NXqIWmnGlzVyuDl/i', 'admin', TRUE);

-- ============================================================================
-- AgroConnect Database Fixes
-- Run this script to fix all database errors
-- ============================================================================

USE vimansa;

-- ============================================================================
-- FIX 1: Add missing columns to reviews table
-- ============================================================================

-- Check if columns exist before adding
SET @dbname = 'vimansa';
SET @tablename = 'reviews';

-- Add quality_rating if it doesn't exist
SET @column_exists = (
    SELECT COUNT(*)
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = @dbname
    AND TABLE_NAME = @tablename
    AND COLUMN_NAME = 'quality_rating'
);

SET @sql = IF(@column_exists = 0,
    'ALTER TABLE reviews ADD COLUMN quality_rating INT CHECK (quality_rating >= 0 AND quality_rating <= 5) AFTER rating',
    'SELECT "quality_rating column already exists" AS Status'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add delivery_rating if it doesn't exist
SET @column_exists = (
    SELECT COUNT(*)
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = @dbname
    AND TABLE_NAME = @tablename
    AND COLUMN_NAME = 'delivery_rating'
);

SET @sql = IF(@column_exists = 0,
    'ALTER TABLE reviews ADD COLUMN delivery_rating INT CHECK (delivery_rating >= 0 AND delivery_rating <= 5) AFTER quality_rating',
    'SELECT "delivery_rating column already exists" AS Status'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ============================================================================
-- FIX 2: Update farmer_ratings table structure
-- ============================================================================

SET @tablename = 'farmer_ratings';

-- Add quality_score if it doesn't exist
SET @column_exists = (
    SELECT COUNT(*)
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = @dbname
    AND TABLE_NAME = @tablename
    AND COLUMN_NAME = 'quality_score'
);

SET @sql = IF(@column_exists = 0,
    'ALTER TABLE farmer_ratings ADD COLUMN quality_score DECIMAL(3,2) DEFAULT 0.00 AFTER average_rating',
    'SELECT "quality_score column already exists" AS Status'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add delivery_score if it doesn't exist
SET @column_exists = (
    SELECT COUNT(*)
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = @dbname
    AND TABLE_NAME = @tablename
    AND COLUMN_NAME = 'delivery_score'
);

SET @sql = IF(@column_exists = 0,
    'ALTER TABLE farmer_ratings ADD COLUMN delivery_score DECIMAL(3,2) DEFAULT 0.00 AFTER quality_score',
    'SELECT "delivery_score column already exists" AS Status'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ============================================================================
-- FIX 3: Verify order_items table structure
-- ============================================================================

-- Check if order_items has price_at_order column (correct) or price column (wrong)
SET @tablename = 'order_items';

SET @price_at_order_exists = (
    SELECT COUNT(*)
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = @dbname
    AND TABLE_NAME = @tablename
    AND COLUMN_NAME = 'price_at_order'
);

SET @price_exists = (
    SELECT COUNT(*)
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = @dbname
    AND TABLE_NAME = @tablename
    AND COLUMN_NAME = 'price'
);

-- If 'price' column exists but 'price_at_order' doesn't, rename it
SET @sql = IF(@price_exists = 1 AND @price_at_order_exists = 0,
    'ALTER TABLE order_items CHANGE COLUMN price price_at_order DECIMAL(10,2) NOT NULL',
    'SELECT "order_items table structure is correct" AS Status'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- If neither exists, add price_at_order
SET @price_at_order_exists = (
    SELECT COUNT(*)
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = @dbname
    AND TABLE_NAME = @tablename
    AND COLUMN_NAME = 'price_at_order'
);

SET @sql = IF(@price_at_order_exists = 0,
    'ALTER TABLE order_items ADD COLUMN price_at_order DECIMAL(10,2) NOT NULL AFTER quantity',
    'SELECT "price_at_order column exists" AS Status'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ============================================================================
-- FIX 4: Update farmer ratings (recalculate from reviews)
-- ============================================================================

-- Recalculate all farmer ratings from existing reviews
INSERT INTO farmer_ratings (
    farmer_id,
    total_reviews,
    average_rating,
    quality_score,
    delivery_score,
    rating_5_count,
    rating_4_count,
    rating_3_count,
    rating_2_count,
    rating_1_count
)
SELECT 
    r.farmer_id,
    COUNT(*) as total_reviews,
    AVG(r.rating) as average_rating,
    AVG(NULLIF(r.quality_rating, 0)) as quality_score,
    AVG(NULLIF(r.delivery_rating, 0)) as delivery_score,
    SUM(CASE WHEN r.rating = 5 THEN 1 ELSE 0 END) as rating_5_count,
    SUM(CASE WHEN r.rating = 4 THEN 1 ELSE 0 END) as rating_4_count,
    SUM(CASE WHEN r.rating = 3 THEN 1 ELSE 0 END) as rating_3_count,
    SUM(CASE WHEN r.rating = 2 THEN 1 ELSE 0 END) as rating_2_count,
    SUM(CASE WHEN r.rating = 1 THEN 1 ELSE 0 END) as rating_1_count
FROM reviews r
GROUP BY r.farmer_id
ON DUPLICATE KEY UPDATE
    total_reviews = VALUES(total_reviews),
    average_rating = VALUES(average_rating),
    quality_score = VALUES(quality_score),
    delivery_score = VALUES(delivery_score),
    rating_5_count = VALUES(rating_5_count),
    rating_4_count = VALUES(rating_4_count),
    rating_3_count = VALUES(rating_3_count),
    rating_2_count = VALUES(rating_2_count),
    rating_1_count = VALUES(rating_1_count);

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================

SELECT '✅ All database fixes applied successfully!' as Status;

-- Show reviews table structure
SELECT 'Reviews Table Structure:' as Info;
DESCRIBE reviews;

-- Show order_items table structure
SELECT 'Order Items Table Structure:' as Info;
DESCRIBE order_items;

-- Show farmer_ratings table structure
SELECT 'Farmer Ratings Table Structure:' as Info;
DESCRIBE farmer_ratings;

-- Count statistics
SELECT 
    'Database Statistics' as Info,
    (SELECT COUNT(*) FROM users WHERE role != 'admin') as TotalUsers,
    (SELECT COUNT(*) FROM products) as TotalProducts,
    (SELECT COUNT(*) FROM orders) as TotalOrders,
    (SELECT COUNT(*) FROM reviews) as TotalReviews;

SELECT 'Database is ready for use!' as FinalStatus;
SELECT 'Test with: admin / admin123' as AdminLogin;

ALTER TABLE orders ADD COLUMN delivery_partner_id INT NULL AFTER total_amount;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS delivery_fee DECIMAL(10,2) DEFAULT 0 AFTER total_amount;

-- Add foreign key constraint (optional but recommended)
ALTER TABLE orders ADD CONSTRAINT fk_delivery_partner 
FOREIGN KEY (delivery_partner_id) REFERENCES users(id) ON DELETE SET NULL;

-- Add phone and address columns to users table if they don't exist
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS phone VARCHAR(20) NULL,
ADD COLUMN IF NOT EXISTS address TEXT NULL;
