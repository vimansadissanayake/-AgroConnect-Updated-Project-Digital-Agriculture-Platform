<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DIY Crop Health - AgroConnect</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
       
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f1ffeb;
        }
        /* Basic styling for consistent card appearance */
        .diy-card {
            background-color: #ffffff;
            padding: 1.5rem;
            border-radius: 0.75rem; 
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06); /* shadow-lg */
            border: 1px solid #e5e7eb;
            transition: all 0.3s ease-in-out;
        }
        .diy-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05); /* hover:shadow-xl */
        }
        /* Custom styles for mobile menu toggle  */
        #mobile-menu {
            display: none;
        }
        #mobile-menu.active {
            display: block;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="bg-white shadow-md sticky top-0 z-50">
        <div class="container mx-auto px-6 py-3">
            <div class="flex items-center justify-between">
                <div class="flex items-center">
                    <img src="logo.png" alt="AgroConnect Logo" class="w-10 h-10 mr-2 rounded-full">
                    <span class="text-xl font-bold text-green-800">AgroConnect</span>
                </div>
                <div class="hidden md:flex items-center space-x-8">
                    <a href="home.php" class="text-gray-600 hover:text-green-600 font-medium">Home</a>
                    <a href="features.php" class="text-gray-600 hover:text-green-600 font-medium">Features</a>
                    <a href="marketplace.php" class="text-gray-600 hover:text-green-600 font-medium">Marketplace</a>
                    <a href="crophealth.php" class="text-green-700 font-bold">Crop Health</a>
                    <a href="aboutus.php" class="text-gray-600 hover:text-green-600 font-medium">About</a> 
                    <a href="profile.php" class="text-gray-600 hover:text-green-600 font-medium">Profile</a>
                    <a href="map.php" class="text-gray-600 hover:text-green-600 font-medium">Map</a>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="login.php" class="px-4 py-2 text-green-700 border border-green-700 rounded-md hover:bg-green-50 transition-all">
                        Login
                    </a>
                    <a href="register.php" class="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-all">
                        Register
                    </a>
                    <button id="mobile-menu-button" class="md:hidden text-gray-600 focus:outline-none">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                </div>
            </div>
            <div id="mobile-menu" class="md:hidden mt-4 bg-white rounded-md shadow-lg py-2">
                <a href="home.php" class="block px-4 py-2 text-gray-800 hover:bg-gray-100">Home</a>
                <a href="features.php" class="block px-4 py-2 text-gray-800 hover:bg-gray-100">Features</a>
                <a href="marketplace.php" class="block px-4 py-2 text-gray-800 hover:bg-gray-100">Marketplace</a>
                <a href="crophealth.php" class="block px-4 py-2 text-green-700 font-bold hover:bg-gray-100">Crop Health</a>
                <a href="aboutus.php" class="block px-4 py-2 text-gray-800 hover:bg-gray-100">About</a>
                <a href="profile.php" class="block px-4 py-2 text-gray-800 hover:bg-gray-100">Profile</a>
                <a href="map.php" class="block px-4 py-2 text-gray-800 hover:bg-gray-100">Map</a>
            </div>
        </div>
    </nav>

    <!-- Header Section -->
    <header class="py-10 px-4 sm:px-6 lg:px-8 text-center bg-green-700 text-white shadow-lg rounded-b-3xl">
        <h1 class="text-2xl sm:text-3xl lg:text-4xl font-bold mb-4 leading-tight">
            DIY Crop Health Guide
        </h1>
        <p class="text-lg sm:text-xl max-w-3xl mx-auto opacity-90">
            Empower your garden with simple, natural, and effective techniques.
        </p>
    </header>

    <!-- Main Content  -->
    <main class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <!-- Section: Natural Pest Control -->
        <section class="mb-12">
            <h2 class="text-3xl sm:text-4xl font-bold text-center mb-8 text-green-800">
                <i class="fas fa-bug text-green-600 mr-3"></i> Natural Pest Control
            </h2>
            <div class="diy-card">
                <p class="text-gray-700 mb-4 text-lg">
                    Keep unwanted visitors away without harsh chemicals.
                </p>
                <ul class="list-disc list-inside text-gray-600 space-y-2">
                    <li><strong>Neem Oil Spray:</strong> Mix 1 tsp neem oil, 1/2 tsp mild liquid soap, and 1 liter water. Spray thoroughly on affected plants, especially undersides of leaves, every 5-7 days.</li>
                    <li><strong>Soapy Water Spray:</strong> For soft-bodied pests like aphids, mix 1-2 tbsp dish soap with 1 liter water. Spray directly on pests.</li>
                    <li><strong>Companion Planting:</strong> Plant marigolds to deter nematodes, basil to repel flies, or nasturtiums to attract aphids away from other crops.</li>
                    <li><strong>Hand-Picking:</strong> For larger pests like slugs or caterpillars, manually remove them from plants. Do this in the early morning or evening.</li>
                </ul>
            </div>
        </section>

        <!-- Section: Healthy Soil & Fertilization -->
        <section class="mb-12">
            <h2 class="text-3xl sm:text-4xl font-bold text-center mb-8 text-green-800">
                <i class="fas fa-seedling text-green-600 mr-3"></i> Healthy Soil & Fertilization
            </h2>
            <div class="diy-card">
                <p class="text-gray-700 mb-4 text-lg">
                    The foundation of healthy plants is healthy soil.
                </p>
                <ul class="list-disc list-inside text-gray-600 space-y-2">
                    <li><strong>Compost Power:</strong> Regularly amend your soil with homemade compost to improve structure, drainage, and nutrient content.</li>
                    <li><strong>Coffee Grounds:</strong> Add used coffee grounds to acid-loving plants (like blueberries, tomatoes) for a nitrogen boost and to deter slugs.</li>
                    <li><strong>Eggshells:</strong> Crush dried eggshells and mix into soil around plants like tomatoes and peppers to provide calcium and prevent blossom end rot.</li>
                    <li><strong>Banana Peels:</strong> Bury banana peels near fruiting plants (like roses, tomatoes) for a potassium boost, essential for flower and fruit development.</li>
                </ul>
            </div>
        </section>

        <!-- Section: Optimal Watering & Moisture -->
        <section class="mb-12">
            <h2 class="text-3xl sm:text-4xl font-bold text-center mb-8 text-green-800">
                <i class="fas fa-tint text-green-600 mr-3"></i> Optimal Watering & Moisture
            </h2>
            <div class="diy-card">
                <p class="text-gray-700 mb-4 text-lg">
                    Watering correctly is key to preventing many common issues.
                </p>
                <ul class="list-disc list-inside text-gray-600 space-y-2">
                    <li><strong>Deep Watering:</strong> Water deeply and less frequently to encourage strong, deep root growth. Avoid shallow, frequent watering.</li>
                    <li><strong>Morning Watering:</strong> Water in the early morning to allow leaves to dry before nightfall, reducing fungal disease risk.</li>
                    <li><strong>Mulching:</strong> Apply a layer of organic mulch (straw, wood chips) around plants to retain soil moisture, suppress weeds, and regulate soil temperature.</li>
                    <li><strong>Finger Test:</strong> Before watering, stick your finger about 1-2 inches into the soil. If it feels dry, it's time to water.</li>
                </ul>
            </div>
        </section>

        <!-- Section: Identifying & Addressing Deficiencies -->
        <section class="mb-12">
            <h2 class="text-3xl sm:text-4xl font-bold text-center mb-8 text-green-800">
                <i class="fas fa-leaf text-green-600 mr-3"></i> Identifying & Addressing Deficiencies
            </h2>
            <div class="diy-card">
                <p class="text-gray-700 mb-4 text-lg">
                    Learn to read your plants' signals for nutrient needs.
                </p>
                <ul class="list-disc list-inside text-gray-600 space-y-2">
                    <li><strong>Yellowing Lower Leaves:</strong> Often indicates Nitrogen deficiency. Use compost tea or blood meal as a quick fix.</li>
                    <li><strong>Purple Stems/Leaves:</strong> Can signal Phosphorus deficiency, especially in cool weather. Bone meal or rock phosphate can help.</li>
                    <li><strong>Yellowing Between Veins (New Leaves):</strong> Points to Iron or Magnesium deficiency. Epsom salts (for Magnesium) or chelated iron can be applied.</li>
                    <li><strong>Stunted Growth:</strong> A general sign of nutrient imbalance or poor soil. Improve soil health with compost and ensure proper watering.</li>
                </ul>
            </div>
        </section>
    </main>

    <!-- Footer (Copied from aboutus.php for consistency) -->
    <footer class="bg-green-900 text-white py-8">
        <div class="container mx-auto px-6 text-center">
            <p>© 2025 AgroConnect. All rights reserved <i class="fas fa-heart text-yellow-500 "></i></p>
        </div>
    </footer>

    <script>
        // JavaScript for mobile menu toggle (from aboutus.php)
        document.getElementById('mobile-menu-button').addEventListener('click', function() {
            const mobileMenu = document.getElementById('mobile-menu');
            mobileMenu.classList.toggle('active');
        });
    </script>
</body>
</html>
