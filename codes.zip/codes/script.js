// Contact Form Handler
const contactForm = document.getElementById('contactForm');
if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const subject = document.getElementById('subject').value;
        const message = document.getElementById('message').value;
        
        alert(`Thank you ${name}! Your message has been received. We'll get back to you at ${email} soon.`);
        
        contactForm.reset();
    });
}

// Product Contact Buttons
const contactButtons = document.querySelectorAll('.product-card .btn');
contactButtons.forEach(button => {
    button.addEventListener('click', function() {
        const productName = this.closest('.product-card').querySelector('h3').textContent;
        alert(`To inquire about ${productName}, please visit our Contact page or call us at +1 (555) 123-4567`);
    });
});
