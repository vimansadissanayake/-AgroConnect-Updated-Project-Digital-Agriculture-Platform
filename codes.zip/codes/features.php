<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Features</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
       
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f1ffeb;
        }
        
        
        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        
        
        .transition-all {
            transition: all 0.3s ease;
        }
        
        .role-card:hover {
            background-color: #f1f8e9;
        }
    </style>
</head>
<body>
      <nav class="bg-white shadow-md sticky top-0 z-50">
        <div class="container mx-auto px-6 py-3">
            <div class="flex items-center justify-between">
                <div class="flex items-center">
                    <img src="logo.png" alt="AgroConnect Logo" class="w-15 h-10 mr-2">
                    <span class="text-xl font-bold text-green-800">AgroConnect</span>
                </div>
                <div class="hidden md:flex items-center space-x-8">
                    <a href="home.php" class="text-gray-600 hover:text-green-600 font-medium">Home</a>
                    <a href="features.php" class="text-green-700 hover:text-green-600 font-medium">Features</a>
                    <a href="marketplace.php" class="text-gray-600 hover:text-green-600 font-medium">Marketplace</a>
                    <a href="crophealth.php" class="text-gray-600 hover:text-green-600 font-medium">Crop Health</a>
                    <a href="aboutus.php" class="text-gray-600 hover:text-green-600 font-medium">About</a>
                    <a href="profile.php" class="text-gray-600 hover:text-green-600 font-medium">Profile</a>
                    <a href="map.php" class="text-gray-600 hover:text-green-600 font-medium">Map</a>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="login.php" class="px-4 py-2 text-green-700 border border-green-700 rounded-md hover:bg-green-50 transition-all">
                        Login
                    </a>
                    <a href="register.php" class="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-all">
                        Register
                    </a>
                    <button class="md:hidden text-gray-600">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                </div>
            </div>
        </div>
    </nav>

    <!-- Features Section -->
    <section id="features" class="py-16 bg-gray-50">
        <div class="container mx-auto px-6">
            <div class="text-center mb-16">
                <h2 class="text-3xl font-bold text-gray-800 mb-4">Our Comprehensive Features</h2>
                <p class="text-gray-600 max-w-2xl mx-auto">AgroConnect provides all the tools farmers, buyers, and agricultural experts need in one integrated platform.</p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="bg-white p-8 rounded-lg shadow-md feature-card transition-all cursor-pointer">
                    <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
                        <i class="fas fa-store text-green-600 text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-800 mb-3">Digital Marketplace</h3>
                    <p class="text-gray-600">Farmers can list their produce with detailed information and images. Buyers can browse, filter, and purchase directly from farmers.</p>
                </div>
                
                <div class="bg-white p-8 rounded-lg shadow-md feature-card transition-all cursor-pointer">
                    <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
                        <i class="fas fa-leaf text-green-600 text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-800 mb-3">Crop Health Diagnosis</h3>
                    <p class="text-gray-600">Farmers can report plant diseases with photos and get expert diagnosis and treatment recommendations within hours.</p>
                </div>
                
                <div class="bg-white p-8 rounded-lg shadow-md feature-card transition-all cursor-pointer">
                    <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
                        <i class="fas fa-truck text-green-600 text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-800 mb-3">Integrated Logistics</h3>
                    <p class="text-gray-600">Our platform connects with delivery services to provide seamless order fulfillment and real-time tracking for both farmers and buyers.</p>
                </div>
            </div>
        </div>
    </section>

   

    <!-- Footer -->
    <footer class="bg-green-900 text-white py-8">
        <div class="container mx-auto px-6 text-center">
            <p>© 2025 AgroConnect. All rights reserved <i class="fas fa-heart text-yellow-500 "></i></p>
        </div>
    </footer>
</body>
</html>
