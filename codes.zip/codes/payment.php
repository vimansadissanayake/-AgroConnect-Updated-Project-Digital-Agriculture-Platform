<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'Buyer') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$order_id = $_GET['order_id'] ?? null;
$total_amount = $_GET['amount'] ?? 0;

if (!$order_id || $total_amount <= 0) {
    header("Location: buyer.php");
    exit();
}

// Fetch order details
$order_query = "SELECT * FROM orders WHERE id = ? AND user_id = ?";
$stmt = $conn->prepare($order_query);
$stmt->bind_param("ii", $order_id, $user_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) {
    header("Location: buyer.php");
    exit();
}

// Fetch order items
$items_query = "SELECT oi.*, p.name as product_name FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?";
$stmt = $conn->prepare($items_query);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order_items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$error_message = '';

// Handle payment submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $card_number = preg_replace('/\s+/', '', $_POST['card_number'] ?? ''); // Remove spaces
    $expiry_month = intval($_POST['expiry_month'] ?? 0);
    $expiry_year = intval($_POST['expiry_year'] ?? 0);
    $cvv = $_POST['cvv'] ?? '';
    $card_holder = trim($_POST['card_holder'] ?? '');
    $delivery_address = trim($_POST['delivery_address'] ?? '');

    // Basic server-side validation
    if (empty($card_number) || empty($expiry_month) || empty($expiry_year) || empty($cvv) || empty($card_holder) || empty($delivery_address)) {
        $error_message = "Please fill all required fields!";
    } elseif (strlen($card_number) < 13 || strlen($card_number) > 19 || !ctype_digit($card_number)) {
        $error_message = "Invalid card number!";
    } elseif ($expiry_month < 1 || $expiry_month > 12 || $expiry_year < date('Y') || ($expiry_year == date('Y') && $expiry_month < date('m'))) {
        $error_message = "Invalid or expired card!";
    } elseif (strlen($cvv) < 3 || strlen($cvv) > 4 || !ctype_digit($cvv)) {
        $error_message = "Invalid CVV!";
    } else {
        $conn->begin_transaction();
        try {
            // Mock payment processing (in real: call Stripe API here)
            // For demo, assume success if validations pass
            $payment_method = 'credit_card';
            $transaction_id = 'TXN' . time() . rand(1000, 9999);

            // Update order
            $update_order = "UPDATE orders SET payment_method = ?, delivery_address = ?, payment_status = 'completed', status = 'processing' WHERE id = ?";
            $stmt = $conn->prepare($update_order);
            $stmt->bind_param("ssi", $payment_method, $delivery_address, $order_id);
            $stmt->execute();
            $stmt->close();

            // Insert payment record
            $insert_payment = "INSERT INTO payments (order_id, user_id, amount, payment_method, payment_status, transaction_id) VALUES (?, ?, ?, ?, 'completed', ?)";
            $stmt = $conn->prepare($insert_payment);
            $stmt->bind_param("iidss", $order_id, $user_id, $total_amount, $payment_method, $transaction_id);
            $stmt->execute();
            $stmt->close();

            // Clear cart items
            $clear_cart = "DELETE FROM cart_items WHERE user_id = ?";
            $stmt = $conn->prepare($clear_cart);
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $stmt->close();

            $conn->commit();

            // Redirect to success page
            header("Location: payment_success.php?order_id={$order_id}&transaction_id={$transaction_id}");
            exit();

        } catch (Exception $e) {
            $conn->rollback();
            $error_message = "Payment processing failed: " . $e->getMessage();
        }
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment - AgroConnect</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        body { font-family: 'Poppins', sans-serif; background-color: #f1ffeb; }
        .card-input { transition: all 0.3s; }
        .card-input:focus { border-color: #22c55e; box-shadow: 0 0 0 3px rgba(34,197,94,0.1); }
        .error { color: #ef4444; }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 to-green-100 p-4">
    <div class="w-full max-w-4xl bg-white rounded-2xl shadow-xl overflow-hidden">
        <div class="grid grid-cols-1 lg:grid-cols-2">
            <!-- Payment Form -->
            <div class="p-8">
                <h2 class="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                    <i class="fas fa-credit-card mr-2 text-green-600"></i> Secure Payment
                </h2>
                
                <?php if ($error_message): ?>
                    <div class="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg mb-6">
                        <?php echo $error_message; ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" class="space-y-6">
                    <div>
                        <label class="block text-gray-700 mb-2 font-medium">Card Holder Name</label>
                        <input type="text" name="card_holder" class="w-full px-4 py-3 border border-gray-300 rounded-lg card-input focus:outline-none" 
                               placeholder="John Doe" required value="<?php echo htmlspecialchars($_POST['card_holder'] ?? ''); ?>">
                    </div>
                    
                    <div>
                        <label class="block text-gray-700 mb-2 font-medium">Card Number</label>
                        <div class="relative">
                            <input type="text" name="card_number" id="card-number" class="w-full px-4 py-3 border border-gray-300 rounded-lg card-input focus:outline-none" 
                                   placeholder="1234 5678 9012 3456" maxlength="19" required>
                            <span id="card-type" class="absolute right-4 top-3 text-gray-500"></span>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-gray-700 mb-2 font-medium">Expiry Date</label>
                            <div class="grid grid-cols-2 gap-2">
                                <select name="expiry_month" class="px-4 py-3 border border-gray-300 rounded-lg card-input focus:outline-none" required>
                                    <option value="">MM</option>
                                    <?php for ($m = 1; $m <= 12; $m++): ?>
                                        <option value="<?php echo $m; ?>"><?php echo str_pad($m, 2, '0', STR_PAD_LEFT); ?></option>
                                    <?php endfor; ?>
                                </select>
                                <select name="expiry_year" class="px-4 py-3 border border-gray-300 rounded-lg card-input focus:outline-none" required>
                                    <option value="">YY</option>
                                    <?php $year = date('Y'); for ($y = $year; $y <= $year + 10; $y++): ?>
                                        <option value="<?php echo $y; ?>"><?php echo substr($y, -2); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                        </div>
                        <div>
                            <label class="block text-gray-700 mb-2 font-medium">CVV</label>
                            <input type="text" name="cvv" class="w-full px-4 py-3 border border-gray-300 rounded-lg card-input focus:outline-none" 
                                   placeholder="123" maxlength="4" required>
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-gray-700 mb-2 font-medium">Delivery Address</label>
                        <textarea name="delivery_address" class="w-full px-4 py-3 border border-gray-300 rounded-lg card-input focus:outline-none" 
                                  rows="3" placeholder="Enter your delivery address" required><?php echo htmlspecialchars($_POST['delivery_address'] ?? ''); ?></textarea>
                    </div>
                    
                    <button type="submit" class="w-full py-3 bg-green-600 text-white font-bold rounded-lg hover:bg-green-700 transition">
                        <i class="fas fa-lock mr-2"></i> Pay Rs <?php echo number_format($total_amount, 2); ?>
                    </button>
                </form>
            </div>
            
            <!-- Order Summary -->
            <div class="bg-green-50 p-8">
                <h2 class="text-2xl font-bold text-gray-800 mb-6">Order Summary</h2>
                <div class="space-y-4 mb-6">
                    <?php foreach($order_items as $item): ?>
                    <div class="flex justify-between text-gray-700">
                        <span><?= htmlspecialchars($item['product_name']) ?> × <?= $item['quantity'] ?></span>
                        <span>Rs <?= number_format($item['price_at_order'] * $item['quantity'], 2) ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="border-t pt-4 space-y-2">
                    <div class="flex justify-between text-gray-700">
                        <span>Subtotal</span>
                        <span>Rs <?php echo number_format($total_amount, 2); ?></span>
                    </div>
                    <div class="flex justify-between text-gray-700">
                        <span>Delivery Fee</span>
                        <span>Rs 0.00</span>
                    </div>
                    <div class="border-t pt-3 flex justify-between text-lg font-bold text-green-800">
                        <span>Total</span>
                        <span>Rs <?php echo number_format($total_amount, 2); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Card number formatting and type detection
        const cardInput = document.getElementById('card-number');
        const cardType = document.getElementById('card-type');

        cardInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 19) value = value.slice(0, 19);
            
            // Format with spaces
            e.target.value = value.replace(/(\d{4})(?=\d)/g, '$1 ');
            
            // Detect card type
            if (value.startsWith('4')) {
                cardType.innerHTML = '<i class="fab fa-cc-visa text-blue-600"></i>';
            } else if (value.startsWith('5')) {
                cardType.innerHTML = '<i class="fab fa-cc-mastercard text-orange-600"></i>';
            } else if (value.startsWith('3')) {
                cardType.innerHTML = '<i class="fab fa-cc-amex text-blue-800"></i>';
            } else {
                cardType.innerHTML = '';
            }
        });

        // Luhn validation (client-side check)
        function luhnCheck(cardNum) {
            let sum = 0;
            let shouldDouble = false;
            for (let i = cardNum.length - 1; i >= 0; i--) {
                let digit = parseInt(cardNum[i]);
                if (shouldDouble) {
                    digit *= 2;
                    if (digit > 9) digit -= 9;
                }
                sum += digit;
                shouldDouble = !shouldDouble;
            }
            return sum % 10 === 0;
        }

        // Validate on submit (optional client-side)
        document.querySelector('form').addEventListener('submit', function(e) {
            const cardNum = cardInput.value.replace(/\s/g, '');
            if (!luhnCheck(cardNum)) {
                alert('Invalid card number!');
                e.preventDefault();
            }
        });
    </script>
</body>
</html>