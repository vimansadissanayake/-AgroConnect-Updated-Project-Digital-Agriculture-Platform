<?php
session_start();
$message = "";

$servername = "localhost";
$username_db = "root";
$password_db = "";
$dbname = "vimansa";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? '';

    if (empty($name) || empty($email) || empty($password) || empty($role)) {
        $message = "Please fill all fields!";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $conn = new mysqli($servername, $username_db, $password_db, $dbname);

        if ($conn->connect_error) {
            $message = "Database connection failed: " . $conn->connect_error;
        } else {
            $stmt_check = $conn->prepare("SELECT id FROM users WHERE email = ?");
            $stmt_check->bind_param("s", $email);
            $stmt_check->execute();
            $stmt_check->store_result();

            if ($stmt_check->num_rows > 0) {
                $message = "Email already exists. Please use a different one.";
            } else {
                $stmt_insert = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
                $stmt_insert->bind_param("ssss", $name, $email, $hashed_password, $role);

                if ($stmt_insert->execute()) {
                    $message = "Registration successful! You can now login.";
                    header("Location: login.php?registration=success");
                    exit();
                } else {
                    $message = "Error: " . $stmt_insert->error;
                }
                $stmt_insert->close();
            }
            $stmt_check->close();
            $conn->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | AgroConnect</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        body { font-family: 'Poppins', sans-serif; background-color: #f1ffeb; }
        .hero-gradient { background: linear-gradient(135deg, #2e7d32 0%, #7cb342 100%); }
    </style>
</head>
<body>
    <div class="min-h-screen flex flex-col justify-center items-center bg-[#f1ffeb]">
        <div class="mb-8 text-center">
            <a href="home.php" class="inline-block hover:opacity-80 transition-opacity">
                <img src="logo.png" alt="AgroConnect Logo" class="w-12 h-10 mx-auto mb-2">
                <h1 class="text-3xl font-bold text-green-800">AgroConnect</h1>
                <p class="text-green-700 font-medium mt-1">Digital Agriculture Platform</p>
            </a>
        </div>
        <div class="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md">
            <h2 class="text-2xl font-bold text-green-700 mb-6 text-center">Register for AgroConnect</h2>
            <?php if (!empty($message)) : ?>
                <div class="text-center mb-4 p-3 rounded-lg <?php echo (strpos($message, 'successful') !== false) ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-600'; ?>">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>
            <form method="POST" autocomplete="off">
                <div class="mb-4">
                    <label class="block text-gray-700 mb-1" for="name">
                        <i class="fas fa-user mr-2 text-green-600"></i>Your Name
                    </label>
                    <input class="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-green-600 focus:outline-none transition"
                        type="text" id="name" name="name" placeholder="Vimansa Charuni" required>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700 mb-1" for="email">
                        <i class="fas fa-envelope mr-2 text-green-600"></i>Email Address
                    </label>
                    <input class="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-green-600 focus:outline-none transition"
                        type="email" id="email" name="email" placeholder="vimansa@example.com" required>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700 mb-1" for="password">
                        <i class="fas fa-lock mr-2 text-green-600"></i>Password
                    </label>
                    <input class="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-green-600 focus:outline-none transition"
                        type="password" id="password" name="password" placeholder="Create your password" required>
                </div>
                <div class="mb-6">
                    <label class="block text-gray-700 mb-1" for="role">
                        <i class="fas fa-user-tag mr-2 text-green-600"></i>Register As
                    </label>
                    <select class="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-green-600 focus:outline-none transition"
                        id="role" name="role" required>
                        <option value="">Select your role</option>
                        <option value="Buyer">Buyer</option>
                        <option value="Farmer">Farmer</option>
                        <option value="Delivery">Delivery</option>
                        <option value="Food Tester">Food Tester</option>
                    </select>
                </div>
                <button type="submit" class="w-full py-3 bg-green-700 hover:bg-green-800 text-white font-bold rounded-lg transition">
                    Register
                </button>
            </form>
            <p class="mt-6 text-center text-gray-600 text-sm">
                Already have an account?
                <a href="login.php" class="text-green-700 font-bold hover:underline">Login</a>
            </p>
            <p class="mt-4 text-center">
                <a href="home.php" class="text-gray-600 hover:text-green-700 text-sm inline-flex items-center">
                    <i class="fas fa-arrow-left mr-2"></i> Back to Home
                </a>
            </p>
        </div>
        <footer class="mt-8 text-gray-500 text-sm text-center">
            &copy; 2025 AgroConnect. All rights reserved.
        </footer>
    </div>
</body>
</html>
