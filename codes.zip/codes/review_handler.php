<?php
// review_handler.php - Handle all review operations
session_start();

header('Content-Type: application/json');

// Database connection
$servername = "localhost";
$username_db = "root";
$password_db = "";
$dbname = "vimansa";

$conn = new mysqli($servername, $username_db, $password_db, $dbname);
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit();
}

// Get action from POST
$action = $_POST['action'] ?? '';

switch ($action) {
    case 'submit_review':
        submitReview($conn);
        break;
    
    case 'get_reviews':
        getReviews($conn);
        break;
    
    case 'mark_helpful':
        markHelpful($conn);
        break;
    
    case 'get_product_rating':
        getProductRating($conn);
        break;
    
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}

$conn->close();

function submitReview($conn) {
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'message' => 'Please login to submit a review']);
        return;
    }
    
    $user_id = $_SESSION['user_id'];
    $product_id = intval($_POST['product_id'] ?? 0);
    $rating = intval($_POST['rating'] ?? 0);
    $review_text = trim($_POST['review_text'] ?? '');
    
    // Validation
    if ($product_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid product']);
        return;
    }
    
    if ($rating < 1 || $rating > 5) {
        echo json_encode(['success' => false, 'message' => 'Rating must be between 1 and 5 stars']);
        return;
    }
    
    if (empty($review_text) || strlen($review_text) < 10) {
        echo json_encode(['success' => false, 'message' => 'Review must be at least 10 characters']);
        return;
    }
    
    // Check if user already reviewed this product
    $check_sql = "SELECT id FROM reviews WHERE user_id = ? AND product_id = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("ii", $user_id, $product_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => 'You have already reviewed this product']);
        $check_stmt->close();
        return;
    }
    $check_stmt->close();
    
    // Get farmer_id from product
    $farmer_sql = "SELECT farmer_id FROM products WHERE id = ?";
    $farmer_stmt = $conn->prepare($farmer_sql);
    $farmer_stmt->bind_param("i", $product_id);
    $farmer_stmt->execute();
    $farmer_result = $farmer_stmt->get_result();
    
    if ($farmer_result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Product not found']);
        $farmer_stmt->close();
        return;
    }
    
    $farmer_row = $farmer_result->fetch_assoc();
    $farmer_id = $farmer_row['farmer_id'];
    $farmer_stmt->close();
    
    // Insert review
    $insert_sql = "INSERT INTO reviews (product_id, user_id, farmer_id, rating, review_text) VALUES (?, ?, ?, ?, ?)";
    $insert_stmt = $conn->prepare($insert_sql);
    $insert_stmt->bind_param("iiiis", $product_id, $user_id, $farmer_id, $rating, $review_text);
    
    if ($insert_stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Review submitted successfully!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to submit review']);
    }
    
    $insert_stmt->close();
}

function getReviews($conn) {
    $product_id = intval($_POST['product_id'] ?? 0);
    $limit = intval($_POST['limit'] ?? 5);
    $offset = intval($_POST['offset'] ?? 0);
    
    if ($product_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid product']);
        return;
    }
    
    $sql = "SELECT r.id, r.rating, r.review_text, r.created_at, r.verified_purchase, 
                   r.helpful_count, u.name as user_name,
                   f.name as farmer_name, p.location as farmer_location,
                   CASE WHEN rh.user_id IS NOT NULL THEN 1 ELSE 0 END as user_marked_helpful
            FROM reviews r 
            JOIN users u ON r.user_id = u.id 
            JOIN products pr ON r.product_id = pr.id
            JOIN users f ON pr.farmer_id = f.id
            LEFT JOIN products p ON pr.farmer_id = p.farmer_id
            LEFT JOIN review_helpful rh ON r.id = rh.review_id AND rh.user_id = ?
            WHERE r.product_id = ? 
            GROUP BY r.id
            ORDER BY r.created_at DESC 
            LIMIT ? OFFSET ?";
    
    $user_id = $_SESSION['user_id'] ?? 0;
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiii", $user_id, $product_id, $limit, $offset);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $reviews = [];
    while ($row = $result->fetch_assoc()) {
        $reviews[] = $row;
    }
    
    // Get total count
    $count_sql = "SELECT COUNT(*) as total FROM reviews WHERE product_id = ?";
    $count_stmt = $conn->prepare($count_sql);
    $count_stmt->bind_param("i", $product_id);
    $count_stmt->execute();
    $count_result = $count_stmt->get_result();
    $total = $count_result->fetch_assoc()['total'];
    
    echo json_encode([
        'success' => true, 
        'reviews' => $reviews,
        'total' => $total,
        'has_more' => ($offset + $limit) < $total
    ]);
    
    $stmt->close();
    $count_stmt->close();
}

function markHelpful($conn) {
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'message' => 'Please login']);
        return;
    }
    
    $user_id = $_SESSION['user_id'];
    $review_id = intval($_POST['review_id'] ?? 0);
    
    if ($review_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid review']);
        return;
    }
    
    // Check if already marked
    $check_sql = "SELECT id FROM review_helpful WHERE review_id = ? AND user_id = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("ii", $review_id, $user_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows > 0) {
        // Unmark as helpful
        $delete_sql = "DELETE FROM review_helpful WHERE review_id = ? AND user_id = ?";
        $delete_stmt = $conn->prepare($delete_sql);
        $delete_stmt->bind_param("ii", $review_id, $user_id);
        $delete_stmt->execute();
        
        // Update count
        $update_sql = "UPDATE reviews SET helpful_count = helpful_count - 1 WHERE id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("i", $review_id);
        $update_stmt->execute();
        
        echo json_encode(['success' => true, 'marked' => false]);
        $delete_stmt->close();
        $update_stmt->close();
    } else {
        // Mark as helpful
        $insert_sql = "INSERT INTO review_helpful (review_id, user_id) VALUES (?, ?)";
        $insert_stmt = $conn->prepare($insert_sql);
        $insert_stmt->bind_param("ii", $review_id, $user_id);
        $insert_stmt->execute();
        
        // Update count
        $update_sql = "UPDATE reviews SET helpful_count = helpful_count + 1 WHERE id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("i", $review_id);
        $update_stmt->execute();
        
        echo json_encode(['success' => true, 'marked' => true]);
        $insert_stmt->close();
        $update_stmt->close();
    }
    
    $check_stmt->close();
}

function getProductRating($conn) {
    $product_id = intval($_POST['product_id'] ?? 0);
    
    if ($product_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid product']);
        return;
    }
    
    $sql = "SELECT 
                COUNT(*) as total_reviews,
                AVG(rating) as average_rating,
                SUM(CASE WHEN rating = 5 THEN 1 ELSE 0 END) as rating_5,
                SUM(CASE WHEN rating = 4 THEN 1 ELSE 0 END) as rating_4,
                SUM(CASE WHEN rating = 3 THEN 1 ELSE 0 END) as rating_3,
                SUM(CASE WHEN rating = 2 THEN 1 ELSE 0 END) as rating_2,
                SUM(CASE WHEN rating = 1 THEN 1 ELSE 0 END) as rating_1
            FROM reviews 
            WHERE product_id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();
    
    echo json_encode(['success' => true, 'data' => $data]);
    $stmt->close();
}
?>
