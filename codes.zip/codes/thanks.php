<?php
// thanks.php - Order confirmation page

session_start();
// You might want to display the order ID or summary here
// if passed from checkout.php via session or GET parameters.
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmed - AgroConnect</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #e8f5e8 0%, #f0f9f0 100%);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            color: #333;
            text-align: center;
        }
        .container {
            background: white;
            padding: 3rem;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 500px;
        }
        h2 {
            font-size: 2.5rem;
            color: #2d5a2d;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 1rem;
        }
        h2::before {
            content: "🎉";
            font-size: 2.2rem;
        }
        p {
            font-size: 1.1rem;
            color: #555;
            margin-bottom: 2rem;
        }
        .btn-continue {
            background: #28a745;
            color: white;
            border: none;
            padding: 0.9rem 2rem;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            font-size: 1.1rem;
            text-decoration: none;
            display: inline-block;
            transition: background 0.3s ease, transform 0.3s ease;
        }
        .btn-continue:hover {
            background: #218838;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Thank you for your order!</h2>
        <p>Your purchase has been confirmed and is being processed.</p>
        <a href="buyer.php" class="btn-continue">Continue Shopping</a>
    </div>
</body>
</html>
