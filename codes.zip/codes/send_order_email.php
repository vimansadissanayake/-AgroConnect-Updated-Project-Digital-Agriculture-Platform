<?php
function sendOrderConfirmationEmail($orderId, $userEmail, $userName, $orderDetails) {
    $subject = "Order Confirmation #$orderId - AgroConnect";
    
    $message = "
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #2d5a2d; color: white; padding: 20px; text-align: center; }
            .content { background: #f9f9f9; padding: 20px; }
            .order-item { border-bottom: 1px solid #ddd; padding: 10px 0; }
            .total { font-size: 1.2em; font-weight: bold; color: #2d5a2d; margin-top: 20px; }
            .footer { background: #f0f0f0; padding: 15px; text-align: center; font-size: 0.9em; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>🌾 Order Confirmed!</h1>
            </div>
            <div class='content'>
                <p>Dear $userName,</p>
                <p>Thank you for your order! Your order #$orderId has been confirmed.</p>
                
                <h3>Order Details:</h3>
                <div style='background: white; padding: 15px; border-radius: 5px;'>
                    {$orderDetails['items_html']}
                    <div class='total'>Total: Rs.{$orderDetails['total']}</div>
                </div>
                
                <h3>What's Next?</h3>
                <ul>
                    <li>✅ You'll receive an order confirmation email shortly</li>
                    <li>👨‍🌾 The farmer will prepare your order</li>
                    <li>📍 Track your delivery in real-time from your dashboard</li>
                    <li>⭐ After delivery, you can rate and review your purchase</li>
                </ul>
                
                <p style='margin-top: 20px;'>
                    <a href='http://localhost/agggg%20-%20Copy/order_tracking.php?order_id=$orderId' 
                       style='background: #2d5a2d; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block;'>
                        Track Your Order
                    </a>
                </p>
            </div>
            <div class='footer'>
                <p>AgroConnect - Connecting Farmers with Buyers</p>
                <p>For support, contact us at support@agroconnect.com</p>
            </div>
        </div>
    </body>
    </html>
    ";
    
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: AgroConnect <noreply@agroconnect.com>" . "\r\n";
    
    return mail($userEmail, $subject, $message, $headers);
}
?>
