<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$admin_name = $_SESSION['user_name'];

// Fetch comprehensive statistics
$stats = [
    'total_users' => $conn->query("SELECT COUNT(*) as count FROM users WHERE role != 'admin'")->fetch_assoc()['count'],
    'total_farmers' => $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'Farmer'")->fetch_assoc()['count'],
    'total_buyers' => $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'Buyer'")->fetch_assoc()['count'],
    'total_delivery' => $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'Delivery'")->fetch_assoc()['count'],
    'total_testers' => $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'Food Tester'")->fetch_assoc()['count'],
    'total_products' => $conn->query("SELECT COUNT(*) as count FROM products")->fetch_assoc()['count'],
    'verified_products' => $conn->query("SELECT COUNT(*) as count FROM products WHERE is_quality_verified = 1")->fetch_assoc()['count'],
    'total_orders' => $conn->query("SELECT COUNT(*) as count FROM orders")->fetch_assoc()['count'],
    'pending_orders' => $conn->query("SELECT COUNT(*) as count FROM orders WHERE status = 'pending'")->fetch_assoc()['count'],
    'completed_orders' => $conn->query("SELECT COUNT(*) as count FROM orders WHERE status = 'delivered'")->fetch_assoc()['count'],
    'total_revenue' => $conn->query("SELECT SUM(total_amount) as revenue FROM orders WHERE payment_status = 'completed'")->fetch_assoc()['revenue'] ?? 0,
    'total_reviews' => $conn->query("SELECT COUNT(*) as count FROM reviews")->fetch_assoc()['count'],
    'total_diseases' => $conn->query("SELECT COUNT(*) as count FROM disease_reports")->fetch_assoc()['count'],
    'pending_diseases' => $conn->query("SELECT COUNT(*) as count FROM disease_reports WHERE diagnosis IS NULL")->fetch_assoc()['count']
];

// Get current view
$view = $_GET['view'] ?? 'dashboard';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - AgroConnect</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        body { font-family: 'Poppins', sans-serif; }
        .sidebar-link.active { background-color: #065f46; }
    </style>
</head>
<body class="bg-gray-100">
    <div class="flex h-screen overflow-hidden">
        <!-- Sidebar -->
        <aside class="w-64 bg-green-800 text-white flex-shrink-0 overflow-y-auto">
            <div class="p-6">
                <div class="flex items-center space-x-3 mb-8">
                    <img src="logo.png" alt="Logo" class="w-10 h-10">
                    <h1 class="text-xl font-bold">AgroConnect Admin</h1>
                </div>
                <nav class="space-y-2">
                    <a href="?view=dashboard" class="sidebar-link flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-green-700 transition <?php echo $view == 'dashboard' ? 'active' : ''; ?>">
                        <i class="fas fa-chart-line"></i>
                        <span>Dashboard</span>
                    </a>
                    <a href="?view=users" class="sidebar-link flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-green-700 transition <?php echo $view == 'users' ? 'active' : ''; ?>">
                        <i class="fas fa-users"></i>
                        <span>Users</span>
                    </a>
                    <a href="?view=products" class="sidebar-link flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-green-700 transition <?php echo $view == 'products' ? 'active' : ''; ?>">
                        <i class="fas fa-seedling"></i>
                        <span>Products</span>
                    </a>
                    <a href="?view=orders" class="sidebar-link flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-green-700 transition <?php echo $view == 'orders' ? 'active' : ''; ?>">
                        <i class="fas fa-shopping-cart"></i>
                        <span>Orders</span>
                    </a>
                    <a href="?view=reviews" class="sidebar-link flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-green-700 transition <?php echo $view == 'reviews' ? 'active' : ''; ?>">
                        <i class="fas fa-star"></i>
                        <span>Reviews</span>
                    </a>
                    <a href="?view=diseases" class="sidebar-link flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-green-700 transition <?php echo $view == 'diseases' ? 'active' : ''; ?>">
                        <i class="fas fa-leaf"></i>
                        <span>Disease Reports</span>
                    </a>
                    <a href="?view=analytics" class="sidebar-link flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-green-700 transition <?php echo $view == 'analytics' ? 'active' : ''; ?>">
                        <i class="fas fa-chart-bar"></i>
                        <span>Analytics</span>
                    </a>
                    <a href="?view=settings" class="sidebar-link flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-green-700 transition <?php echo $view == 'settings' ? 'active' : ''; ?>">
                        <i class="fas fa-cog"></i>
                        <span>Settings</span>
                    </a>
                </nav>
            </div>
            <div class="p-6 border-t border-green-700">
                <div class="flex items-center space-x-3 mb-4">
                    <div class="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center">
                        <i class="fas fa-user-shield"></i>
                    </div>
                    <div>
                        <p class="text-sm font-semibold"><?php echo htmlspecialchars($admin_name); ?></p>
                        <p class="text-xs text-green-300">Administrator</p>
                    </div>
                </div>
                <a href="logout.php" class="flex items-center space-x-2 px-4 py-2 bg-red-600 hover:bg-red-700 rounded-lg transition">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="flex-1 overflow-y-auto">
            <!-- Top Bar -->
            <header class="bg-white shadow-sm">
                <div class="px-8 py-4 flex items-center justify-between">
                    <h2 class="text-2xl font-bold text-gray-800">
                        <?php 
                        $titles = [
                            'dashboard' => 'Dashboard Overview',
                            'users' => 'User Management',
                            'products' => 'Product Management',
                            'orders' => 'Order Management',
                            'reviews' => 'Review Management',
                            'diseases' => 'Disease Reports',
                            'analytics' => 'Analytics & Reports',
                            'settings' => 'System Settings'
                        ];
                        echo $titles[$view] ?? 'Dashboard';
                        ?>
                    </h2>
                    <div class="flex items-center space-x-4">
                        <button onclick="window.print()" class="px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded-lg transition">
                            <i class="fas fa-print mr-2"></i>Print
                        </button>
                        <a href="home.php" class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition">
                            <i class="fas fa-home mr-2"></i>View Site
                        </a>
                    </div>
                </div>
            </header>

            <!-- Content Area -->
            <div class="p-8">
                <?php
                switch($view) {
                    case 'dashboard':
                        include 'admin_views/dashboard.php';
                        break;
                    case 'users':
                        include 'admin_views/users.php';
                        break;
                    case 'products':
                        include 'admin_views/products.php';
                        break;
                    case 'orders':
                        include 'admin_views/orders.php';
                        break;
                    case 'reviews':
                        include 'admin_views/reviews.php';
                        break;
                    case 'diseases':
                        include 'admin_views/diseases.php';
                        break;
                    case 'analytics':
                        include 'admin_views/analytics.php';
                        break;
                    case 'settings':
                        include 'admin_views/settings.php';
                        break;
                    default:
                        include 'admin_views/dashboard.php';
                }
                ?>
            </div>
        </main>
    </div>
</body>
</html>
