<?php
session_start();

function ensureAdminExists($conn) {
    // Check if any admin exists
    $check_sql = "SELECT id FROM users WHERE role = 'admin' LIMIT 1";
    $result = $conn->query($check_sql);
    
    if ($result->num_rows == 0) {
        // No admin exists, create default admin
        $admin_name = 'Administrator';
        $admin_email = 'admin@agroconnect.com';
        $admin_password = 'admin123';
        $hashed_password = password_hash($admin_password, PASSWORD_DEFAULT);
        
        $insert_sql = "INSERT INTO users (name, email, password, role, is_active) VALUES (?, ?, ?, 'admin', TRUE)";
        $stmt = $conn->prepare($insert_sql);
        $stmt->bind_param("sss", $admin_name, $admin_email, $hashed_password);
        $stmt->execute();
        $stmt->close();
        
        return [
            'created' => true,
            'email' => $admin_email
        ];
    }
    return ['created' => false];
}

$msg = '';
$admin_info = [];

// Database connection details
$servername = "localhost";
$username_db = "root";
$password_db = "";
$dbname = "vimansa";

// Create connection
$conn = new mysqli($servername, $username_db, $password_db, $dbname);

if ($conn->connect_error) {
    $msg = "Database connection failed: " . $conn->connect_error;
} else {
    // Auto-create admin if doesn't exist
    $admin_info = ensureAdminExists($conn);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $login_input = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($login_input) || empty($password)) {
        $msg = "Please fill all fields!";
    } else {
        
        $possible_admin_logins = [
            'admin',
            'admin@agroconnect.com',
            'admin@gmail.com',
            'admin@example.com',
            'administrator'
        ];
        
        
        $is_admin_attempt = in_array(strtolower($login_input), array_map('strtolower', $possible_admin_logins));
        
        if ($is_admin_attempt) {
            // Search for any user with admin role
            $stmt = $conn->prepare("SELECT id, name, email, password, role, is_active FROM users WHERE role = 'admin' LIMIT 1");
            $stmt->execute();
        } else {
            // Normal login - search by email
            $stmt = $conn->prepare("SELECT id, name, email, password, role, is_active FROM users WHERE email = ?");
            $stmt->bind_param("s", $login_input);
            $stmt->execute();
        }
        
        $stmt->store_result();

        if ($stmt->num_rows == 1) {
            $stmt->bind_result($id, $name, $email, $hash, $role, $is_active);
            $stmt->fetch();

            // Check if user is active
            if (!$is_active) {
                $msg = "Your account has been deactivated. Please contact support.";
            } elseif (password_verify($password, $hash)) {
                $_SESSION['user_id'] = $id;
                $_SESSION['user_name'] = $name;
                $_SESSION['user_role'] = $role;
                $_SESSION['user_email'] = $email;

                // Redirect based on role
                switch ($role) {
                    case "admin":
                        header("Location: admin.php");
                        break;
                    case "Farmer":
                        header("Location: farmer.php");
                        break;
                    case "Buyer":
                        header("Location: buyer.php");
                        break;
                    case "Delivery":
                        header("Location: delivery.php");
                        break;
                    case "Food Tester":
                        header("Location: foodtester.php");
                        break;
                    default:
                        header("Location: home.php");
                }
                exit();
            } else {
                $msg = "Invalid password!";
            }
        } else {
            $msg = "No account found! Please check your credentials or register.";
        }
        $stmt->close();
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | AgroConnect</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        body { 
            font-family: 'Poppins', sans-serif; 
            background: linear-gradient(135deg, #e8f5e8 0%, #f0f9f0 100%);
        }
        .slide-in {
            animation: slideIn 0.5s ease-out;
        }
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
    <div class="min-h-screen flex flex-col justify-center items-center p-4">
        <div class="mb-8 text-center slide-in">
            <a href="home.php" class="inline-block hover:opacity-80 transition-opacity">
                <img src="logo.png" alt="AgroConnect Logo" class="w-16 h-14 mx-auto mb-3" onerror="this.style.display='none'">
                <h1 class="text-4xl font-bold text-green-800">AgroConnect</h1>
                <p class="text-green-700 font-medium mt-2">Digital Agriculture Platform</p>
            </a>
        </div>
        
        <div class="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-md slide-in">
            <h2 class="text-2xl font-bold text-green-700 mb-2 text-center">Welcome Back!</h2>
            <p class="text-gray-600 text-center mb-6 text-sm">Sign in to continue to AgroConnect</p>
            
            <?php if (isset($admin_info['created']) && $admin_info['created']) : ?>
                <div class="mb-4 p-4 rounded-lg bg-green-50 border-2 border-green-400 slide-in">
                    <div class="flex items-start">
                        <i class="fas fa-check-circle text-green-600 text-xl mt-1 mr-3"></i>
                        <div>
                            <strong class="text-green-800 block">Admin account created successfully!</strong>
                            <p class="text-sm text-green-700 mt-2">Default login credentials:</p>
                            <div class="mt-2 bg-white p-3 rounded border border-green-300">
                                <div class="text-sm space-y-1">
                                    <div><strong class="text-green-800">Username:</strong> admin</div>
                                    <div><strong class="text-green-800">Password:</strong> admin123</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($msg)) : ?>
                <div class="text-center mb-4 p-4 rounded-lg <?php echo (strpos($msg, 'successful') !== false) ? 'bg-green-50 text-green-800 border-2 border-green-400' : 'bg-red-50 text-red-700 border-2 border-red-400'; ?>">
                    <i class="fas fa-exclamation-circle mr-2"></i><?php echo htmlspecialchars($msg); ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" autocomplete="off" class="space-y-4">
                <div>
                    <label class="block text-gray-700 font-medium mb-2" for="login">
                        <i class="fas fa-user mr-2 text-green-600"></i>Email or Username
                    </label>
                    <input class="w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-green-600 focus:outline-none transition"
                        type="text" id="login" name="login" placeholder="Enter email or username" required 
                        value="<?php echo isset($_POST['login']) ? htmlspecialchars($_POST['login']) : ''; ?>">
                    
                </div>
                
                <div>
                    <label class="block text-gray-700 font-medium mb-2" for="password">
                        <i class="fas fa-lock mr-2 text-green-600"></i>Password
                    </label>
                    <div class="relative">
                        <input class="w-full px-4 py-3 rounded-lg border-2 border-gray-200 focus:border-green-600 focus:outline-none transition pr-12"
                            type="password" id="password" name="password" placeholder="Enter your password" required>
                        <button type="button" onclick="togglePassword()" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-green-600">
                            <i class="fas fa-eye" id="toggleIcon"></i>
                        </button>
                    </div>
                </div>
                
                <div class="flex items-center justify-between">
                    <label class="inline-flex items-center text-sm text-gray-600 cursor-pointer">
                        <input type="checkbox" class="form-checkbox text-green-600 mr-2 rounded">
                        Remember me
                    </label>
                    <a href="#" class="text-green-600 hover:text-green-700 text-sm font-medium">Forgot password?</a>
                </div>
                
                <button type="submit" class="w-full py-3 bg-green-700 hover:bg-green-800 text-white font-bold rounded-lg transition shadow-lg hover:shadow-xl transform hover:-translate-y-0.5">
                    <i class="fas fa-sign-in-alt mr-2"></i>Login
                </button>
            </form>
            
            <div class="mt-6 text-center">
                <p class="text-gray-600 text-sm">
                    Don't have an account?
                    <a href="register.php" class="text-green-700 font-bold hover:underline ml-1">Create Account</a>
                </p>
            </div>
            
            <div class="mt-4 text-center">
                <a href="home.php" class="text-gray-600 hover:text-green-700 text-sm inline-flex items-center font-medium">
                    <i class="fas fa-arrow-left mr-2"></i> Back to Home
                </a>
            </div>
        </div>

        <footer class="mt-8 text-gray-600 text-sm text-center">
            <p>&copy; 2025 AgroConnect. All rights reserved.</p>
        </footer>
    </div>

    <script>
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const toggleIcon = document.getElementById('toggleIcon');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.remove('fa-eye');
                toggleIcon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.remove('fa-eye-slash');
                toggleIcon.classList.add('fa-eye');
            }
        }

        function fillAdminCredentials() {
            document.getElementById('login').value = 'admin';
            document.getElementById('password').value = 'admin123';
            
            // Visual feedback
            const loginInput = document.getElementById('login');
            const passwordInput = document.getElementById('password');
            
            loginInput.classList.add('border-green-500', 'bg-green-50');
            passwordInput.classList.add('border-green-500', 'bg-green-50');
            
            setTimeout(() => {
                loginInput.classList.remove('border-green-500', 'bg-green-50');
                passwordInput.classList.remove('border-green-500', 'bg-green-50');
            }, 2000);
        }

        function showBuyerInfo() {
            const alertDiv = document.createElement('div');
            alertDiv.className = 'fixed top-4 right-4 bg-blue-600 text-white px-6 py-4 rounded-lg shadow-2xl z-50 slide-in';
            alertDiv.innerHTML = `
                <div class="flex items-center">
                    <i class="fas fa-info-circle text-2xl mr-3"></i>
                    <div>
                        <strong class="block">Buyer Account</strong>
                        <p class="text-sm mt-1">Register or login with your buyer email</p>
                    </div>
                    <button onclick="this.parentElement.parentElement.remove()" class="ml-4 text-xl hover:text-gray-200">&times;</button>
                </div>
            `;
            document.body.appendChild(alertDiv);
            setTimeout(() => alertDiv.remove(), 5000);
        }

        <?php if (isset($admin_info['created']) && $admin_info['created']) : ?>
        // Show helpful tip for first-time setup
        setTimeout(() => {
            const hint = document.createElement('div');
            hint.className = 'fixed bottom-4 right-4 bg-green-600 text-white px-6 py-4 rounded-lg shadow-2xl z-50 max-w-sm slide-in';
            hint.innerHTML = `
                <div class="flex items-start">
                    <i class="fas fa-lightbulb text-2xl mr-3"></i>
                    <div>
                        <strong class="block mb-1">Ready to Login!</strong>
                        <p class="text-sm">Click "Admin Login" button or type "admin" and "admin123"</p>
                    </div>
                    <button onclick="this.parentElement.parentElement.remove()" class="ml-2 text-xl hover:text-gray-200">&times;</button>
                </div>
            `;
            document.body.appendChild(hint);
            setTimeout(() => hint.remove(), 8000);
        }, 1000);
        <?php endif; ?>
    </script>
</body>
</html>