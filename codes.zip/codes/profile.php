<?php
session_start();

// Database connection details
$servername = "localhost";
$username_db = "root";
$password_db = ""; // Your MySQL password
$dbname = "vimansa"; // Your database name

// Redirect if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$userId = $_SESSION['user_id'];
$userNameFromSession = htmlspecialchars($_SESSION['user_name']);
$userRole = htmlspecialchars($_SESSION['user_role'] ?? 'Buyer');

$userProfileName = '';
$userProfileEmail = '';
$userProfilePhone = '';
$userProfileAddress = '';
$userProfileImagePath = 'uploads/default_profile.png'; // Default image path
$message = '';
$messageType = ''; // 'success' or 'error'

// Establish database connection
$conn = new mysqli($servername, $username_db, $password_db, $dbname);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// --- Handle Profile Update (POST Request) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $profileName = trim($_POST['profileName'] ?? '');
    $profileEmail = trim($_POST['profileEmail'] ?? '');
    $profilePhone = trim($_POST['profilePhone'] ?? '');
    $profileAddress = trim($_POST['profileAddress'] ?? '');
    $newPassword = $_POST['profilePassword'] ?? ''; // Optional new password
    $confirmPassword = $_POST['profileConfirmPassword'] ?? '';
    
    // Initialize image path to current one, in case no new image is uploaded
    $currentImagePath = '';
    $stmt_fetch_img = $conn->prepare("SELECT profile_image_path FROM users WHERE id = ?");
    $stmt_fetch_img->bind_param("i", $userId);
    $stmt_fetch_img->execute();
    $stmt_fetch_img->bind_result($currentImagePath);
    $stmt_fetch_img->fetch();
    $stmt_fetch_img->close();

    $uploadDir = 'uploads/'; // Directory to save uploaded images
    $newImagePath = $currentImagePath; // Assume current path unless new image is uploaded

    // Handle image upload
    if (isset($_FILES['profileImageUpload']) && $_FILES['profileImageUpload']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['profileImageUpload']['tmp_name'];
        $fileName = $_FILES['profileImageUpload']['name'];
        $fileSize = $_FILES['profileImageUpload']['size'];
        $fileType = $_FILES['profileImageUpload']['type'];
        $fileNameCmps = explode(".", $fileName);
        $fileExtension = strtolower(end($fileNameCmps));

        $allowedfileExtensions = array('jpg', 'gif', 'png', 'jpeg');
        if (in_array($fileExtension, $allowedfileExtensions)) {
            // Generate a unique file name to prevent overwriting
            $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
            $destPath = $uploadDir . $newFileName;

            if (move_uploaded_file($fileTmpPath, $destPath)) {
                // If previous image was not default, delete it
                if ($currentImagePath && $currentImagePath != 'uploads/default_profile.png' && file_exists($currentImagePath)) {
                    unlink($currentImagePath);
                }
                $newImagePath = $destPath;
            } else {
                $message = "Error uploading image. Please try again.";
                $messageType = 'error';
            }
        } else {
            $message = "Invalid image file type. Only JPG, JPEG, PNG, GIF allowed.";
            $messageType = 'error';
        }
    }


    // Validate other inputs
    if (empty($profileName) || empty($profileEmail)) {
        $message = "Name and Email cannot be empty.";
        $messageType = 'error';
    } elseif ($newPassword && $newPassword !== $confirmPassword) {
        $message = "New passwords do not match!";
        $messageType = 'error';
    } else {
        // Start transaction for atomicity
        $conn->begin_transaction();
        try {
            // Update basic user info including image path
            $updateSql = "UPDATE users SET name = ?, email = ?, phone_number = ?, address = ?, profile_image_path = ? WHERE id = ?";
            $stmt = $conn->prepare($updateSql);
            $stmt->bind_param("sssssi", $profileName, $profileEmail, $profilePhone, $profileAddress, $newImagePath, $userId);
            $stmt->execute();
            $stmt->close();

            // Update password if provided
            if (!empty($newPassword)) {
                $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                $updatePassSql = "UPDATE users SET password = ? WHERE id = ?";
                $stmtPass = $conn->prepare($updatePassSql);
                $stmtPass->bind_param("si", $hashedPassword, $userId);
                $stmtPass->execute();
                $stmtPass->close();
            }

            $conn->commit();
            $message = "Profile updated successfully!";
            $messageType = 'success';

            // Update session variables if needed (e.g., if you show name from session)
            $_SESSION['user_name'] = $profileName;
            // Optionally, update image path in session if you store it there
            // $_SESSION['profile_image_path'] = $newImagePath; 

        } catch (mysqli_sql_exception $e) {
            $conn->rollback();
            $message = "Error updating profile: " . $e->getMessage();
            $messageType = 'error';
            error_log("Profile update error: " . $e->getMessage()); // Log error for debugging
        }
    }
}

// --- Fetch User Data for Display ---
$sql = "SELECT name, email, phone_number, address, role, profile_image_path FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $userData = $result->fetch_assoc();
    $userProfileName = htmlspecialchars($userData['name']);
    $userProfileEmail = htmlspecialchars($userData['email']);
    $userProfilePhone = htmlspecialchars($userData['phone_number']);
    $userProfileAddress = htmlspecialchars($userData['address']);
    $userRole = htmlspecialchars($userData['role']);
    // Set userProfileImagePath to fetched path, or default if NULL/empty
    $userProfileImagePath = !empty($userData['profile_image_path']) ? htmlspecialchars($userData['profile_image_path']) : 'uploads/default_profile.png';
} else {
    $message = "User data not found.";
    $messageType = 'error';
}
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile | AgroConnect</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f1ffeb;
        }
        .message-box {
            padding: 1rem;
            margin-bottom: 1rem;
            border-radius: 0.5rem;
            font-weight: 500;
        }
        .message-box.success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .message-box.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
     <nav class="bg-white shadow-md sticky top-0 z-50">
        <div class="container mx-auto px-6 py-3">
            <div class="flex items-center justify-between">
                <div class="flex items-center">
                    <img src="logo.png" alt="AgroConnect Logo" class="w-15 h-10 mr-2">
                    <span class="text-xl font-bold text-green-800">AgroConnect</span>
                </div>
                <div class="hidden md:flex items-center space-x-8">
                    <a href="home.php" class="text-gray-600 hover:text-green-600 font-medium">Home</a>
                    <a href="features.php" class="text-gray-700 hover:text-green-600 font-medium">Features</a>
                    <a href="marketplace.php" class="text-gray-600 hover:text-green-600 font-medium">Marketplace</a>
                    <a href="crophealth.php" class="text-gray-600 hover:text-green-600 font-medium">Crop Health</a>
                    <a href="aboutus.php" class="text-gray-600 hover:text-green-600 font-medium">About</a>
                    <a href="profile.php" class="text-green-600 hover:text-green-600 font-medium">Profile</a>
                    <a href="map.php" class="text-gray-600 hover:text-green-600 font-medium">Map</a>
                    <a href="logout.php" class="text-red-700 hover:text-red-600 font-medium transition duration-300">Logout</a>
                </div>
            </div>
        </div>
    </nav>
 
    <div class="container mx-auto px-6 py-12">
        <div class="bg-white rounded-2xl shadow-xl p-8 max-w-2xl mx-auto">
            <h2 class="text-3xl font-bold text-green-700 mb-4 text-center">My Profile</h2>
            <p class="text-center text-lg text-gray-600 mb-6">Role: <span class="font-semibold text-green-700"><?= $userRole ?></span></p>

            <?php if (!empty($message)) : ?>
                <div class="message-box <?= $messageType ?>">
                    <?= htmlspecialchars($message) ?>
                </div>
            <?php endif; ?>

            <form id="profileUpdateForm" method="POST" action="profile.php" class="space-y-6" enctype="multipart/form-data">
                <div class="flex flex-col items-center mb-8">
                    <img id="profileImagePreview" src="<?= $userProfileImagePath ?>" alt="Profile Picture" class="w-32 h-32 rounded-full object-cover border-4 border-green-300 shadow-md mb-4">
                    <label for="profileImageUpload" class="cursor-pointer bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-full transition duration-300">
                        <i class="fas fa-camera mr-2"></i>Change Photo
                    </label>
                    <input type="file" id="profileImageUpload" name="profileImageUpload" accept="image/*" class="hidden">
                    <p class="text-sm text-gray-500 mt-2">Upload a new profile picture</p>
                </div>

                <div>
                    <label class="block text-gray-700 mb-2" for="profileName">
                        <i class="fas fa-user mr-2 text-green-600"></i>Name
                    </label>
                    <input class="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-green-600 focus:outline-none transition"
                           type="text" id="profileName" name="profileName" value="<?= $userProfileName ?>" required>
                </div>

                <div>
                    <label class="block text-gray-700 mb-2" for="profileEmail">
                        <i class="fas fa-envelope mr-2 text-green-600"></i>Email Address
                    </label>
                    <input class="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-green-600 focus:outline-none transition"
                           type="email" id="profileEmail" name="profileEmail" value="<?= $userProfileEmail ?>" required>
                </div>

                <div>
                    <label class="block text-gray-700 mb-2" for="profilePhone">
                        <i class="fas fa-phone-alt mr-2 text-green-600"></i>Phone Number
                    </label>
                    <input class="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-green-600 focus:outline-none transition"
                           type="tel" id="profilePhone" name="profilePhone" value="<?= $userProfilePhone ?>" placeholder="e.g., +94712345678">
                </div>

                <div>
                    <label class="block text-gray-700 mb-2" for="profileAddress">
                        <i class="fas fa-map-marker-alt mr-2 text-green-600"></i>Address
                    </label>
                    <textarea class="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-green-600 focus:outline-none transition"
                              id="profileAddress" name="profileAddress" rows="4" placeholder="Street Address, City, Postal Code"><?= $userProfileAddress ?></textarea>
                </div>

                <?php if ($userRole == 'Farmer') : ?>
                    <div class="border-t pt-6 mt-6 border-gray-200">
                        <h4 class="text-xl font-semibold text-green-700 mb-4">Farmer Details</h4>
                        <p class="text-gray-600 mb-4">Manage your products, diseseases reports, or activities here.</p>
                        <a href="farmer.php" class="inline-block bg-green-500 hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded-lg transition">
                            <i class="fas fa-leaf mr-2"></i>Go to Farmer Dashboard
                        </a>
                        
                    </div>
                <?php elseif ($userRole == 'Buyer') : ?>
                    <div class="border-t pt-6 mt-6 border-gray-200">
                        <h4 class="text-xl font-semibold text-green-700 mb-4">Buyer Specific Options</h4>
                        <p class="text-gray-600 mb-4">View your order history or manage multiple delivery addresses.</p>
                        <a href="buyer.php" class="inline-block bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-lg transition">
                            <i class="fas fa-clipboard-list mr-2"></i>Go to Buyer Dashboard
                        </a>
                    </div>
                <?php elseif ($userRole == 'Delivery') : ?>
                    <div class="border-t pt-6 mt-6 border-gray-200">
                        <h4 class="text-xl font-semibold text-green-700 mb-4">Delivery Partner Details</h4>
                        <p class="text-gray-600 mb-4">View your assigned deliveries and route information.</p>
                        <a href="delivery.php" class="inline-block bg-orange-500 hover:bg-orange-600 text-white font-bold py-2 px-4 rounded-lg transition">
                            <i class="fas fa-truck mr-2"></i>Go to Delivery Dashboard
                        </a>
                    </div>
                <?php elseif ($userRole == 'Food Tester') : ?>
                    <div class="border-t pt-6 mt-6 border-gray-200">
                        <h4 class="text-xl font-semibold text-green-700 mb-4">Food Tester Details</h4>
                        <p class="text-gray-600 mb-4">Access disease reports and submit diagnoses.</p>
                        <a href="foodtester.php" class="inline-block bg-teal-500 hover:bg-teal-600 text-white font-bold py-2 px-4 rounded-lg transition">
                            <i class="fas fa-flask mr-2"></i>Go to Food Tester Dashboard
                        </a>
                    </div>
                <?php endif; ?>
                <div class="border-t pt-6 mt-6 border-gray-200">
                    <h4 class="text-xl font-semibold text-gray-700 mb-4">Change Password</h4>
                    <div>
                        <label class="block text-gray-700 mb-2" for="profilePassword">
                            <i class="fas fa-lock mr-2 text-green-600"></i>New Password (optional)
                        </label>
                        <input class="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-green-600 focus:outline-none transition"
                               type="password" id="profilePassword" name="profilePassword" placeholder="Enter new password">
                    </div>

                    <div>
                        <label class="block text-gray-700 mb-2" for="profileConfirmPassword">
                            <i class="fas fa-lock mr-2 text-green-600"></i>Confirm New Password
                        </label>
                        <input class="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-green-600 focus:outline-none transition"
                               type="password" id="profileConfirmPassword" name="profileConfirmPassword" placeholder="Confirm new password">
                    </div>
                </div>

                <button type="submit" name="update_profile" class="w-full py-3 bg-green-700 hover:bg-green-800 text-white font-bold rounded-lg transition">
                    <i class="fas fa-save mr-2"></i>Save Changes
                </button>
            </form>
        </div>
    </div>

     <footer class="bg-green-900 text-white py-8">
        <div class="container mx-auto px-6 text-center">
            <p>© 2025 AgroConnect. All rights reserved <i class="fas fa-heart text-yellow-500 "></i></p>
        </div>
    </footer>

    <script>
        // Client-side image preview
        document.getElementById("profileImageUpload").addEventListener("change", function(event) {
            const reader = new FileReader();
            reader.onload = function(){
                const output = document.getElementById('profileImagePreview');
                output.src = reader.result;
            };
            if (event.target.files[0]) {
                reader.readAsDataURL(event.target.files[0]);
            }
        });

        // Client-side password validation (optional, server-side is mandatory)
        document.getElementById("profileUpdateForm").addEventListener("submit", function(e) {
            const profilePassword = document.getElementById("profilePassword").value;
            const profileConfirmPassword = document.getElementById("profileConfirmPassword").value;

            if (profilePassword && profilePassword !== profileConfirmPassword) {
                e.preventDefault(); // Prevent form submission
                alert("New passwords do not match!");
                return;
            }
        });
    </script>
</body>
</html>