<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['order_id'])) {
    header('Location: buyer.php');
    exit();
}

$order_id = $_GET['order_id'];
$user_id = $_SESSION['user_id'];

// Fetch order details
$sql = "SELECT o.*, u.email FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = ? AND o.user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $order_id, $user_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) {
    header('Location: buyer.php');
    exit();
}

// Fetch order items
$items_sql = "SELECT oi.*, p.name FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?";
$stmt = $conn->prepare($items_sql);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmed - AgroConnect</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #e8f5e8 0%, #f0f9f0 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
        }
        .success-container {
            max-width: 700px;
            width: 100%;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.15);
            overflow: hidden;
            animation: slideUp 0.5s ease;
        }
        @keyframes slideUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .success-header {
            background: linear-gradient(135deg, #2d5a2d 0%, #1a3d1a 100%);
            color: white;
            padding: 3rem 2rem;
            text-align: center;
        }
        .success-icon {
            width: 80px;
            height: 80px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem;
            animation: scaleIn 0.5s ease 0.3s both;
        }
        @keyframes scaleIn {
            from { transform: scale(0); }
            to { transform: scale(1); }
        }
        .success-icon i {
            font-size: 3rem;
            color: #28a745;
        }
        .success-header h1 {
            font-size: 2rem;
            margin-bottom: 0.5rem;
        }
        .order-number {
            font-size: 1.1rem;
            opacity: 0.9;
        }
        .success-body {
            padding: 2rem;
        }
        .info-box {
            background: #f8f9fa;
            border-left: 4px solid #2d5a2d;
            padding: 1.5rem;
            margin-bottom: 2rem;
            border-radius: 5px;
        }
        .info-box p {
            margin-bottom: 0.5rem;
            color: #666;
        }
        .info-box strong {
            color: #2d5a2d;
        }
        .next-steps {
            margin: 2rem 0;
        }
        .next-steps h3 {
            color: #2d5a2d;
            margin-bottom: 1rem;
            font-size: 1.3rem;
        }
        .step {
            display: flex;
            gap: 1rem;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: 10px;
            margin-bottom: 1rem;
            transition: transform 0.3s ease;
        }
        .step:hover {
            transform: translateX(5px);
        }
        .step-icon {
            width: 50px;
            height: 50px;
            background: #2d5a2d;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            flex-shrink: 0;
        }
        .step-content h4 {
            color: #2d5a2d;
            margin-bottom: 0.25rem;
        }
        .step-content p {
            color: #666;
            font-size: 0.9rem;
        }
        .order-items {
            margin: 2rem 0;
        }
        .order-items h3 {
            color: #2d5a2d;
            margin-bottom: 1rem;
        }
        .item {
            display: flex;
            justify-content: space-between;
            padding: 0.75rem 0;
            border-bottom: 1px solid #e8f5e8;
        }
        .item:last-child {
            border-bottom: none;
        }
        .total {
            display: flex;
            justify-content: space-between;
            padding: 1rem;
            background: #e8f5e8;
            border-radius: 10px;
            margin-top: 1rem;
            font-size: 1.2rem;
            font-weight: bold;
            color: #2d5a2d;
        }
        .actions {
            display: flex;
            gap: 1rem;
            margin-top: 2rem;
        }
        .btn {
            flex: 1;
            padding: 1rem;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            text-align: center;
            transition: all 0.3s ease;
        }
        .btn-primary {
            background: #2d5a2d;
            color: white;
        }
        .btn-primary:hover {
            background: #1a3d1a;
            transform: translateY(-2px);
        }
        .btn-secondary {
            background: #007bff;
            color: white;
        }
        .btn-secondary:hover {
            background: #0056b3;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="success-container">
        <div class="success-header">
            <div class="success-icon">
                <i class="fas fa-check"></i>
            </div>
            <h1>Order Confirmed!</h1>
            <p class="order-number">Order #<?php echo $order_id; ?></p>
        </div>
        
        <div class="success-body">
            <div class="info-box">
                <p><strong><i class="fas fa-envelope"></i> Confirmation Email Sent</strong></p>
                <p>We've sent a confirmation email to <strong><?php echo htmlspecialchars($order['email']); ?></strong></p>
                <p style="margin-bottom: 0;">Order Date: <?php echo date('F d, Y \a\t g:i A', strtotime($order['order_date'])); ?></p>
            </div>

            <div class="next-steps">
                <h3><i class="fas fa-list-check"></i> What Happens Next?</h3>
                
                <div class="step">
                    <div class="step-icon">
                        <i class="fas fa-envelope-circle-check"></i>
                    </div>
                    <div class="step-content">
                        <h4>Email Confirmation</h4>
                        <p>You'll receive an order confirmation email shortly with all the details</p>
                    </div>
                </div>

                <div class="step">
                    <div class="step-icon">
                        <i class="fas fa-seedling"></i>
                    </div>
                    <div class="step-content">
                        <h4>Farmer Preparation</h4>
                        <p>The farmer will prepare your fresh produce order</p>
                    </div>
                </div>

                <div class="step">
                    <div class="step-icon">
                        <i class="fas fa-truck"></i>
                    </div>
                    <div class="step-content">
                        <h4>Real-Time Tracking</h4>
                        <p>Track your delivery in real-time from your dashboard</p>
                    </div>
                </div>

                <div class="step">
                    <div class="step-icon">
                        <i class="fas fa-star"></i>
                    </div>
                    <div class="step-content">
                        <h4>Rate & Review</h4>
                        <p>After delivery, you can rate and review your purchase</p>
                    </div>
                </div>
            </div>

            <div class="order-items">
                <h3><i class="fas fa-box"></i> Order Summary</h3>
                <?php foreach($items as $item): ?>
                <div class="item">
                    <span><?php echo htmlspecialchars($item['name']); ?> × <?php echo $item['quantity']; ?></span>
                    <span>Rs.<?php echo number_format($item['price_at_order'] * $item['quantity'], 2); ?></span>
                </div>
                <?php endforeach; ?>
                <div class="total">
                    <span>Total Amount</span>
                    <span>Rs.<?php echo number_format($order['total_amount'], 2); ?></span>
                </div>
            </div>

            <div class="actions">
                <a href="order_tracking.php?order_id=<?php echo $order_id; ?>" class="btn btn-secondary">
                    <i class="fas fa-map-marker-alt"></i> Track Order
                </a>
                <a href="buyer.php" class="btn btn-primary">
                    <i class="fas fa-home"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </div>
</body>
</html>
