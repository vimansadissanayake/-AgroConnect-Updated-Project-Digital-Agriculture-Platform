<?php
session_start();

$order_id = $_GET['order_id'] ?? null;
$transaction_id = $_GET['transaction_id'] ?? null;

if (!$order_id || !$transaction_id) {
    header("Location: buyer.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Successful - AgroConnect</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        body { font-family: 'Poppins', sans-serif; }
        @keyframes checkmark {
            0% { stroke-dashoffset: 100; }
            100% { stroke-dashoffset: 0; }
        }
        .checkmark { animation: checkmark 0.6s ease-in-out 0.4s forwards; }
    </style>
</head>
<body class="bg-gradient-to-br from-green-50 to-green-100 min-h-screen flex items-center justify-center">
    <div class="max-w-2xl w-full mx-4">
        <div class="bg-white rounded-3xl shadow-2xl p-8 text-center">
            <!-- Success Icon -->
            <div class="mb-6">
                <div class="mx-auto w-24 h-24 bg-green-100 rounded-full flex items-center justify-center">
                    <svg class="w-16 h-16" viewBox="0 0 52 52">
                        <circle class="checkmark" cx="26" cy="26" r="25" fill="none" stroke="#28a745" stroke-width="3" stroke-dasharray="100" stroke-dashoffset="100"/>
                        <path class="checkmark" fill="none" stroke="#28a745" stroke-width="3" stroke-linecap="round" stroke-dasharray="48" stroke-dashoffset="48" d="M14 27l7 7 16-16"/>
                    </svg>
                </div>
            </div>

            <!-- Success Message -->
            <h1 class="text-4xl font-bold text-green-800 mb-4">
                Payment Successful!
            </h1>
            <p class="text-xl text-gray-600 mb-8">
                Your order has been placed successfully
            </p>

            <!-- Transaction Details -->
            <div class="bg-green-50 rounded-2xl p-6 mb-8">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-left">
                    <div>
                        <p class="text-sm text-gray-600 mb-1">Order ID</p>
                        <p class="text-lg font-bold text-green-800">#<?php echo htmlspecialchars($order_id); ?></p>
                    </div>
                    <div>
                        <p class="text-sm text-gray-600 mb-1">Transaction ID</p>
                        <p class="text-lg font-bold text-green-800"><?php echo htmlspecialchars($transaction_id); ?></p>
                    </div>
                </div>
            </div>

            <!-- Info Card -->
            <div class="bg-blue-50 border border-blue-200 rounded-xl p-6 mb-8 text-left">
                <div class="flex items-start space-x-3">
                    <i class="fas fa-info-circle text-blue-600 text-2xl mt-1"></i>
                    <div>
                        <h3 class="font-bold text-gray-800 mb-2">What's Next?</h3>
                        <ul class="text-sm text-gray-700 space-y-2">
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>You'll receive an order confirmation email shortly</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>The farmer will prepare your order</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>Track your delivery in real-time from your dashboard</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-600 mr-2 mt-1"></i>
                                <span>After delivery, you can rate and review your purchase</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="buyer.php" class="bg-green-700 hover:bg-green-800 text-white font-bold py-3 px-8 rounded-lg transition inline-flex items-center justify-center">
                    <i class="fas fa-shopping-bag mr-2"></i>
                    Continue Shopping
                </a>
                <a href="order_details.php?order_id=<?php echo $order_id; ?>" class="bg-white hover:bg-gray-50 text-green-700 font-bold py-3 px-8 rounded-lg border-2 border-green-700 transition inline-flex items-center justify-center">
                    <i class="fas fa-receipt mr-2"></i>
                    View Order Details
                </a>
            </div>
        </div>

        <!-- Back to Home -->
        <div class="text-center mt-6">
            <a href="home.php" class="text-green-700 hover:text-green-800 font-medium">
                <i class="fas fa-home mr-2"></i>Back to Home
            </a>
        </div>
    </div>
</body>
</html>
