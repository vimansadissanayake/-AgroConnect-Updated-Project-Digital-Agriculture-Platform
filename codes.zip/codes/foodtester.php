<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$userId = $_SESSION['user_id'];
$userName = $_SESSION['user_name']; 
$userRole = $_SESSION['user_role'] ?? 'Food Tester';

// --- Handle AJAX diagnosis submission ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['report_id'], $_POST['diagnosis'], $_POST['treatment'])) {
    $reportId = $_POST['report_id'];
    $diagnosis = $_POST['diagnosis'];
    $treatment = $_POST['treatment'];
    if (!$reportId || !$diagnosis || !$treatment) {
        http_response_code(400); exit('Missing fields');
    }
    // Database connection details (should be consistent)
    $servername = "localhost";
    $username_db = "root";
    $password_db = "";
    $dbname = "vimansa"; 

    $conn = new mysqli($servername, $username_db, $password_db, $dbname);
    if ($conn->connect_error) { http_response_code(500); exit('DB error'); }
    // When a food tester submits a diagnosis, set seen_notification for the farmer to 0 (unseen)
    $stmt = $conn->prepare("UPDATE disease_reports SET diagnosis=?, treatment_suggestion=?, seen_notification=0 WHERE id=?");
    $stmt->bind_param("ssi", $diagnosis, $treatment, $reportId);
    $ok = $stmt->execute();
    $stmt->close();
    $conn->close();
    if ($ok) echo 'success'; else http_response_code(500);
    exit();
}


$servername = "localhost";
$username_db = "root";
$password_db = "";
$dbname = "vimansa"; 

$conn = new mysqli($servername, $username_db, $password_db, $dbname);
if ($conn->connect_error) die("<div style='color:red;'>Database connection failed: " . $conn->connect_error . "</div>");

// --- Get Pending Disease Reports (for food tester to diagnose & notifications) ---
$pending = [];
$sql = "SELECT d.*, u.name
        FROM disease_reports d
        LEFT JOIN users u ON d.user_id = u.id
        WHERE d.diagnosis IS NULL OR d.diagnosis = ''
        ORDER BY d.created_at DESC";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) $pending[] = $row;

// --- Get Diagnosed Reports ---

$submitted = [];
$sql2 = "SELECT d.*, u.name
        FROM disease_reports d
        LEFT JOIN users u ON d.user_id = u.id
        WHERE d.diagnosis IS NOT NULL AND d.diagnosis != ''
        ORDER BY d.created_at DESC";
$result2 = $conn->query($sql2);
while ($row = $result2->fetch_assoc()) $submitted[] = $row;

// --- Prepare notification data for food tester ---
// For food testers, notifications are new pending reports.
$diseaseNotifications = $pending; // All pending reports are potential notifications for the food tester
$showRedDot = count($diseaseNotifications) > 0;

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?php echo htmlspecialchars($userRole); ?> - AgroConnect Food Tester Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<style>
/* Reset and Base Styles */
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background: linear-gradient(135deg, #e8f5e8 0%, #f0f9f0 100%);
    min-height: 100vh; color: #333; margin:0;}
.header { background: white; padding: 1rem 2rem; box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    position: sticky; top: 0; z-index: 100;}
.nav { display: flex; justify-content: space-between; align-items: center; max-width: 1200px; margin: 0 auto;}
.logo { display: flex; align-items: center; gap: 1rem; font-size: 1.5rem; font-weight: bold; color: #2d5a2d; margin-right: 2rem;}
.logo img { width: 38px; height: 38px; }

/* Header Icons (for notifications and logout) */
.header-icons {
    display: flex;
    align-items: center;
    gap: 1rem; /* Adjusted to 1rem for consistent spacing */
    margin-left: auto;
    position: relative;
}
#notif-dot { position:absolute; right:8px; top:7px; width:12px; height:12px; background:#e53935; border-radius:50%; border:2px solid #fff; display: <?php echo $showRedDot ? 'block' : 'none'; ?>; z-index: 2; }
/* Styles for navigation links */
.nav-links {
    display: flex;
    gap: 2rem;
    list-style: none;
    margin: 0; 
    padding: 0;
}
.nav-links a {
    text-decoration: none;
    color: #666;
    font-weight: 500;
    transition: color 0.3s ease;
}
.nav-links a:hover {
    color: rgb(74, 171, 74);
}
@media (max-width: 768px) {
    .nav-links {
        display: none; 
    }
}
/* Styles for the logout button */
.btn-logout {
    background: #dc3545;
    color: white;
    border: none;
    padding: 0.5rem 1.5rem;
    border-radius: 25px;
    cursor: pointer;
    font-weight: 500;
    transition: all 0.3s ease;
    text-decoration: none;
    display: inline-block;
    text-align: center;
}
.btn-logout:hover {
    background: #c82333;
    transform: translateY(-2px);
}

/* Notification Popup */
.notification-popup {
    display: none;
    position: fixed;
    top: 70px; 
    right: 48px; 
    width: 320px;
    background: #fff;
    border-radius: 14px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.13);
    z-index: 1200;
    animation: popup-fade 0.25s;
}
@keyframes popup-fade {
    from { opacity: 0; transform: translateY(-24px);}
    to { opacity: 1; transform: translateY(0);}
}
.popup-header { font-size: 1.15rem; font-weight: bold; color: #256129; padding: 16px 20px 12px 20px; border-bottom: 1px solid #e8f5e8; display: flex; justify-content: space-between; align-items: center;}
.popup-close { font-size: 1.4rem; cursor: pointer; color: #888; padding: 2px 8px; border-radius: 4px;}
.popup-close:hover { background: #eaeaea; }
.notification-list { list-style: none; margin: 0; padding: 0 0 10px 0; max-height: 270px; overflow-y: auto;}
.notification-list li { padding: 14px 20px 10px 20px; border-bottom: 1px solid #f4f4f4; font-size: 0.97rem; display: flex; flex-direction: column;}
.notification-list li:last-child { border-bottom: none; }
.notif-title { color: #255729; font-weight: 500; }
.notif-time { color: #aaa; font-size: 0.85em; margin-top: 2px; }


/* Main Content Styles */
.container { max-width: 900px; margin: 2rem auto; padding: 0 1rem; }
.dashboard-header { margin-bottom: 2rem; }
.dashboard-title { font-size: 2rem; color: #2d5a2d; margin-bottom: 0.5rem; display: flex; align-items: center; gap: 1rem; }
.dashboard-title::before { content: "🔬"; font-size: 2rem; }
.section { background: white; border-radius: 15px; padding: 2rem; margin-bottom: 2rem;
    box-shadow: 0 5px 20px rgba(0,0,0,0.1); border: 1px solid #e8f5e8;}
.section-title { font-size: 1.3rem; color: #2d5a2d; margin-bottom: 1.5rem; font-weight: 600; }
.disease-report { background: #f8f9fa; border-radius: 10px; padding: 1.5rem; margin-bottom: 1.5rem; border-left: 4px solid #dc3545;}
.disease-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem;}
.disease-title { font-size: 1.1rem; font-weight: bold; color: #dc3545; margin-bottom: 0.5rem;}
.disease-meta { color: #666; font-size: 0.9rem; margin-bottom: 1rem; }
.disease-symptoms { color: #333; margin-bottom: 1rem; line-height: 1.5; }
.disease-image { width: 80px; height: 80px; border-radius: 10px; object-fit: cover;
    background: #e9ecef; display: flex; align-items: center; justify-content: center;
    font-size: 2rem; margin-bottom: 1rem; cursor: zoom-in;}
.diagnosis-section, .treatment-section { background: #f8f9fa; border-radius: 8px; padding: 1rem; margin-bottom: 1rem; }
.diagnosis-label, .treatment-label { font-weight: 600; color: #2d5a2d; margin-bottom: 0.5rem; }
.diagnosis-textarea, .treatment-textarea {
    width: 100%; min-height: 60px; padding: 0.75rem; border: 2px solid #e8f5e8; border-radius: 8px;
    font-family: inherit; font-size: 0.95rem; resize: vertical; background: white;}
.diagnosis-textarea:focus, .treatment-textarea:focus { outline: none; border-color: #2d5a2d; }
.submit-btn { background: #28a745; color: white; border: none; padding: 0.75rem 2rem;
    border-radius: 25px; cursor: pointer; font-weight: 500; font-size: 1rem;
    transition: all 0.3s ease; width: 100%;}
.submit-btn:hover { background: #218838; transform: translateY(-2px);}
.submitted-section { background: #e8f5e8; }
.empty-state { text-align: center; padding: 3rem; color: #666; }
.empty-state-icon { font-size: 3rem; margin-bottom: 1rem; }
.footer { background: #2d5a2d; color: white; text-align: center; padding: 2rem; margin-top: 3rem; }
/* Modal styling */
#imageModal { display:none; position:fixed; z-index:2000; left:0; top:0; width:100vw; height:100vh; background:rgba(0,0,0,0.8); align-items:center; justify-content:center;}
#imageModal[style*="display: flex"] { display: flex !important; }
#imageModal img { max-width:90vw; max-height:85vh; border-radius:15px; box-shadow:0 8px 40px #0008; }
#closeModalBtn { position:absolute; top:30px; right:40px; font-size:2.5rem; color:#fff; cursor:pointer; font-weight:bold; }
@media (max-width: 768px) {
    .dashboard-title { font-size: 1.5rem; }
    .disease-header { flex-direction: column; gap: 1rem; }
    .disease-image { width: 60px; height: 60px; font-size: 1.5rem; }
    #imageModal img { max-width:96vw; max-height:60vh;}
    #closeModalBtn { top:10px; right:15px; }
}
</style>
</head>
<body>
<header class="header">
    <nav class="nav">
        <div class="logo">
            <img src="logo.png" alt="AgroConnect Logo">
            <span>AgroConnect</span>
        </div>
        <ul class="nav-links">
            <li><a href="home.php">Home</a></li>
            <li><a href="features.php">Features</a></li>
            <li><a href="marketplace.php">Marketplace</a></li>
            <li><a href="crop-health.php">Crop Health</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="profile.php">Profile</a></li>
            <li><a href="map.php">Map</a></li>
        </ul>
        <div class="header-icons">
            <a href="javascript:void(0);" title="Notifications" style="display: flex; align-items: center; position:relative;"
            id="notif-bell" onclick="showNotificationPopup()">
                <img src="notification.png" alt="Notifications" style="width:38px; height:38px; cursor:pointer;">
                <span id="notif-dot"></span>
            </a>
            <span style="color: #2d5a2d; font-weight: bold; margin-right: 10px;">Welcome, <?php echo htmlspecialchars($userName); ?>!</span>
            <a href="logout.php" class="btn btn-logout">Logout</a>
        </div>
    </nav>
</header>
<div class="container">
    <div class="dashboard-header">
        <h1 class="dashboard-title">Food Tester Dashboard</h1>
    </div>
    <section class="section">
        <h2 class="section-title">Pending Disease Reports</h2>
        <?php
        if (count($pending) > 0) {
            foreach ($pending as $row) {
                $caseId = 'D-' . str_pad($row['id'], 3, '0', STR_PAD_LEFT);
                $userName = htmlspecialchars($row['name'] ?? 'Unknown');
                $cropType = htmlspecialchars($row['crop_type']);
                $symptoms = htmlspecialchars($row['symptoms']);
                // Corrected to use image_url from database.sql
                if (!empty($row['image_path']) && file_exists($row['image_path'])) {
                    $imageHtml = "<img src=\"{$row['image_path']}\" alt=\"Disease Image\" class=\"disease-image clickable-image\" onclick=\"showImageModal('{$row['image_path']}')\">";
                } else {
                    $imageHtml = "<div class=\"disease-image\">🌱</div>";
                }
                $createdAt = strtotime($row['created_at']);
                $seconds = time() - $createdAt;
                if ($seconds < 60) $timeAgo = "$seconds seconds ago";
                else if ($seconds < 3600) $timeAgo = floor($seconds/60) . " minutes ago";
                else if ($seconds < 86400) $timeAgo = floor($seconds/3600) . " hours ago";
                else $timeAgo = floor($seconds/86400) . " days ago";
                echo <<<HTML
                <div class="disease-report" data-report-id="{$row['id']}">
                    <div class="disease-header">
                        <div>
                            <div class="disease-title">{$cropType} Disease (Case ID: {$caseId})</div>
                            <div class="disease-meta">
                                Reported by: {$userName} • Crop Type: {$cropType} • {$timeAgo}
                            </div>
                            <div class="disease-symptoms">
                                Symptoms: {$symptoms}
                            </div>
                        </div>
                        {$imageHtml}
                    </div>
                    <div class="diagnosis-section">
                        <div class="diagnosis-label">Diagnosis</div>
                        <textarea class="diagnosis-textarea" placeholder="Enter your diagnosis..."></textarea>
                    </div>
                    <div class="treatment-section">
                        <div class="treatment-label">Treatment Suggestion</div>
                        <textarea class="treatment-textarea" placeholder="Suggest treatment, e.g., Fungicide application, pruning..."></textarea>
                    </div>
                    <button class="submit-btn" onclick="submitDiagnosis('{$row['id']}', this)">Submit Diagnosis</button>
                </div>
HTML;
            }
        } else {
            echo '<div class="empty-state"><div class="empty-state-icon">📋</div>No disease reports found.</div>';
        }
        ?>
    </section>
    <section class="section submitted-section">
        <h2 class="section-title">Submitted Diagnoses</h2>
        <?php
        if (count($submitted) > 0) {
            foreach ($submitted as $row2) {
                $caseId2 = 'D-' . str_pad($row2['id'], 3, '0', STR_PAD_LEFT);
                $userName2 = htmlspecialchars($row2['name'] ?? 'Unknown');
                $cropType2 = htmlspecialchars($row2['crop_type']);
                $diagnosis2 = htmlspecialchars($row2['diagnosis']);
                $treatment2 = htmlspecialchars($row2['treatment_suggestion']);
                echo <<<HTML
                <div class="disease-report" style="border-left:4px solid #28a745;">
                    <div class="disease-header">
                        <div>
                            <div class="disease-title" style="color:#28a745;">{$cropType2} Disease (Case ID: {$caseId2})</div>
                            <div class="disease-meta">
                                Reported by: {$userName2}
                            </div>
                            <div class="disease-symptoms">
                                <strong>Diagnosis:</strong> {$diagnosis2}<br>
                                <strong>Treatment:</strong> {$treatment2}
                            </div>
                        </div>
                    </div>
                </div>
HTML;
            }
        } else {
            echo '<div class="empty-state"><div class="empty-state-icon">📋</div><p>No diagnoses have been submitted yet.</p></div>';
        }
        ?>
    </section>
</div>
<div id="imageModal" style="display:none;">
    <span id="closeModalBtn">&times;</span>
    <img id="modalImage" src="" alt="Big Image">
</div>

<div id="notification-popup" class="notification-popup">
    <div class="popup-header">
        New Pending Reports
        <span class="popup-close" onclick="closeNotificationPopup()">&times;</span>
    </div>
    <ul class="notification-list" id="notification-list">
        <?php
        if (empty($diseaseNotifications)) {
            echo "<li><span class='notif-title'>No new pending reports</span></li>";
        } else {
            foreach ($diseaseNotifications as $notif) {
                echo "<li>
                            <span class='notif-title'>New report for '{$notif['crop_type']}' from {$notif['name']}</span>
                            <span class='notif-time'>".date('M d, H:i', strtotime($notif['created_at']))."</span>
                          </li>";
            }
        }
        ?>
    </ul>
</div>

<footer class="footer">
    <p>© 2025 AgroConnect. All rights reserved🧡</p>
</footer>
<script>
function submitDiagnosis(reportId, btn) {
    const reportCard = btn.closest('.disease-report');
    const diagnosis = reportCard.querySelector('.diagnosis-textarea').value;
    const treatment = reportCard.querySelector('.treatment-textarea').value;
    if (!diagnosis.trim() || !treatment.trim()) {
        alert('Please fill in both diagnosis and treatment suggestions before submitting.');
        return;
    }
    btn.textContent = 'Submitting...';
    btn.disabled = true;
    btn.style.background = '#6c757d';
    // AJAX to *THIS SAME FILE*
    fetch(window.location.pathname, {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'report_id=' + encodeURIComponent(reportId) +
              '&diagnosis=' + encodeURIComponent(diagnosis) +
              '&treatment=' + encodeURIComponent(treatment)
    })
    .then(res => res.text())
    .then(res => {
        if (res === 'success') {
            btn.textContent = '✅ Submitted';
            btn.style.background = '#28a745';
            setTimeout(() => {
                alert(`Diagnosis submitted!\n\nDiagnosis: ${diagnosis}\nTreatment: ${treatment}\n\nThe farmer will be notified.`);
                location.reload(); // reload to see diagnosis under "My Submitted Diagnoses"
            }, 1000);
        } else {
            btn.disabled = false;
            btn.textContent = 'Submit Diagnosis';
            alert('Failed to save diagnosis! Try again.');
        }
    }).catch(() => {
        btn.disabled = false;
        btn.textContent = 'Submit Diagnosis';
        alert('Error saving diagnosis.');
    });
}
// Modal image viewer functions
function showImageModal(src) {
    document.getElementById('modalImage').src = src;
    document.getElementById('imageModal').style.display = 'flex';
}
document.getElementById('closeModalBtn').onclick = function() {
    document.getElementById('imageModal').style.display = 'none';
    document.getElementById('modalImage').src = '';
};
// Close modal if click outside image
document.getElementById('imageModal').onclick = function(e) {
    if (e.target === this) {
        this.style.display = 'none';
        document.getElementById('modalImage').src = '';
    }
};

// Functions for notification popup 
function showNotificationPopup() {
    document.getElementById('notification-popup').style.display = 'block';
    document.getElementById('notif-dot').style.display = 'none'; // Mark as read visually
    document.body.style.overflow = 'hidden';

    
}

function closeNotificationPopup() {
    document.getElementById('notification-popup').style.display = 'none';
    document.body.style.overflow = 'auto';
}

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        // Close image modal if open
        const imageModal = document.getElementById('imageModal');
        if (imageModal && imageModal.style.display === 'flex') {
            imageModal.style.display = 'none';
            imageModal.querySelector('#modalImage').src = '';
        }
        // Close notification popup if open
        closeNotificationPopup();
    }
});

window.onclick = function(event) {
    // Close image modal if clicked outside
    const imageModal = document.getElementById('imageModal');
    if (imageModal && imageModal.style.display === 'flex' && event.target === imageModal) {
        imageModal.style.display = 'none';
        imageModal.querySelector('#modalImage').src = '';
    }

    // Close notification popup if clicked outside and not on the bell icon
    const popup = document.getElementById('notification-popup');
    const bell = document.getElementById('notif-bell');
    if (popup && popup.style.display === 'block' && !popup.contains(event.target) && !bell.contains(event.target)) {
        closeNotificationPopup();
    }
};

</script>
</body>
</html>