<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - AgroConnect</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Import Google Font - Poppins */
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f1ffeb;
        }
        /* Custom styles for mobile menu toggle */
        #mobile-menu {
            display: none;
        }
        #mobile-menu.active {
            display: block;
        }
    </style>
</head>
<body>
    <nav class="bg-white shadow-md sticky top-0 z-50">
        <div class="container mx-auto px-6 py-3">
            <div class="flex items-center justify-between">
                <div class="flex items-center">
                    <img src="logo.png" alt="AgroConnect Logo" class="w-15 h-10 mr-2">
                    <span class="text-xl font-bold text-green-800">AgroConnect</span>
                </div>
                <div class="hidden md:flex items-center space-x-8">
                    <a href="home.php" class="text-gray-600 hover:text-green-600 font-medium">Home</a>
                    <a href="features.php" class="text-green-700 hover:text-green-600 font-medium">Features</a>
                    <a href="marketplace.php" class="text-gray-600 hover:text-green-600 font-medium">Marketplace</a>
                    <a href="crophealth.php" class="text-gray-600 hover:text-green-600 font-medium">Crop Health</a>
                    <a href="aboutus.php" class="text-green-700 font-bold">About</a> <a href="profile.php" class="text-gray-600 hover:text-green-600 font-medium">Profile</a>
                    <a href="map.php" class="text-gray-600 hover:text-green-600 font-medium">Map</a>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="login.php" class="px-4 py-2 text-green-700 border border-green-700 rounded-md hover:bg-green-50 transition-all">
                        Login
                    </a>
                    <a href="register.php" class="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-all">
                        Register
                    </a>
                    <button id="mobile-menu-button" class="md:hidden text-gray-600 focus:outline-none">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                </div>
            </div>
            <div id="mobile-menu" class="md:hidden mt-4 bg-white rounded-md shadow-lg py-2">
                <a href="home.php" class="block px-4 py-2 text-gray-800 hover:bg-gray-100">Home</a>
                <a href="features.php" class="block px-4 py-2 text-gray-800 hover:bg-gray-100">Features</a>
                <a href="marketplace.php" class="block px-4 py-2 text-gray-800 hover:bg-gray-100">Marketplace</a>
                <a href="crophealth.php" class="block px-4 py-2 text-gray-800 hover:bg-gray-100">Crop Health</a>
                <a href="aboutus.php" class="block px-4 py-2 text-green-700 font-bold hover:bg-gray-100">About</a>
                <a href="profile.php" class="block px-4 py-2 text-gray-800 hover:bg-gray-100">Profile</a>
                <a href="map.php" class="block px-4 py-2 text-gray-800 hover:bg-gray-100">Map</a>
            </div>
        </div>
    </nav>

    <section id="about" class="py-16 bg-white shadow-sm">
        <div class="container mx-auto px-6 text-center">
            <h2 class="text-4xl font-extrabold text-green-800 mb-6">About AgroConnect</h2>
            <p class="text-xl leading-relaxed text-gray-700 max-w-3xl mx-auto mb-8">
                <strong class="text-green-800">AgroConnect</strong> is your smart, digital bridge connecting
                <span class="font-semibold text-green-700">farmers</span>, <span class="font-semibold text-green-700">buyers</span>,
                <span class="font-semibold text-green-700">delivery services</span>, and <span class="font-semibold text-green-700">agriculture experts</span>.
                We're committed to making agriculture more connected, efficient, and sustainable for everyone.
            </p>
            <p class="text-lg leading-relaxed text-gray-600 max-w-4xl mx-auto">
                Our dynamic platform revolutionizes the agricultural ecosystem by seamlessly connecting all stakeholders.
                Our mission is to <span class="font-semibold text-green-800">empower farmers</span> with direct market access,
                ensure the highest standards of <span class="font-semibold text-green-800">food safety</span> through expert testing,
                and deliver fresh produce <span class="font-semibold text-green-800">efficiently and reliably</span>.
                By eliminating middlemen and fostering transparency, AgroConnect helps farmers increase their income,
                enables buyers to purchase trusted, quality produce, and supports timely delivery to preserve freshness.
                Through innovative technology and community collaboration, we build a smarter, safer, and more sustainable agricultural supply chain — benefiting everyone from the farm to the table.
            </p>
        </div>
    </section>


    <section id="our-story" class="py-16 bg-gradient-to-r from-green-50 to-emerald-100">
        <div class="container mx-auto px-6 flex flex-col md:flex-row items-center justify-center gap-12">
            <div class="md:w-1/2 text-center md:text-left">
                <h3 class="text-3xl font-bold text-green-800 mb-6">AgroConnect Journey: From Idea to Impact</h3>
                <p class="text-lg text-gray-700 mb-4">
                    AgroConnect started as my software engineering project, driven by a mission to use technology to solve real challenges in agriculture.
                     My goal was to create a <strong>digital platform</strong> that connects <strong> farmers, buyers,food experts and delivery services</strong>, making farming more efficient.
                </p>
                <p class="text-lg text-gray-700">
                    To build a truly effective solution, I gained hands-on farming experience, growing various products myself. This practical insight, 
                    from planting to harvest, helped me deeply understand farmers' needs. This blend of technical skill and
                     real-world agricultural knowledge is what makes <strong>AgroConnect</strong> a truly relevant and beneficial platform for the farming community.
                </p>
            </div>
            <div class="md:w-1/2 flex justify-center">
                <img src="aboutus.png" alt="Software Engineering meets Farming" class="rounded-lg shadow-lg max-w-full h-auto">
                </div>
        </div>
    </section>

  <section class="py-12 bg-white text-center">
        <div class="container mx-auto px-6">
            <h3 class="text-2xl font-bold text-gray-800 mb-6">Connect With Us!</h3>
            <div class="flex justify-center space-x-8 text-3xl text-green-600">
                <a href="https://web.facebook.com/vimansa.dissanayake.2025" target="_blank" class="hover:text-green-800 transition-colors duration-300"><i class="fab fa-facebook"></i></a>
                
                <a href="https://medium.com/@vimansacharuni" target="_blank" class="hover:text-green-800 transition-colors duration-300"><i class="fab fa-medium"></i></a>
                
                <a href="https://www.linkedin.com/in/vimansa-dissanayake-80125535a" target="_blank" class="hover:text-green-800 transition-colors duration-300"><i class="fab fa-linkedin"></i></a>
                
                <a href="http://www.youtube.com/@Lilz_Liz" target="_blank" class="hover:text-green-800 transition-colors duration-300"><i class="fab fa-youtube"></i></a>
            </div>
        </div>
    </section>

    <footer class="bg-green-900 text-white py-8">
        <div class="container mx-auto px-6 text-center">
            <p>© 2025 AgroConnect. All rights reserved <i class="fas fa-heart text-yellow-500 "></i></p>
        </div>
    </footer>

    <script>
        // JavaScript
        document.getElementById('mobile-menu-button').addEventListener('click', function() {
            const mobileMenu = document.getElementById('mobile-menu');
            mobileMenu.classList.toggle('active');
        });
    </script>
</body>
</html>