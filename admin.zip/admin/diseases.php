<?php
session_start();
include '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

$diseases = $conn->query("SELECT d.*, u.name as farmer_name FROM disease_reports d JOIN users u ON d.farmer_id = u.id ORDER BY d.created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Disease Reports - AgroConnect</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <aside class="w-64 bg-green-800 text-white">
            <div class="p-6">
                <h2 class="text-2xl font-bold">AgroConnect</h2>
                <p class="text-sm text-green-200">Admin Panel</p>
            </div>
            <nav class="mt-6">
                <a href="dashboard.php" class="block py-3 px-6 hover:bg-green-700"><i class="fas fa-home mr-3"></i>Dashboard</a>
                <a href="users.php" class="block py-3 px-6 hover:bg-green-700"><i class="fas fa-users mr-3"></i>Users</a>
                <a href="products.php" class="block py-3 px-6 hover:bg-green-700"><i class="fas fa-box mr-3"></i>Products</a>
                <a href="orders.php" class="block py-3 px-6 hover:bg-green-700"><i class="fas fa-shopping-cart mr-3"></i>Orders</a>
                <a href="diseases.php" class="block py-3 px-6 bg-green-900"><i class="fas fa-leaf mr-3"></i>Disease Reports</a>
                <a href="reviews.php" class="block py-3 px-6 hover:bg-green-700"><i class="fas fa-star mr-3"></i>Reviews</a>
                <a href="../home.php" class="block py-3 px-6 hover:bg-green-700"><i class="fas fa-globe mr-3"></i>View Site</a>
                <a href="../logout.php" class="block py-3 px-6 hover:bg-green-700"><i class="fas fa-sign-out-alt mr-3"></i>Logout</a>
            </nav>
        </aside>

        <main class="flex-1 overflow-y-auto">
            <header class="bg-white shadow-sm p-6">
                <h1 class="text-2xl font-bold text-gray-800">Disease Reports</h1>
            </header>

            <div class="p-6">
                <div class="bg-white rounded-lg shadow overflow-hidden">
                    <table class="w-full">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Farmer</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Crop</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <?php while($disease = $diseases->fetch_assoc()): ?>
                            <tr>
                                <td class="px-6 py-4"><?= $disease['id'] ?></td>
                                <td class="px-6 py-4"><?= htmlspecialchars($disease['farmer_name']) ?></td>
                                <td class="px-6 py-4"><?= htmlspecialchars($disease['crop_name']) ?></td>
                                <td class="px-6 py-4"><span class="px-2 py-1 bg-yellow-100 text-yellow-800 rounded text-xs"><?= $disease['status'] ?></span></td>
                                <td class="px-6 py-4"><?= date('M d, Y', strtotime($disease['created_at'])) ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
