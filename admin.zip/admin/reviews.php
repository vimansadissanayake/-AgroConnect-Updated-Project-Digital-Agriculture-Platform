<?php
session_start();
include '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_review'])) {
    $review_id = $_POST['review_id'];
    $conn->query("DELETE FROM reviews WHERE id = $review_id");
    header('Location: reviews.php');
    exit();
}

$reviews = $conn->query("SELECT r.*, u.name as buyer_name, p.name as product_name FROM reviews r JOIN users u ON r.user_id = u.id JOIN products p ON r.product_id = p.id ORDER BY r.created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reviews Management - AgroConnect</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <div class="flex h-screen">
        <aside class="w-64 bg-green-800 text-white">
            <div class="p-6">
                <h2 class="text-2xl font-bold">AgroConnect</h2>
                <p class="text-sm text-green-200">Admin Panel</p>
            </div>
            <nav class="mt-6">
                <a href="dashboard.php" class="block py-3 px-6 hover:bg-green-700"><i class="fas fa-home mr-3"></i>Dashboard</a>
                <a href="users.php" class="block py-3 px-6 hover:bg-green-700"><i class="fas fa-users mr-3"></i>Users</a>
                <a href="products.php" class="block py-3 px-6 hover:bg-green-700"><i class="fas fa-box mr-3"></i>Products</a>
                <a href="orders.php" class="block py-3 px-6 hover:bg-green-700"><i class="fas fa-shopping-cart mr-3"></i>Orders</a>
                <a href="diseases.php" class="block py-3 px-6 hover:bg-green-700"><i class="fas fa-leaf mr-3"></i>Disease Reports</a>
                <a href="reviews.php" class="block py-3 px-6 bg-green-900"><i class="fas fa-star mr-3"></i>Reviews</a>
                <a href="../home.php" class="block py-3 px-6 hover:bg-green-700"><i class="fas fa-globe mr-3"></i>View Site</a>
                <a href="../logout.php" class="block py-3 px-6 hover:bg-green-700"><i class="fas fa-sign-out-alt mr-3"></i>Logout</a>
            </nav>
        </aside>

        <main class="flex-1 overflow-y-auto">
            <header class="bg-white shadow-sm p-6">
                <h1 class="text-2xl font-bold text-gray-800">Reviews Management</h1>
            </header>

            <div class="p-6">
                <div class="bg-white rounded-lg shadow overflow-hidden">
                    <table class="w-full">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Product</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Buyer</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Rating</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Review</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <?php while($review = $reviews->fetch_assoc()): ?>
                            <tr>
                                <td class="px-6 py-4"><?= $review['id'] ?></td>
                                <td class="px-6 py-4"><?= htmlspecialchars($review['product_name']) ?></td>
                                <td class="px-6 py-4"><?= htmlspecialchars($review['buyer_name']) ?></td>
                                <td class="px-6 py-4">
                                    <?php for($i = 0; $i < $review['rating']; $i++): ?>
                                        <i class="fas fa-star text-yellow-400"></i>
                                    <?php endfor; ?>
                                </td>
                                <td class="px-6 py-4"><?= htmlspecialchars(substr($review['review_text'], 0, 50)) ?>...</td>
                                <td class="px-6 py-4"><?= date('M d, Y', strtotime($review['created_at'])) ?></td>
                                <td class="px-6 py-4">
                                    <form method="POST" class="inline" onsubmit="return confirm('Delete this review?')">
                                        <input type="hidden" name="review_id" value="<?= $review['id'] ?>">
                                        <button type="submit" name="delete_review" class="text-red-600 hover:text-red-800">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
